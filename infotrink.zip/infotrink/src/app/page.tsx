"use client";

import { useEffect, useLayoutEffect, useRef, useState } from "react";
import Image from "next/image";

const NAV_ITEMS = ["Beranda", "Publikasi", "Kategori", "Galeri", "Mengenal INFOTRINK"];

const SUB_MENUS: Record<string, { description: string; items: string[] }> = {
  Publikasi: {
    description: "Pusat seluruh konten yang diterbitkan.",
    items: [
      "Artikel Informasi & Penjelasan",
      "Hasil Riset dan Penelitian",
      "Kajian dan Analisis",
      "Laporan & Catatan Perkembangan",
      "Data dan Referensi",
      "Gagasan & Konsep Pengembangan",
    ],
  },
  Kategori: {
    description: "Pengelompokan publikasi berdasarkan bidang.",
    items: ["Media Digital", "Pembangunan", "Personal", "Bidang lainnya"],
  },
  Galeri: {
    description: "Arsip visual dan dokumentasi.",
    items: [
      "Dokumentasi riset",
      "Dokumentasi media digital",
      "Dokumentasi pembangunan",
      "Dokumentasi personal",
      "Visual dan infografis",
    ],
  },
  "Mengenal INFOTRINK": {
    description:
      "Menjelaskan konsep dan keberadaan INFOTRINK sebagai sebuah wadah, bukan profil perusahaan atau lembaga.",
    items: [
      "Pengenalan INFOTRINK",
      "Latar Belakang",
      "Tujuan dan Fungsi",
      "Ruang Lingkup",
      "Prinsip Pengelolaan",
    ],
  },
};

// Nav item center X positions (in 1280x720 slide coordinates) — fallback only.
// Actual positions are measured dynamically from the DOM (handles translation/resize).
const NAV_X: Record<string, number> = {
  Beranda: 820,
  Publikasi: 910,
  Kategori: 1000,
  Galeri: 1085,
  "Mengenal INFOTRINK": 1190,
};

const LINE_START_Y = 78;
const LINE_TURN_Y = 150;
const BOX_LEFT = 70;
const BOX_RIGHT = 1210;
const BOX_BOTTOM = 680;

export default function Home() {
  const containerRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(0);
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [lastActiveMenu, setLastActiveMenu] = useState<string | null>(null);
  const [closingMenu, setClosingMenu] = useState<string | null>(null);
  const [navPositions, setNavPositions] = useState<Record<string, number>>({});
  const navItemRefs = useRef<Record<string, HTMLAnchorElement | null>>({});
  // currentPage: null = Beranda, { menu, submenu } = halaman sub-menu
  const [currentPage, setCurrentPage] = useState<{ menu: string; submenu: string } | null>(null);
  // selectedArticle: null = list view, string = article slug (detail view)
  const [selectedArticle, setSelectedArticle] = useState<string | null>(null);
  // contentHeight: tinggi aktual konten SCALED — supaya saat translate mengubah
  // teks (jadi lebih panjang/pendek), wrapper height menyesuaikan otomatis.
  // Tidak ada lagi ruang kosong atau konten ter-clip.
  const [contentHeight, setContentHeight] = useState(0);

  // useLayoutEffect runs before browser paint — no visible "jump" on refresh.
  useLayoutEffect(() => {
    const update = () => {
      const el = containerRef.current;
      if (!el) return;
      const w = el.clientWidth;
      // Scale berdasarkan WIDTH. Minimum 0.5 supaya text tetap readable di mobile.
      // Di mobile kecil (320-414px), zoom akan jadi 0.5 (bukan 0.25-0.32).
      // Konten akan overflow sedikit horizontal — tapi bisa di-scroll horizontal.
      // Lebih baik text readable + sedikit scroll, daripada text kecil tidak terbaca.
      setScale(Math.max(w / 1280, 0.5));
    };
    update();
    const ro = new ResizeObserver(update);
    if (containerRef.current) ro.observe(containerRef.current);
    window.addEventListener("resize", update);
    window.addEventListener("orientationchange", update);
    // Re-measure after fonts/layout settle
    const t1 = setTimeout(update, 100);
    const t2 = setTimeout(update, 500);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", update);
      window.removeEventListener("orientationchange", update);
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  // Apply CSS zoom ke content element — zoom benar-benar re-render text
  // di ukuran yang tepat (crisp, readable), beda dengan transform: scale.
  useEffect(() => {
    const content = contentRef.current;
    if (content && scale > 0) {
      // Pakai setProperty dengan !important supaya tidak di-override React re-render
      content.style.setProperty("zoom", scale.toString(), "important");
    }
  }, [scale, currentPage, contentHeight]);

  // Measure content height dynamically — supaya saat translate mengubah teks,
  // wrapper height menyesuaikan. Pakai MutationObserver (lebih akurat dari interval).
  useLayoutEffect(() => {
    const updateContentHeight = () => {
      const content = contentRef.current;
      if (!content) return;
      // Dengan CSS zoom, scrollHeight return nilai UNSCALED.
      // Tinggi visual = scrollHeight × scale.
      const actualHeight = content.scrollHeight * scale;
      if (actualHeight > 0) {
        requestAnimationFrame(() => setContentHeight(actualHeight));
      }
    };
    updateContentHeight();
    // Observe content untuk perubahan (misal saat translate — Google Translate
    // mengubah textContent, yang ter-detect oleh MutationObserver)
    const mo = new MutationObserver(() => {
      requestAnimationFrame(updateContentHeight);
    });
    if (contentRef.current) {
      mo.observe(contentRef.current, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: false,
      });
    }
    // ResizeObserver untuk perubahan layout (resize window, font load)
    const ro = new ResizeObserver(() => {
      requestAnimationFrame(updateContentHeight);
    });
    if (contentRef.current) ro.observe(contentRef.current);
    return () => {
      mo.disconnect();
      ro.disconnect();
    };
  }, [scale, currentPage]);

  // Measure nav item positions (called from event handlers + on mount)
  const measureNavPositions = () => {
    const el = containerRef.current;
    if (!el) return;
    const slideEl = el.querySelector('[data-slide-content]') as HTMLElement | null;
    if (!slideEl) return;
    const slideRect = slideEl.getBoundingClientRect();
    const currentScale = slideRect.width / 1280;
    if (currentScale === 0) return;
    const positions: Record<string, number> = {};
    for (const item of NAV_ITEMS) {
      const navEl = navItemRefs.current[item];
      if (navEl) {
        const navRect = navEl.getBoundingClientRect();
        const centerX = (navRect.left + navRect.width / 2 - slideRect.left) / currentScale;
        positions[item] = centerX;
      }
    }
    // Defer setState to next frame to avoid sync-state-in-effect lint warning
    requestAnimationFrame(() => setNavPositions(positions));
  };

  // Re-measure nav positions whenever menu state changes (open/close).
  useLayoutEffect(() => {
    measureNavPositions();
  }, [activeMenu, lastActiveMenu, scale]);

  const handleNavClick = (item: string, e: React.MouseEvent) => {
    e.preventDefault();
    if (item === "Beranda") {
      // Reset semua state — tutup overlay, clear article, kembali ke Beranda
      if (activeMenu) {
        setClosingMenu(activeMenu);
        setTimeout(() => setClosingMenu(null), 1500);
      }
      setActiveMenu(null);
      setLastActiveMenu("Beranda");
      setCurrentPage(null);
      setSelectedArticle(null);
      const m = containerRef.current;
      if (m) m.scrollTop = 0;
      return;
    }
    if (activeMenu === item) {
      // Same menu clicked — close (underline stays on this menu)
      setClosingMenu(item);
      setTimeout(() => setClosingMenu(null), 1500);
      setActiveMenu(null);
      setLastActiveMenu(item);
    } else if (activeMenu === null) {
      // Open this menu
      measureNavPositions();
      setTimeout(() => {
        setActiveMenu(item);
        setLastActiveMenu(item);
        requestAnimationFrame(() => measureNavPositions());
      }, 0);
    } else {
      // Different menu is open — close current, then open new one
      setClosingMenu(activeMenu);
      setTimeout(() => setClosingMenu(null), 1500);
      setActiveMenu(null);
      measureNavPositions();
      setTimeout(() => {
        setActiveMenu(item);
        setLastActiveMenu(item);
        requestAnimationFrame(() => measureNavPositions());
      }, 0);
    }
  };

  const handleClose = () => {
    if (activeMenu) {
      setClosingMenu(activeMenu);
      setTimeout(() => setClosingMenu(null), 1500);
    }
    setActiveMenu(null);
  };

  // Buka halaman sub-menu saat klik "Telusuri →"
  const handleOpenSubmenu = (menu: string, submenu: string) => {
    // Tutup overlay dulu
    if (activeMenu) {
      setClosingMenu(activeMenu);
      setTimeout(() => setClosingMenu(null), 1500);
    }
    setActiveMenu(null);
    // Set halaman baru
    setCurrentPage({ menu, submenu });
    setSelectedArticle(null);
    // Scroll ke atas
    const m = containerRef.current;
    if (m) m.scrollTop = 0;
  };

  // Kembali ke Beranda
  const handleBackToBeranda = () => {
    setCurrentPage(null);
    setSelectedArticle(null);
    setActiveMenu(null);
    setClosingMenu(null);
    const m = containerRef.current;
    if (m) m.scrollTop = 0;
  };

  // Wrapper height = contentHeight (dynamic, sudah include zoom factor)
  const wrapperHeight = contentHeight > 0 ? contentHeight : 720 * scale;

  return (
    <main
      ref={containerRef}
      style={{
        position: "fixed",
        inset: 0,
        width: "100vw",
        height: "100vh",
        overflowY: "auto",
        overflowX: "hidden",
        background:
          "linear-gradient(180deg, #81F6EF 0%, #9CF4ED 22%, #B2FBF6 45%, #CFFCF6 68%, #E1FFFD 88%, #E8FEFC 100%)",
      }}
    >
      {/* Wrapper dengan tinggi SCALED supaya scroll area pas dengan konten visual.
          Tanpa ini, transform: scale() tidak mengubah layout height, sehingga
          muncul ruang kosong di bawah saat di-scroll. */}
      <div
        style={{
          width: "100%",
          height: `${wrapperHeight}px`,
          position: "relative",
          overflow: "hidden",
          background: "#0B3B3A",
        }}
      >
        <div
          ref={contentRef}
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "1280px",
            // zoom di-set via useEffect (bukan inline style) supaya support React.
            // Tidak pakai transform: scale — zoom bikin text tetap crisp & readable.
          }}
          suppressHydrationWarning
      >
        {currentPage ? (
          <SubmenuPage
            menu={currentPage.menu}
            submenu={currentPage.submenu}
            onBack={handleBackToBeranda}
            onNavClick={handleNavClick}
            activeMenu={activeMenu}
            lastActiveMenu={lastActiveMenu}
            closingMenu={closingMenu}
            onClose={handleClose}
            navItemRefs={navItemRefs}
            navPositions={navPositions}
            selectedArticle={selectedArticle}
            onSelectArticle={(slug) => {
              setSelectedArticle(slug);
              const m = containerRef.current;
              if (m) m.scrollTop = 0;
            }}
            onBackToList={() => {
              setSelectedArticle(null);
              const m = containerRef.current;
              if (m) m.scrollTop = 0;
            }}
            onOpenSubmenu={handleOpenSubmenu}
          />
        ) : (
          <>
            <SlideContent
              activeMenu={activeMenu}
              lastActiveMenu={lastActiveMenu}
              closingMenu={closingMenu}
              onNavClick={handleNavClick}
              onClose={handleClose}
              onOpenSubmenu={handleOpenSubmenu}
              navItemRefs={navItemRefs}
              navPositions={navPositions}
            />
            <BerandaSections onOpenSubmenu={handleOpenSubmenu} />
          </>
        )}
        </div>
      </div>
    </main>
  );
}

function SlideContent({
  activeMenu,
  lastActiveMenu,
  closingMenu,
  onNavClick,
  onClose,
  onOpenSubmenu,
  navItemRefs,
  navPositions,
}: {
  activeMenu: string | null;
  lastActiveMenu: string | null;
  closingMenu: string | null;
  onNavClick: (item: string, e: React.MouseEvent) => void;
  onClose: () => void;
  onOpenSubmenu: (menu: string, submenu: string) => void;
  navItemRefs: React.RefObject<Record<string, HTMLAnchorElement | null>>;
  navPositions: Record<string, number>;
}) {
  const isOpen = activeMenu !== null;

  return (
    <div
      data-slide-content
      style={{
        position: "relative",
        width: "1280px",
        height: "720px",
        overflow: "hidden",
        background:
          "linear-gradient(180deg, #81F6EF 0%, #9CF4ED 22%, #B2FBF6 45%, #CFFCF6 68%, #E1FFFD 88%, #E8FEFC 100%)",
        fontFamily: "'Open Sans', 'Segoe UI', Tahoma, sans-serif",
      }}
    >
      {/* === HERO CONTENT (dimmed when overlay open) === */}
      <div
        style={{
          opacity: isOpen ? 0.25 : 1,
          transition: "opacity 0.4s ease",
          pointerEvents: isOpen ? "none" : "auto",
        }}
      >
        {/* Header */}
        <header
          style={{
            position: "absolute",
            top: "32px",
            left: "70px",
            right: "70px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            zIndex: 10,
          }}
        >
          {/* Logo group: icon + wordmark, dibungkus pill putih */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "12px",
              padding: "8px 22px 8px 10px",
              background: "rgba(255, 255, 255, 0.85)",
              backdropFilter: "blur(10px)",
              borderRadius: "999px",
              boxShadow: "0 4px 16px rgba(11, 59, 58, 0.12)",
              border: "1px solid rgba(255, 255, 255, 0.6)",
            }}
          >
            <Image
              src="/slide/logo_icon.png"
              alt="Infotrink logo"
              width={42}
              height={42}
              style={{
                width: "42px",
                height: "42px",
                objectFit: "contain",
                display: "block",
                filter: "drop-shadow(0 2px 4px rgba(11, 59, 58, 0.15))",
              }}
              unoptimized
            />
            <Image
              src="/slide/logo_text.png"
              alt="Infotrink"
              width={125}
              height={40}
              style={{
                width: "125px",
                height: "auto",
                objectFit: "contain",
                display: "block",
              }}
              unoptimized
            />
          </div>

          <nav
            style={{
              display: "flex",
              alignItems: "center",
              gap: "32px",
              padding: "10px 26px",
              background: "rgba(255, 255, 255, 0.55)",
              backdropFilter: "blur(8px)",
              borderRadius: "999px",
              boxShadow: "0 4px 16px rgba(11, 59, 58, 0.10)",
            }}
          >
            {NAV_ITEMS.map((item) => {
              // Underline stays on the last clicked menu (even when closed).
              // Beranda is only active by default if nothing has been clicked yet.
              const isActive = activeMenu === item;
              const isLastActive = lastActiveMenu === item && !activeMenu;
              const isDefaultBeranda =
                item === "Beranda" && !activeMenu && !lastActiveMenu;
              const isHighlighted = isActive || isLastActive || isDefaultBeranda;
              return (
                <a
                  key={item}
                  ref={(el) => {
                    navItemRefs.current[item] = el;
                  }}
                  href="#"
                  onClick={(e) => onNavClick(item, e)}
                  style={{
                    fontFamily: "'Open Sans', sans-serif",
                    fontSize: "15px",
                    fontWeight: isHighlighted ? 700 : 600,
                    color: isHighlighted ? "#0B6E6A" : "#0B3B3A",
                    textDecoration: "none",
                    padding: "4px 0",
                    borderBottom: isHighlighted
                      ? "2px solid #0B6E6A"
                      : "2px solid transparent",
                    transition: "all 0.2s ease",
                    letterSpacing: "0.2px",
                    cursor: "pointer",
                  }}
                >
                  <BrandText text={item} />
                </a>
              );
            })}
          </nav>
        </header>

        {/* Main content */}
        <div
          style={{
            position: "absolute",
            left: "70px",
            top: "150px",
            width: "560px",
            zIndex: 5,
          }}
        >
          <h1
            style={{
              fontFamily: "'Open Sans', sans-serif",
              fontWeight: 800,
              fontSize: "44px",
              lineHeight: 1.28,
              color: "#0B3B3A",
              letterSpacing: "-0.5px",
              margin: 0,
              textAlign: "left",
            }}
          >
            Mengolah Pengetahuan
            <br />
            Menjadi Wawasan
            <br />
            Bermakna
          </h1>

          <div
            style={{
              display: "flex",
              alignItems: "flex-start",
              marginTop: "32px",
              gap: "10px",
            }}
          >
            <Image
              src="/slide/quote.svg"
              alt=""
              width={48}
              height={34}
              style={{
                flexShrink: 0,
                width: "48px",
                height: "34px",
                marginTop: "-12px",
                userSelect: "none",
              }}
              unoptimized
            />
            <p
              style={{
                fontFamily: "'Open Sans', sans-serif",
                fontWeight: 400,
                fontSize: "16.5px",
                lineHeight: 1.6,
                color: "#1F2937",
                textAlign: "justify",
                textJustify: "inter-word",
                width: "470px",
                margin: 0,
              }}
            >
              Menghimpun, mengolah, dan mengembangkan pengetahuan melalui
              riset, kajian, pemikiran, serta dokumentasi dari berbagai bidang
              menjadi wawasan yang bermakna dalam satu sistem publikasi yang
              terstruktur dan berkelanjutan.
            </p>
          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginTop: "34px",
              marginLeft: "58px",
              width: "470px",
            }}
          >
            {/* Tombol KIRI: Telusuri — pakai gambar tombol asli + teks di atasnya */}
            <div
              onClick={() => onOpenSubmenu("Publikasi", SUB_MENUS["Publikasi"].items[0])}
              style={{
                position: "relative",
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "flex-end",
                height: "44px",
                width: "auto",
                paddingRight: "40px",
                paddingLeft: "60px",
                cursor: "pointer",
              }}
            >
              <img
                src="/slide/button2.png"
                alt="Tombol Telusuri"
                style={{
                  position: "absolute",
                  inset: 0,
                  width: "100%",
                  height: "100%",
                  objectFit: "fill",
                  display: "block",
                  zIndex: 0,
                }}
              />
              <span
                style={{
                  position: "relative",
                  zIndex: 1,
                  fontFamily: "'Open Sans', sans-serif",
                  fontSize: "16px",
                  fontWeight: 700,
                  color: "#1a1a1a",
                  letterSpacing: "0.3px",
                  pointerEvents: "none",
                }}
              >
                Telusuri
              </span>
            </div>

            {/* Tombol KANAN: Kenali — pakai gambar tombol asli + teks di atasnya */}
            <div
              onClick={() => onOpenSubmenu("Mengenal INFOTRINK", SUB_MENUS["Mengenal INFOTRINK"].items[0])}
              style={{
                position: "relative",
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "flex-start",
                height: "44px",
                width: "auto",
                paddingLeft: "40px",
                paddingRight: "60px",
                cursor: "pointer",
              }}
            >
              <img
                src="/slide/button1.png"
                alt="Tombol Kenali"
                style={{
                  position: "absolute",
                  inset: 0,
                  width: "100%",
                  height: "100%",
                  objectFit: "fill",
                  display: "block",
                  zIndex: 0,
                }}
              />
              <span
                style={{
                  position: "relative",
                  zIndex: 1,
                  fontFamily: "'Open Sans', sans-serif",
                  fontSize: "16px",
                  fontWeight: 700,
                  color: "#1a1a1a",
                  letterSpacing: "0.3px",
                  pointerEvents: "none",
                }}
              >
                Kenali
              </span>
            </div>
          </div>
        </div>

        {/* Photos */}
        <div
          style={{
            position: "absolute",
            left: "680px",
            top: "150px",
            width: "540px",
            height: "500px",
            zIndex: 3,
          }}
        >
          <Photo top={0} left={0} />
          <Photo top={21} left={243} />
          <Photo top={244} left={-29} />
          <Photo top={266} left={213} />
        </div>
      </div>

      {/* === OVERLAY: animated line + white box + sub menu cards ===
          Render ALL overlays from the start (hidden via CSS), so Google Translate
          can scan all sub-menu text on initial page load. Only the active one is visible. */}
      {Object.keys(SUB_MENUS).map((menuKey) => (
        <Overlay
          key={menuKey}
          menuKey={menuKey}
          isOpen={activeMenu === menuKey}
          isClosing={closingMenu === menuKey}
          onClose={onClose}
          onOpenSubmenu={onOpenSubmenu}
          navX={navPositions[menuKey] ?? NAV_X[menuKey]}
        />
      ))}
    </div>
  );
}

function Overlay({
  menuKey,
  isOpen,
  isClosing,
  onClose,
  onOpenSubmenu,
  navX,
}: {
  menuKey: string;
  isOpen: boolean;
  isClosing: boolean;
  onClose: () => void;
  onOpenSubmenu: (menu: string, submenu: string) => void;
  navX: number;
}) {
  const menuData = SUB_MENUS[menuKey];
  const linePath = `M ${navX} ${LINE_START_Y} L ${navX} ${LINE_TURN_Y} L ${BOX_LEFT} ${LINE_TURN_Y}`;

  // Wrapper: always render (so Google Translate can scan text on initial load).
  // Use visibility:hidden (not display:none) so transitions/animations still work.
  // visibility:hidden keeps text in DOM for translate, but hides from view + clicks.
  const visible = isOpen || isClosing;

  return (
    <div
      style={{
        visibility: visible ? "visible" : "hidden",
        position: "absolute",
        inset: 0,
        // Wrapper TIDAK capture pointer events — hanya elemen di dalamnya (box, X)
        // yang capture. Supaya nav (zIndex 10) tetap bisa diklik saat overlay terbuka.
        pointerEvents: "none",
      }}
    >
    <>
      {/* === Animated line (SVG): down then left, L-shape === */}
      <svg
        width="1280"
        height="720"
        style={{
          position: "absolute",
          inset: 0,
          pointerEvents: "none",
          zIndex: 20,
        }}
      >
        {/* Start dot at nav item */}
        <circle
          cx={navX}
          cy={LINE_START_Y}
          r="5"
          fill="#0B6E6A"
          style={{
            opacity: isOpen ? 1 : 0,
            transition: `opacity 0.3s ease ${isOpen ? "0s" : "1.2s"}`,
          }}
        />
        {/* The L-shaped line */}
        <path
          d={linePath}
          stroke="#0B6E6A"
          strokeWidth="3"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
          pathLength={1}
          style={{
            strokeDasharray: 1,
            strokeDashoffset: isOpen ? 0 : 1,
            transition: `stroke-dashoffset 0.6s ease ${isOpen ? "0s" : "0.7s"}`,
          }}
        />
        {/* End dot at box corner */}
        <circle
          cx={BOX_LEFT}
          cy={LINE_TURN_Y}
          r="5"
          fill="#0B6E6A"
          style={{
            opacity: isOpen ? 1 : 0,
            transition: `opacity 0.3s ease ${isOpen ? "0.5s" : "0.6s"}`,
          }}
        />
      </svg>

      {/* === White box === */}
      <div
        style={{
          position: "absolute",
          left: `${BOX_LEFT}px`,
          top: `${LINE_TURN_Y}px`,
          width: `${BOX_RIGHT - BOX_LEFT}px`,
          height: `${BOX_BOTTOM - LINE_TURN_Y}px`,
          background: "rgba(255, 255, 255, 0.97)",
          borderRadius: "0 0 16px 16px",
          boxShadow: "0 8px 32px rgba(11, 59, 58, 0.18)",
          zIndex: 15,
          pointerEvents: isOpen ? "auto" : "none",
          opacity: isOpen ? 1 : 0,
          transform: isOpen ? "scaleY(1)" : "scaleY(0)",
          transformOrigin: "center top",
          transition: `opacity 0.4s ease ${isOpen ? "0.5s" : "0.3s"}, transform 0.4s ease ${isOpen ? "0.5s" : "0.3s"}`,
          padding: "36px 44px",
          overflow: "hidden",
        }}
      >
        {/* Menu title + description */}
        <div
          style={{
            opacity: isOpen ? 1 : 0,
            transform: isOpen ? "translateY(0)" : "translateY(10px)",
            transition: `opacity 0.3s ease ${isOpen ? "0.7s" : "0s"}, transform 0.3s ease ${isOpen ? "0.7s" : "0s"}`,
          }}
        >
          <h2
            style={{
              fontSize: "30px",
              fontWeight: 800,
              color: "#0B3B3A",
              margin: 0,
              letterSpacing: "-0.3px",
            }}
          >
            <BrandText text={menuKey} />
          </h2>
          <p
            style={{
              fontSize: "15px",
              color: "#5B7A78",
              margin: "6px 0 0 0",
              fontWeight: 500,
            }}
          >
            <BrandText text={menuData.description} />
          </p>
        </div>

        {/* Divider line */}
        <div
          style={{
            height: "2px",
            background: "linear-gradient(90deg, #0B6E6A 0%, rgba(11,110,106,0.1) 100%)",
            margin: "18px 0 24px 0",
            opacity: isOpen ? 1 : 0,
            transform: isOpen ? "scaleX(1)" : "scaleX(0)",
            transformOrigin: "left center",
            transition: `opacity 0.3s ease ${isOpen ? "0.75s" : "0s"}, transform 0.4s ease ${isOpen ? "0.75s" : "0s"}`,
          }}
        />

        {/* Sub menu cards grid */}
        <div
          style={{
            display: "flex",
            gap: "14px",
            flexWrap: "wrap",
          }}
        >
          {menuData.items.map((item, i) => (
            <div
              key={item}
              style={{
                width: "182px",
                padding: "18px 16px",
                background: "linear-gradient(135deg, #F0FAF8 0%, #DCF3EC 100%)",
                borderRadius: "12px",
                border: "1px solid rgba(11, 110, 106, 0.12)",
                opacity: isOpen ? 1 : 0,
                transform: isOpen ? "translateY(0)" : "translateY(20px)",
                transition: `opacity 0.4s ease ${isOpen ? `${0.85 + i * 0.08}s` : "0s"}, transform 0.4s ease ${isOpen ? `${0.85 + i * 0.08}s` : "0s"}`,
              }}
            >
              {/* Number badge */}
              <div
                style={{
                  display: "inline-block",
                  fontSize: "11px",
                  fontWeight: 700,
                  color: "#0B6E6A",
                  background: "rgba(11, 110, 106, 0.1)",
                  padding: "3px 8px",
                  borderRadius: "6px",
                  marginBottom: "10px",
                  letterSpacing: "0.5px",
                }}
              >
                {String(i + 1).padStart(2, "0")}
              </div>
              {/* Sub menu name */}
              <div
                style={{
                  fontSize: "15px",
                  fontWeight: 700,
                  color: "#0B3B3A",
                  minHeight: "38px",
                  lineHeight: 1.3,
                }}
              >
                <BrandText text={item} />
              </div>
              {/* Button */}
              <button
                onClick={() => onOpenSubmenu(menuKey, item)}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: "5px",
                  padding: "6px 14px",
                  background: "#0B6E6A",
                  color: "white",
                  border: "none",
                  borderRadius: "999px",
                  fontSize: "11px",
                  fontWeight: 700,
                  cursor: "pointer",
                  marginTop: "12px",
                  letterSpacing: "0.3px",
                  transition: "background 0.2s ease, transform 0.2s ease",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = "#0B3B3A";
                  e.currentTarget.style.transform = "translateX(2px)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = "#0B6E6A";
                  e.currentTarget.style.transform = "translateX(0)";
                }}
              >
                Telusuri →
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* === X close button (top-right inside box) === */}
      <button
        onClick={onClose}
        style={{
          position: "absolute",
          left: `${BOX_RIGHT - 56}px`,
          top: `${LINE_TURN_Y + 16}px`,
          width: "38px",
          height: "38px",
          borderRadius: "50%",
          background: "#0B3B3A",
          color: "white",
          border: "none",
          fontSize: "16px",
          fontWeight: 700,
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 18,
          pointerEvents: isOpen ? "auto" : "none",
          opacity: isOpen ? 1 : 0,
          transform: isOpen ? "scale(1) rotate(0deg)" : "scale(0) rotate(-90deg)",
          transition: `opacity 0.3s ease ${isOpen ? "0.85s" : "0.2s"}, transform 0.3s ease ${isOpen ? "0.85s" : "0.2s"}`,
          boxShadow: "0 4px 12px rgba(11, 59, 58, 0.25)",
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = "#d32f2f";
          e.currentTarget.style.transform = "scale(1.1) rotate(0deg)";
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = "#0B3B3A";
          e.currentTarget.style.transform = "scale(1) rotate(0deg)";
        }}
      >
        ✕
      </button>
    </>
    </div>
  );
}

function Photo({ top, left }: { top: number; left: number }) {
  return (
    <Image
      src="/slide/office_photo.png"
      alt="Suasana kantor kolaboratif dengan tim sedang bekerja di sekitar laptop"
      width={232}
      height={232}
      style={{
        position: "absolute",
        top: `${top}px`,
        left: `${left}px`,
        width: "232px",
        height: "232px",
        objectFit: "cover",
        borderRadius: "4px",
        boxShadow: "0 4px 12px rgba(11, 59, 58, 0.15)",
      }}
      unoptimized
    />
  );
}

// BrandText: render text with "INFOTRINK" wrapped in translate="no" so Google Translate
// keeps the brand name "INFOTRINK" unchanged in all languages.
function BrandText({ text }: { text: string }) {
  if (!text.includes("INFOTRINK")) {
    return <>{text}</>;
  }
  // Split text around "INFOTRINK" — wrap brand name with translate="no"
  const parts = text.split("INFOTRINK");
  return (
    <>
      {parts.map((part, i) => (
        <span key={i}>
          {part}
          {i < parts.length - 1 && (
            <span translate="no">INFOTRINK</span>
          )}
        </span>
      ))}
    </>
  );
}

// ============================================================
// BERANDA SECTIONS (Section 2-6, below hero which is 0-720px)
// ============================================================

function BerandaSections({ onOpenSubmenu }: { onOpenSubmenu: (menu: string, submenu: string) => void }) {
  return (
    <div
      style={{
        position: "absolute",
        top: "720px",
        left: 0,
        width: "1280px",
      }}
    >
      <SectionPengenalanSingkat />
      <SectionAlurPengetahuan />
      <SectionAnatomiMateri />
      <SectionManfaatPengetahuan />
      <SectionPenutup onOpenSubmenu={onOpenSubmenu} />
    </div>
  );
}

// ----- Section 2: Pengenalan Singkat (720-1300) -----
function SectionPengenalanSingkat() {
  return (
    <section
      style={{
        position: "relative",
        height: "580px",
        padding: "50px 80px 30px",
        background: "white",
        backdropFilter: "blur(6px)",
        display: "flex",
        alignItems: "center",
        gap: "60px",
      }}
    >
      {/* Left: Text */}
      <div style={{ flex: 1, maxWidth: "620px" }}>
        <div
          style={{
            display: "inline-block",
            fontSize: "13px",
            fontWeight: 700,
            color: "#0B6E6A",
            background: "rgba(11, 110, 106, 0.1)",
            padding: "6px 14px",
            borderRadius: "999px",
            letterSpacing: "1px",
            marginBottom: "18px",
          }}
        >
          TENTANG PLATFORM
        </div>
        <h2
          style={{
            fontSize: "38px",
            fontWeight: 800,
            color: "#0B3B3A",
            margin: "0 0 22px 0",
            lineHeight: 1.2,
            letterSpacing: "-0.5px",
          }}
        >
          Wadah Pengetahuan yang Tumbuh dari Beragam Bidang
        </h2>
        <p
          style={{
            fontSize: "16.5px",
            lineHeight: 1.7,
            color: "#1F2937",
            margin: "0 0 16px 0",
            textAlign: "justify",
          }}
        >
          Berbagai hasil riset, kajian, pemikiran, dan dokumentasi dihimpun dalam satu ruang publikasi yang terstruktur. Materi tidak hanya dikumpulkan, tetapi disusun, dikelompokkan, dan disajikan agar mudah ditelusuri serta dimanfaatkan kembali.
        </p>
        <p
          style={{
            fontSize: "16.5px",
            lineHeight: 1.7,
            color: "#1F2937",
            margin: "0 0 16px 0",
            textAlign: "justify",
          }}
        >
          Bukan portal berita harian yang mengejar kecepatan pemberitaan, melainkan ruang yang menempatkan nilai informasi, kedalaman pembahasan, dan keberlanjutan dokumentasi sebagai bagian penting dari identitasnya.
        </p>
        <p
          style={{
            fontSize: "16.5px",
            lineHeight: 1.7,
            color: "#1F2937",
            margin: 0,
            textAlign: "justify",
          }}
        >
          Materi yang tersaji berasal dari berbagai kegiatan — penelitian, pengamatan, pengembangan gagasan, hingga catatan perkembangan suatu proyek — sehingga pengetahuan yang lahir dapat terus dipelajari dan dikembangkan seiring waktu.
        </p>
      </div>

      {/* Right: Visual card with photo — diperbesar supaya bawahnya sejajar dengan akhir kalimat */}
      <div style={{ flexShrink: 0, position: "relative" }}>
        <div
          style={{
            position: "absolute",
            top: "-24px",
            right: "-24px",
            width: "100%",
            height: "100%",
            background: "linear-gradient(135deg, #0B6E6A 0%, #5B7A78 100%)",
            borderRadius: "24px",
            opacity: 0.15,
          }}
        />
        <div
          style={{
            position: "relative",
            width: "430px",
            height: "470px",
            borderRadius: "22px",
            overflow: "hidden",
            boxShadow: "0 12px 32px rgba(11, 59, 58, 0.20)",
            border: "6px solid white",
          }}
        >
          <Image
            src="/slide/office_photo.png"
            alt="Suasana kerja kolaboratif"
            width={430}
            height={470}
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              display: "block",
            }}
            unoptimized
          />
          {/* Floating badge */}
          <div
            style={{
              position: "absolute",
              bottom: "16px",
              left: "16px",
              padding: "10px 16px",
              background: "rgba(255, 255, 255, 0.95)",
              borderRadius: "12px",
              boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
            }}
          >
            <div style={{ fontSize: "11px", color: "#5B7A78", fontWeight: 600, letterSpacing: "0.5px" }}>
              RUANG PUBLIKASI
            </div>
            <div style={{ fontSize: "14px", color: "#0B3B3A", fontWeight: 700 }}>
              Pengetahuan yang Bermakna
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ----- Section 3: Alur Pengetahuan (1300-1900) -----
// Judul unik (tidak mirip daftar isi), tanpa badge kecil di atas judul,
// desain berbeda: dark section + horizontal stepper + visual card + stats
const ALUR_STEPS = [
  {
    num: "01",
    title: "Himpun",
    desc: "Berbagai hasil riset, kajian, pemikiran, dan dokumentasi dikumpulkan dari beragam kegiatan dan sumber.",
    color: "#3B82F6",
  },
  {
    num: "02",
    title: "Susun",
    desc: "Materi dikelompokkan berdasarkan bidang, kategori, dan jenis agar mudah ditemukan kembali.",
    color: "#10B981",
  },
  {
    num: "03",
    title: "Sajikan",
    desc: "Informasi disusun dalam bentuk publikasi yang mudah dipahami dengan konteks yang jelas.",
    color: "#F59E0B",
  },
  {
    num: "04",
    title: "Telusuri",
    desc: "Materi dapat dicari dan ditemukan kembali oleh pembaca kapan saja sesuai kebutuhan.",
    color: "#8B5CF6",
  },
  {
    num: "05",
    title: "Manfaatkan",
    desc: "Pengetahuan dipakai untuk belajar, berkarya, atau melanjutkan perkembangan berikutnya.",
    color: "#EC4899",
  },
];

function SectionAlurPengetahuan() {
  return (
    <section
      style={{
        position: "relative",
        height: "780px",
        padding: "60px 80px 30px",
        background: "linear-gradient(135deg, #0B3B3A 0%, #0B6E6A 100%)",
        overflow: "hidden",
      }}
    >
      {/* Decorative blobs */}
      <div
        style={{
          position: "absolute",
          top: "-150px",
          right: "-150px",
          width: "400px",
          height: "400px",
          borderRadius: "50%",
          background: "rgba(129, 246, 239, 0.08)",
        }}
      />
      <div
        style={{
          position: "absolute",
          bottom: "-100px",
          left: "-100px",
          width: "300px",
          height: "300px",
          borderRadius: "50%",
          background: "rgba(129, 246, 239, 0.06)",
        }}
      />

      {/* Header: langsung judul besar (tanpa badge kecil di atas) */}
      <div style={{ position: "relative", marginBottom: "56px", maxWidth: "920px" }}>
        <h2
          style={{
            fontSize: "40px",
            fontWeight: 800,
            color: "white",
            margin: "0 0 18px 0",
            lineHeight: 1.2,
            letterSpacing: "-0.5px",
          }}
        >
          Dari Riset, Kajian, hingga Dokumentasi — Satu Alur yang Saling Terhubung
        </h2>
        <p
          style={{
            fontSize: "16.5px",
            lineHeight: 1.7,
            color: "rgba(255,255,255,0.82)",
            margin: 0,
            maxWidth: "820px",
            textAlign: "justify",
            textJustify: "inter-word",
          }}
        >
          Pengetahuan tidak berhenti pada pengumpulan. Setiap materi melalui tahapan pengolahan agar dapat disajikan secara terstruktur dan terus berkembang seiring waktu. Dari himpunan informasi yang beragam, lahir sebuah sistem publikasi yang saling terhubung, mudah ditelusuri, serta mampu menampung perkembangan dari berbagai bidang.
        </p>
      </div>

      {/* Horizontal Stepper — 5 steps dengan connector line */}
      <div
        style={{
          position: "relative",
          display: "grid",
          gridTemplateColumns: "repeat(5, 1fr)",
          gap: "14px",
          marginBottom: "50px",
        }}
      >
        {/* Connector line di belakang steps */}
        <div
          style={{
            position: "absolute",
            top: "32px",
            left: "8%",
            right: "8%",
            height: "2px",
            background: "rgba(255,255,255,0.18)",
            zIndex: 0,
          }}
        />
        {ALUR_STEPS.map((step) => (
          <div
            key={step.num}
            style={{
              position: "relative",
              zIndex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              textAlign: "center",
            }}
          >
            {/* Number circle */}
            <div
              style={{
                width: "64px",
                height: "64px",
                borderRadius: "50%",
                background: step.color,
                color: "white",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "20px",
                fontWeight: 800,
                marginBottom: "18px",
                boxShadow: `0 6px 18px ${step.color}55`,
                border: "3px solid rgba(255,255,255,0.15)",
              }}
            >
              {step.num}
            </div>
            {/* Title */}
            <h3
              style={{
                fontSize: "19px",
                fontWeight: 700,
                color: "white",
                margin: "0 0 10px 0",
              }}
            >
              {step.title}
            </h3>
            {/* Description — justified */}
            <p
              style={{
                fontSize: "12.5px",
                lineHeight: 1.6,
                color: "rgba(255,255,255,0.72)",
                margin: 0,
                maxWidth: "180px",
                textAlign: "justify",
                textJustify: "inter-word",
              }}
            >
              {step.desc}
            </p>
          </div>
        ))}
      </div>

      {/* Bottom: 3 stat cards */}
      <div
        style={{
          position: "relative",
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: "18px",
        }}
      >
        {[
          {
            stat: "Multibidang",
            label: "Ruang Lingkup",
            desc: "Mencakup beragam bidang dalam satu sistem yang saling terhubung dan mudah ditelusuri.",
            icon: (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2"/>
                <path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" stroke="currentColor" strokeWidth="2"/>
              </svg>
            ),
          },
          {
            stat: "Terstruktur",
            label: "Pengelolaan",
            desc: "Setiap materi dikelompokkan dengan konteks, kategori, dan keterkaitan yang jelas.",
            icon: (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <rect x="3" y="3" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2"/>
                <rect x="14" y="3" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2"/>
                <rect x="3" y="14" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2"/>
                <rect x="14" y="14" width="7" height="7" rx="1" stroke="currentColor" strokeWidth="2"/>
              </svg>
            ),
          },
          {
            stat: "Berkelanjutan",
            label: "Pengembangan",
            desc: "Materi terus diperbarui dan dilengkapi agar tetap relevan dari waktu ke waktu.",
            icon: (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <path d="M21 12a9 9 0 1 1-9-9 9 9 0 0 1 9 9z" stroke="currentColor" strokeWidth="2"/>
                <path d="M12 7v5l3 2" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            ),
          },
        ].map((card) => (
          <div
            key={card.label}
            style={{
              padding: "24px 26px",
              background: "rgba(255,255,255,0.07)",
              border: "1px solid rgba(255,255,255,0.12)",
              borderRadius: "14px",
              display: "flex",
              alignItems: "center",
              gap: "16px",
            }}
          >
            <div
              style={{
                flexShrink: 0,
                width: "44px",
                height: "44px",
                borderRadius: "12px",
                background: "rgba(129, 246, 239, 0.15)",
                color: "#81F6EF",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {card.icon}
            </div>
            <div style={{ flex: 1 }}>
              <div
                style={{
                  fontSize: "11px",
                  color: "rgba(255,255,255,0.6)",
                  letterSpacing: "1px",
                  marginBottom: "4px",
                }}
              >
                {card.label.toUpperCase()}
              </div>
              <div
                style={{
                  fontSize: "18px",
                  fontWeight: 700,
                  color: "white",
                  marginBottom: "6px",
                }}
              >
                {card.stat}
              </div>
              <div
                style={{
                  fontSize: "12.5px",
                  color: "rgba(255,255,255,0.7)",
                  lineHeight: 1.5,
                  textAlign: "justify",
                  textJustify: "inter-word",
                }}
              >
                {card.desc}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

// ----- Section 4: Anatomi Materi (2080-2680) -----
// Desain berbeda: putih bersih + split layout (kiri diagram, kanan 3 poin)
// Nyambung dengan section 3 (alur) → section 4 (hasil alur: keteraturan)
const ANATOMI_POIN = [
  {
    num: "01",
    title: "Identitas",
    desc: "Setiap materi memiliki judul, kategori, jenis, serta keterangan pendukung yang membuatnya mudah dikenali, dibedakan dari materi lain, dan ditelusuri kembali ketika dibutuhkan.",
    color: "#3B82F6",
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d="M9 11l3 3L22 4M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
  },
  {
    num: "02",
    title: "Konteks",
    desc: "Materi dilengkapi dengan keterangan asal, waktu, dan latar belakangnya, sehingga makna informasi tetap utuh dan dapat dipahami secara benar ketika dibaca kembali di kemudian hari.",
    color: "#10B981",
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="2"/>
        <path d="M12 8v4l3 2" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
        <path d="M12 6v0M16 12v0M12 18v0M8 12v0" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    ),
  },
  {
    num: "03",
    title: "Keterkaitan",
    desc: "Setiap materi dapat terhubung dengan materi lain yang memiliki kesamaan pembahasan, bidang, atau konteks, sehingga pengetahuan yang dihimpun tidak berdiri sendiri dan saling melengkapi.",
    color: "#F59E0B",
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <circle cx="6" cy="6" r="3" stroke="currentColor" strokeWidth="2"/>
        <circle cx="18" cy="6" r="3" stroke="currentColor" strokeWidth="2"/>
        <circle cx="12" cy="18" r="3" stroke="currentColor" strokeWidth="2"/>
        <path d="M8.5 7.5L11 16M15.5 7.5L13 16M9 6h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    ),
  },
];

function SectionAnatomiMateri() {
  return (
    <section
      style={{
        position: "relative",
        height: "780px",
        padding: "40px 80px 10px",
        background: "white",
        overflow: "hidden",
      }}
    >
      {/* Subtle decorative grid background */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundImage:
            "linear-gradient(rgba(11, 110, 106, 0.04) 1px, transparent 1px), linear-gradient(90deg, rgba(11, 110, 106, 0.04) 1px, transparent 1px)",
          backgroundSize: "40px 40px",
          pointerEvents: "none",
        }}
      />

      {/* Layout: kiri diagram, kanan teks + poin */}
      <div
        style={{
          position: "relative",
          display: "flex",
          gap: "60px",
          alignItems: "flex-start",
          height: "100%",
        }}
      >
        {/* ===== KIRI: Diagram "Anatomi Materi" ===== */}
        <div style={{ flexShrink: 0, width: "500px", position: "relative" }}>
          {/* Judul kecil di atas diagram (ini label diagram, bukan section heading) */}
          <div
            style={{
              fontSize: "11px",
              fontWeight: 700,
              color: "#0B6E6A",
              letterSpacing: "1.5px",
              marginBottom: "20px",
              textAlign: "center",
            }}
          >
            ANATOMI MATERI
          </div>

          {/* Diagram: layout grid simetris, rapi, tidak ketabrak */}
          <div
            style={{
              position: "relative",
              width: "500px",
              height: "460px",
              display: "grid",
              gridTemplateColumns: "1fr 1fr 1fr",
              gridTemplateRows: "auto 1fr auto",
              gap: "20px 16px",
              alignItems: "center",
              justifyItems: "center",
            }}
          >
            {/* Row 1: Judul (left), spacer (center), Kategori (right) */}
            <ChipElement
              gridItem
              color="#3B82F6"
              label="Judul"
              desc="Apa nama materi ini?"
              example="cth: Studi Media Sosial 2024"
            />
            <div />
            <ChipElement
              gridItem
              color="#10B981"
              label="Kategori"
              desc="Masuk bidang apa?"
              example="cth: Media Digital"
            />

            {/* Row 2: Jenis (left), Materi center box, Konteks (right) */}
            <ChipElement
              gridItem
              color="#F59E0B"
              label="Jenis"
              desc="Bentuknya apa?"
              example="cth: Hasil Riset"
            />
            {/* Center box: "Satu Materi" */}
            <div
              style={{
                width: "140px",
                height: "90px",
                background: "linear-gradient(135deg, #0B6E6A 0%, #0B3B3A 100%)",
                borderRadius: "16px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexDirection: "column",
                color: "white",
                boxShadow: "0 8px 24px rgba(11, 59, 58, 0.25)",
                zIndex: 2,
              }}
            >
              <div style={{ fontSize: "10px", opacity: 0.8, letterSpacing: "1px" }}>SATU MATERI</div>
              <div style={{ fontSize: "20px", fontWeight: 800, marginTop: "2px" }}>Materi</div>
            </div>
            <ChipElement
              gridItem
              color="#EF4444"
              label="Konteks"
              desc="Kapan & dari mana?"
              example="cth: Maret 2024, Jakarta"
            />

            {/* Row 3: spacer (left), Sumber (center), spacer (right) */}
            <div />
            <ChipElement
              gridItem
              color="#8B5CF6"
              label="Sumber"
              desc="Datanya dari mana?"
              example="cth: Kuesioner 200 orang"
            />
            <div />

            {/* Connector lines overlay (SVG) */}
            <svg
              width="500"
              height="460"
              style={{ position: "absolute", top: 0, left: 0, zIndex: 1, pointerEvents: "none" }}
            >
              {/* center box approx at center: x=250, y=230 */}
              {/* Lines dari center box edges ke tiap chip */}
              {/* to Judul (top-left) */}
              <line x1="200" y1="195" x2="120" y2="60" stroke="#3B82F6" strokeWidth="2" strokeDasharray="4 4" opacity="0.5"/>
              {/* to Kategori (top-right) */}
              <line x1="300" y1="195" x2="380" y2="60" stroke="#10B981" strokeWidth="2" strokeDasharray="4 4" opacity="0.5"/>
              {/* to Jenis (left) */}
              <line x1="200" y1="230" x2="120" y2="230" stroke="#F59E0B" strokeWidth="2" strokeDasharray="4 4" opacity="0.5"/>
              {/* to Konteks (right) */}
              <line x1="300" y1="230" x2="380" y2="230" stroke="#EF4444" strokeWidth="2" strokeDasharray="4 4" opacity="0.5"/>
              {/* to Sumber (bottom-center) */}
              <line x1="250" y1="275" x2="250" y2="380" stroke="#8B5CF6" strokeWidth="2" strokeDasharray="4 4" opacity="0.5"/>
            </svg>
          </div>
        </div>

        {/* ===== KANAN: Judul + paragraf + 3 poin ===== */}
        <div style={{ flex: 1 }}>
          {/* Judul besar langsung (tanpa badge kecil di atas) */}
          <h2
            style={{
              fontSize: "36px",
              fontWeight: 800,
              color: "#0B3B3A",
              margin: "0 0 18px 0",
              lineHeight: 1.22,
              letterSpacing: "-0.5px",
            }}
          >
            Bukan Sekadar Mengumpulkan — Setiap Materi Punya Tempat dan Konteks
          </h2>
          <p
            style={{
              fontSize: "16px",
              lineHeight: 1.7,
              color: "#1F2937",
              margin: "0 0 16px 0",
              textAlign: "justify",
              textJustify: "inter-word",
            }}
          >
            Setiap materi yang dihimpun memiliki identitas, kategori, dan keterangan yang jelas. Tidak ada materi yang berdiri sendiri tanpa konteks — semuanya terhubung dalam satu sistem yang dapat ditelusuri, sehingga pengetahuan yang tersimpan tetap bermakna bahkan setelah waktu yang lama.
          </p>

          {/* 3 poin dengan icon + nomor — gap diperdekat supaya jarak atas-bawah tidak terlalu jauh */}
          <div style={{ display: "flex", flexDirection: "column", gap: "11px" }}>
            {ANATOMI_POIN.map((poin) => (
              <div
                key={poin.num}
                style={{
                  display: "flex",
                  gap: "16px",
                  alignItems: "flex-start",
                  padding: "14px 18px",
                  background: "#F8FAFA",
                  borderRadius: "12px",
                  border: "1px solid rgba(11, 110, 106, 0.08)",
                }}
              >
                {/* Icon + nomor */}
                <div
                  style={{
                    flexShrink: 0,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    gap: "4px",
                  }}
                >
                  <div
                    style={{
                      width: "44px",
                      height: "44px",
                      borderRadius: "12px",
                      background: `${poin.color}15`,
                      color: poin.color,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {poin.icon}
                  </div>
                  <div
                    style={{
                      fontSize: "11px",
                      fontWeight: 800,
                      color: poin.color,
                    }}
                  >
                    {poin.num}
                  </div>
                </div>
                {/* Text */}
                <div style={{ flex: 1 }}>
                  <h3
                    style={{
                      fontSize: "17px",
                      fontWeight: 700,
                      color: "#0B3B3A",
                      margin: "0 0 4px 0",
                    }}
                  >
                    {poin.title}
                  </h3>
                  <p
                    style={{
                      fontSize: "13.5px",
                      lineHeight: 1.55,
                      color: "#5B7A78",
                      margin: 0,
                      textAlign: "justify",
                      textJustify: "inter-word",
                    }}
                  >
                    {poin.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// Helper component: chip element untuk diagram anatomi
// - gridItem mode: pakai grid layout (no absolute), border normal
// - default mode: absolute positioning (legacy)
function ChipElement({
  x,
  y,
  color,
  label,
  desc,
  example,
  gridItem,
}: {
  x?: number;
  y?: number;
  color: string;
  label: string;
  desc: string;
  example?: string;
  gridItem?: boolean;
}) {
  const baseStyle: React.CSSProperties = {
    padding: "8px 12px",
    background: "white",
    border: `2px solid ${color}`,
    borderRadius: "10px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.06)",
    minWidth: "140px",
    maxWidth: "160px",
    textAlign: "center",
    zIndex: 3,
  };

  if (gridItem) {
    return (
      <div style={{ ...baseStyle, position: "relative", justifySelf: "center" }}>
        <div style={{ fontSize: "13px", fontWeight: 700, color: color, marginBottom: "2px" }}>
          {label}
        </div>
        <div style={{ fontSize: "10px", color: "#5B7A78", marginBottom: example ? "3px" : "0" }}>
          {desc}
        </div>
        {example && (
          <div
            style={{
              fontSize: "9.5px",
              color: color,
              fontStyle: "italic",
              opacity: 0.85,
              borderTop: "1px dashed rgba(0,0,0,0.1)",
              paddingTop: "3px",
            }}
          >
            {example}
          </div>
        )}
      </div>
    );
  }

  return (
    <div
      style={{
        ...baseStyle,
        position: "absolute",
        left: x ? `${x}px` : undefined,
        top: y ? `${y}px` : undefined,
      }}
    >
      <div style={{ fontSize: "13px", fontWeight: 700, color: color, marginBottom: "2px" }}>
        {label}
      </div>
      <div style={{ fontSize: "10px", color: "#5B7A78", marginBottom: example ? "3px" : "0" }}>
        {desc}
      </div>
      {example && (
        <div
          style={{
            fontSize: "9.5px",
            color: color,
            fontStyle: "italic",
            opacity: 0.85,
            borderTop: "1px dashed rgba(0,0,0,0.1)",
            paddingTop: "3px",
          }}
        >
          {example}
        </div>
      )}
    </div>
  );
}

// ----- Section 5: Manfaat Pengetahuan (3000-3600) -----
// Nyambung dari section 4 (struktur internal 1 materi) → section 5 (manfaat untuk pengunjung)
// Desain berbeda: gradient lembut mint→white + accent geometris + split layout (kiri list, kanan visual)
const MANFAAT_ITEMS = [
  {
    num: "01",
    title: "Sumber Pengetahuan",
    desc: "Tempat memperoleh informasi dan memperluas pemahaman mengenai berbagai bidang yang dihimpun secara terstruktur.",
    color: "#3B82F6",
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2zM22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
      </svg>
    ),
  },
  {
    num: "02",
    title: "Sarana Pembelajaran",
    desc: "Publikasi yang disusun secara jelas membantu proses belajar, dari memahami suatu topik hingga membandingkan berbagai materi.",
    color: "#10B981",
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d="M22 10v6M2 10l10-5 10 5-10 5z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
        <path d="M6 12v5c3 3 9 3 12 0v-5" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
      </svg>
    ),
  },
  {
    num: "03",
    title: "Pusat Dokumentasi",
    desc: "Menjaga berbagai hasil kegiatan dan perkembangan agar tidak hilang atau tersebar tanpa pengelolaan yang jelas.",
    color: "#F59E0B",
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d="M3 7v10a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7M3 7l9-4 9 4M3 7l9 4 9-4" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
      </svg>
    ),
  },
  {
    num: "04",
    title: "Rekam Jejak Perkembangan",
    desc: "Menampilkan perjalanan suatu kegiatan, proyek, atau pembahasan dari waktu ke waktu sehingga perubahan dapat dipahami.",
    color: "#EC4899",
    icon: (
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <path d="M3 12h4l3-9 4 18 3-9h4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
  },
];

function SectionManfaatPengetahuan() {
  return (
    <section
      style={{
        position: "relative",
        height: "560px",
        padding: "0px 80px 20px",
        background: "linear-gradient(135deg, #E8FEFC 0%, #FFFFFF 50%, #F0FAF8 100%)",
        overflow: "hidden",
      }}
    >
      {/* Decorative geometric shapes */}
      <div
        style={{
          position: "absolute",
          top: "60px",
          right: "80px",
          width: "120px",
          height: "120px",
          borderRadius: "24px",
          background: "linear-gradient(135deg, rgba(11, 110, 106, 0.08) 0%, rgba(11, 110, 106, 0.02) 100%)",
          transform: "rotate(15deg)",
        }}
      />
      <div
        style={{
          position: "absolute",
          bottom: "40px",
          left: "40px",
          width: "80px",
          height: "80px",
          borderRadius: "50%",
          background: "rgba(11, 110, 106, 0.05)",
        }}
      />
      <div
        style={{
          position: "absolute",
          top: "40%",
          left: "45%",
          width: "60px",
          height: "60px",
          borderRadius: "12px",
          background: "rgba(11, 110, 106, 0.04)",
          transform: "rotate(-12deg)",
        }}
      />

      {/* Layout: kiri list manfaat, kanan visual card */}
      <div
        style={{
          position: "relative",
          display: "flex",
          gap: "50px",
          alignItems: "center",
          height: "100%",
        }}
      >
        {/* ===== KIRI: Judul + 4 manfaat ===== */}
        <div style={{ flex: 1 }}>
          {/* Judul besar langsung (tanpa badge kecil di atas) */}
          <h2
            style={{
              fontSize: "36px",
              fontWeight: 800,
              color: "#0B3B3A",
              margin: "0 0 14px 0",
              lineHeight: 1.22,
              letterSpacing: "-0.5px",
            }}
          >
            Pengetahuan yang Tidak Hilang, Tetap Terus Dapat Ditelusuri
          </h2>
          <p
            style={{
              fontSize: "15.5px",
              lineHeight: 1.65,
              color: "#1F2937",
              margin: "0 0 24px 0",
              textAlign: "justify",
              textJustify: "inter-word",
            }}
          >
            Keteraturan pengelolaan menghadirkan manfaat yang nyata. Materi yang dihimpun tidak sekadar tersimpan, melainkan dapat dimanfaatkan sebagai sumber pengetahuan, sarana pembelajaran, hingga rekam jejak perkembangan dari waktu ke waktu.
          </p>

          {/* 4 manfaat: 2x2 grid */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: "12px",
            }}
          >
            {MANFAAT_ITEMS.map((item) => (
              <div
                key={item.num}
                style={{
                  display: "flex",
                  gap: "12px",
                  alignItems: "flex-start",
                  padding: "13px 14px",
                  background: "white",
                  borderRadius: "12px",
                  border: "1px solid rgba(11, 110, 106, 0.10)",
                  boxShadow: "0 2px 8px rgba(11, 59, 58, 0.04)",
                }}
              >
                {/* Icon */}
                <div
                  style={{
                    flexShrink: 0,
                    width: "38px",
                    height: "38px",
                    borderRadius: "10px",
                    background: `${item.color}15`,
                    color: item.color,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {item.icon}
                </div>
                {/* Text */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "6px", marginBottom: "3px" }}>
                    <span style={{ fontSize: "10px", fontWeight: 800, color: item.color }}>{item.num}</span>
                    <h3
                      style={{
                        fontSize: "14.5px",
                        fontWeight: 700,
                        color: "#0B3B3A",
                        margin: 0,
                      }}
                    >
                      {item.title}
                    </h3>
                  </div>
                  <p
                    style={{
                      fontSize: "11.5px",
                      lineHeight: 1.5,
                      color: "#5B7A78",
                      margin: 0,
                      textAlign: "justify",
                      textJustify: "inter-word",
                    }}
                  >
                    {item.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ===== KANAN: Visual card dengan quote + stat ===== */}
        <div style={{ flexShrink: 0, width: "380px", position: "relative" }}>
          {/* Decorative accent shape belakang card */}
          <div
            style={{
              position: "absolute",
              top: "-16px",
              right: "-16px",
              width: "100%",
              height: "100%",
              borderRadius: "24px",
              background: "linear-gradient(135deg, #0B6E6A 0%, #0B3B3A 100%)",
              opacity: 0.08,
            }}
          />
          {/* Main card */}
          <div
            style={{
              position: "relative",
              padding: "40px 32px",
              background: "white",
              borderRadius: "24px",
              boxShadow: "0 12px 32px rgba(11, 59, 58, 0.12)",
              border: "1px solid rgba(11, 110, 106, 0.08)",
            }}
          >
            {/* Quote icon */}
            <div
              style={{
                fontSize: "60px",
                lineHeight: 0.6,
                color: "#0B6E6A",
                fontFamily: "Georgia, serif",
                fontWeight: 700,
                marginBottom: "12px",
                opacity: 0.4,
              }}
            >
              &ldquo;
            </div>
            {/* Quote text */}
            <p
              style={{
                fontSize: "17px",
                lineHeight: 1.55,
                color: "#0B3B3A",
                margin: "0 0 24px 0",
                fontWeight: 600,
                fontStyle: "italic",
                textAlign: "justify",
                textJustify: "inter-word",
              }}
            >
              Pengetahuan yang dihimpun secara terstruktur tidak hanya tersimpan, tetapi tetap hidup dan dapat ditelusuri kembali oleh siapa saja, kapan saja.
            </p>

            {/* Divider */}
            <div
              style={{
                height: "1px",
                background: "linear-gradient(90deg, #0B6E6A 0%, transparent 100%)",
                margin: "0 0 20px 0",
                opacity: 0.3,
              }}
            />

            {/* 3 mini stats */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr 1fr",
                gap: "8px",
              }}
            >
              {[
                { num: "4", label: "Bidang Utama" },
                { num: "6", label: "Jenis Materi" },
                { num: "5", label: "Elemen Materi" },
              ].map((stat) => (
                <div key={stat.label} style={{ textAlign: "center" }}>
                  <div
                    style={{
                      fontSize: "26px",
                      fontWeight: 800,
                      color: "#0B6E6A",
                      lineHeight: 1,
                      marginBottom: "4px",
                    }}
                  >
                    {stat.num}
                  </div>
                  <div
                    style={{
                      fontSize: "10px",
                      color: "#5B7A78",
                      fontWeight: 600,
                      letterSpacing: "0.3px",
                    }}
                  >
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ----- Section 6: Penutup (3500-4000) -----
// Dark teal, ajakan telusuri, 2 tombol, footer lengkap dengan copyright
function SectionPenutup({ onOpenSubmenu }: { onOpenSubmenu: (menu: string, submenu: string) => void }) {
  return (
    <section
      style={{
        position: "relative",
        background: "linear-gradient(180deg, #0B3B3A 0%, #0B6E6A 60%, #0B3B3A 100%)",
        overflow: "hidden",
      }}
    >
      {/* Decorative circles */}
      <div
        style={{
          position: "absolute",
          top: "-150px",
          right: "-150px",
          width: "400px",
          height: "400px",
          borderRadius: "50%",
          background: "rgba(129, 246, 239, 0.08)",
        }}
      />
      <div
        style={{
          position: "absolute",
          bottom: "-100px",
          left: "-100px",
          width: "300px",
          height: "300px",
          borderRadius: "50%",
          background: "rgba(129, 246, 239, 0.06)",
        }}
      />
      <div
        style={{
          position: "absolute",
          top: "40%",
          left: "35%",
          width: "150px",
          height: "150px",
          borderRadius: "50%",
          background: "rgba(129, 246, 239, 0.04)",
        }}
      />

      {/* ===== Top: CTA Section (heading + paragraf + 2 tombol) ===== */}
      <div
        style={{
          position: "relative",
          padding: "30px 80px 24px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: "60px",
        }}
      >
        {/* Left: Text */}
        <div style={{ flex: 1, maxWidth: "680px" }}>
          <div
            style={{
              display: "inline-block",
              fontSize: "12px",
              fontWeight: 700,
              color: "#81F6EF",
              letterSpacing: "1.5px",
              marginBottom: "14px",
              padding: "5px 14px",
              background: "rgba(129, 246, 239, 0.1)",
              borderRadius: "999px",
              border: "1px solid rgba(129, 246, 239, 0.25)",
            }}
          >
            MULAI MENTELUSURI
          </div>
          <h2
            style={{
              fontSize: "34px",
              fontWeight: 800,
              color: "white",
              margin: "0 0 16px 0",
              lineHeight: 1.22,
              letterSpacing: "-0.5px",
            }}
          >
            Pengetahuan yang Terhimpun Menanti untuk Ditelusuri
          </h2>
          <p
            style={{
              fontSize: "16px",
              lineHeight: 1.7,
              color: "rgba(255,255,255,0.85)",
              margin: 0,
              textAlign: "justify",
              textJustify: "inter-word",
            }}
          >
            Berbagai hasil riset, kajian, pemikiran, dan dokumentasi telah disusun dalam satu sistem yang terstruktur. Setiap materi memiliki tempat, konteks, dan keterkaitan yang jelas — siap dijelajahi, dipelajari, dan dimanfaatkan kembali kapan saja.
          </p>
        </div>

        {/* Right: 2 buttons */}
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "14px",
            minWidth: "220px",
          }}
        >
          <a
            href="#"
            onClick={(e) => { e.preventDefault(); onOpenSubmenu("Publikasi", SUB_MENUS["Publikasi"].items[0]); }}
            style={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "8px",
              padding: "16px 32px",
              background: "#FDEEC5",
              color: "#0B3B3A",
              border: "2px solid #0B3B3A",
              borderRadius: "999px",
              fontSize: "15px",
              fontWeight: 700,
              textDecoration: "none",
              boxShadow: "0 4px 14px rgba(0,0,0,0.2)",
              letterSpacing: "0.3px",
            }}
          >
            Telusuri →
          </a>
          <a
            href="#"
            onClick={(e) => { e.preventDefault(); onOpenSubmenu("Mengenal INFOTRINK", SUB_MENUS["Mengenal INFOTRINK"].items[0]); }}
            style={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "8px",
              padding: "16px 32px",
              background: "rgba(255,255,255,0.1)",
              color: "white",
              border: "2px solid rgba(255,255,255,0.4)",
              borderRadius: "999px",
              fontSize: "15px",
              fontWeight: 700,
              textDecoration: "none",
              letterSpacing: "0.3px",
            }}
          >
            <BrandText text="Kenali INFOTRINK" />
          </a>
        </div>
      </div>

      {/* ===== Middle: 4 Footer Columns ===== */}
      <div
        style={{
          position: "relative",
          padding: "32px 80px 24px",
          display: "grid",
          gridTemplateColumns: "1.6fr 1fr 1fr 1fr",
          gap: "40px",
        }}
      >
        {/* Column 1: Brand Info */}
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "16px" }}>
            <Image
              src="/slide/logo_icon.png"
              alt="Infotrink"
              width={36}
              height={36}
              style={{ width: "36px", height: "36px", objectFit: "contain", display: "block" }}
              unoptimized
            />
            <Image
              src="/slide/logo_text.png"
              alt="Infotrink"
              width={110}
              height={36}
              style={{ width: "110px", height: "auto", objectFit: "contain", display: "block" }}
              unoptimized
            />
          </div>
          <p
            style={{
              fontSize: "12.5px",
              lineHeight: 1.65,
              color: "rgba(255,255,255,0.7)",
              margin: "0 0 16px 0",
              textAlign: "justify",
              textJustify: "inter-word",
            }}
          >
            Platform penghimpunan, pengelolaan, dan publikasi pengetahuan multibidang yang terstruktur, mudah ditelusuri, serta terus berkembang secara berkelanjutan.
          </p>
          <div style={{ display: "flex", gap: "8px" }}>
            {[
              { label: "M", color: "#3B82F6" },
              { label: "P", color: "#10B981" },
              { label: "Pe", color: "#F59E0B" },
              { label: "L", color: "#8B5CF6" },
            ].map((tag) => (
              <div
                key={tag.label}
                style={{
                  fontSize: "10px",
                  fontWeight: 700,
                  color: "white",
                  background: `${tag.color}40`,
                  border: `1px solid ${tag.color}80`,
                  padding: "3px 10px",
                  borderRadius: "6px",
                  letterSpacing: "0.3px",
                }}
              >
                {tag.label}
              </div>
            ))}
          </div>
        </div>

        {/* Column 2: Navigasi */}
        <div>
          <h4
            style={{
              fontSize: "12px",
              fontWeight: 700,
              color: "#81F6EF",
              letterSpacing: "1px",
              margin: "0 0 16px 0",
            }}
          >
            NAVIGASI
          </h4>
          <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "9px" }}>
            {["Beranda", "Publikasi", "Kategori", "Galeri", "Mengenal INFOTRINK"].map((item) => (
              <li key={item}>
                <a
                  href="#"
                  style={{
                    fontSize: "13px",
                    color: "rgba(255,255,255,0.75)",
                    textDecoration: "none",
                    transition: "color 0.2s ease",
                  }}
                >
                  <BrandText text={item} />
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Column 3: Bidang */}
        <div>
          <h4
            style={{
              fontSize: "12px",
              fontWeight: 700,
              color: "#81F6EF",
              letterSpacing: "1px",
              margin: "0 0 16px 0",
            }}
          >
            BIDANG
          </h4>
          <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "9px" }}>
            {["Media Digital", "Pembangunan", "Personal", "Bidang Lainnya"].map((item) => (
              <li key={item}>
                <a
                  href="#"
                  style={{
                    fontSize: "13px",
                    color: "rgba(255,255,255,0.75)",
                    textDecoration: "none",
                  }}
                >
                  {item}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Column 4: Jenis Materi */}
        <div>
          <h4
            style={{
              fontSize: "12px",
              fontWeight: 700,
              color: "#81F6EF",
              letterSpacing: "1px",
              margin: "0 0 16px 0",
            }}
          >
            JENIS MATERI
          </h4>
          <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "9px" }}>
            {["Artikel Informasi", "Hasil Riset", "Kajian & Analisis", "Laporan", "Data & Referensi", "Gagasan"].map((item) => (
              <li key={item}>
                <a
                  href="#"
                  style={{
                    fontSize: "13px",
                    color: "rgba(255,255,255,0.75)",
                    textDecoration: "none",
                  }}
                >
                  {item}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* ===== Bottom: Copyright Bar ===== */}
      <div
        style={{
          position: "relative",
          padding: "18px 80px",
          background: "rgba(0, 0, 0, 0.25)",
          display: "flex",
          alignItems: "center",
          gap: "28px",
        }}
      >
        {/* Copyright text — kiri */}
        <div
          style={{
            fontSize: "11.5px",
            color: "rgba(255,255,255,0.65)",
            lineHeight: 1.55,
            flex: 1,
            minWidth: 0,
          }}
        >
          © {new Date().getFullYear()} <BrandText text="INFOTRINK" />. Hak cipta dilindungi. Seluruh materi yang dipublikasikan merupakan hasil riset, kajian, pemikiran, dan dokumentasi yang dikelola secara terstruktur untuk kepentingan pengetahuan.
        </div>
        {/* Vertical divider */}
        <div
          style={{
            width: "1px",
            alignSelf: "stretch",
            background: "rgba(129, 246, 239, 0.2)",
            flexShrink: 0,
          }}
        />
        {/* Links — kanan */}
        <div
          style={{
            display: "flex",
            gap: "12px",
            fontSize: "11px",
            color: "rgba(255,255,255,0.5)",
            letterSpacing: "0.3px",
            flexShrink: 0,
            whiteSpace: "nowrap",
          }}
        >
          <span>Syarat &amp; Ketentuan</span>
          <span style={{ opacity: 0.4 }}>•</span>
          <span>Kebijakan Privasi</span>
        </div>
      </div>
    </section>
  );
}

// ============================================================
// SUBMENU PAGE — halaman yang muncul saat klik "Telusuri →" di sub-menu
// Pakai state-based view (bukan route terpisah) karena constraint Next.js
// ============================================================
function SubmenuPage({
  menu,
  submenu,
  onBack,
  onNavClick,
  activeMenu,
  lastActiveMenu,
  closingMenu,
  onClose,
  navItemRefs,
  navPositions,
  selectedArticle,
  onSelectArticle,
  onBackToList,
  onOpenSubmenu,
}: {
  menu: string;
  submenu: string;
  onBack: () => void;
  onNavClick: (item: string, e: React.MouseEvent) => void;
  activeMenu: string | null;
  lastActiveMenu: string | null;
  closingMenu: string | null;
  onClose: () => void;
  navItemRefs: React.RefObject<Record<string, HTMLAnchorElement | null>>;
  navPositions: Record<string, number>;
  selectedArticle: string | null;
  onSelectArticle: (slug: string) => void;
  onBackToList: () => void;
  onOpenSubmenu: (menu: string, submenu: string) => void;
}) {
  const menuData = SUB_MENUS[menu];
  const isArtikelPage = menu === "Publikasi" && submenu === "Artikel Informasi & Penjelasan";
  const isMediaDigitalPage = menu === "Kategori" && submenu === "Media Digital";
  const isPengenalanPage = menu === "Mengenal INFOTRINK" && submenu === "Pengenalan INFOTRINK";
  const isLatarBelakangPage = menu === "Mengenal INFOTRINK" && submenu === "Latar Belakang";
  const isTujuanFungsiPage = menu === "Mengenal INFOTRINK" && submenu === "Tujuan dan Fungsi";
  const isRuangLingkupPage = menu === "Mengenal INFOTRINK" && submenu === "Ruang Lingkup";
  const isPrinsipPengelolaanPage = menu === "Mengenal INFOTRINK" && submenu === "Prinsip Pengelolaan";

  return (
    <div
      data-slide-content
      style={{
        position: "relative",
        width: "1280px",
        minHeight: "720px",
        background:
          "linear-gradient(180deg, #81F6EF 0%, #9CF4ED 22%, #B2FBF6 45%, #CFFCF6 68%, #E1FFFD 88%, #E8FEFC 100%)",
        fontFamily: "'Open Sans', 'Segoe UI', Tahoma, sans-serif",
      }}
    >
      {/* Header dengan logo + nav (sama seperti Beranda) */}
      <SubmenuHeader
        onNavClick={onNavClick}
        activeMenu={activeMenu}
        lastActiveMenu={lastActiveMenu}
        navItemRefs={navItemRefs}
      />

      {/* Overlay menu (jika user klik nav di halaman sub-menu) */}
      {Object.keys(SUB_MENUS).map((menuKey) => (
        <Overlay
          key={menuKey}
          menuKey={menuKey}
          isOpen={activeMenu === menuKey}
          isClosing={closingMenu === menuKey}
          onClose={onClose}
          onOpenSubmenu={onOpenSubmenu}
          navX={navPositions[menuKey] ?? NAV_X[menuKey]}
        />
      ))}

      {/* Breadcrumb + back button */}
      <div
        style={{
          position: "absolute",
          top: "110px",
          left: "70px",
          right: "70px",
          display: "flex",
          alignItems: "center",
          gap: "10px",
          fontSize: "13px",
          color: "#5B7A78",
          fontWeight: 600,
          zIndex: 5,
        }}
      >
        <button
          onClick={selectedArticle ? onBackToList : onBack}
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "5px",
            padding: "6px 14px",
            background: "white",
            color: "#0B6E6A",
            border: "1px solid rgba(11, 110, 106, 0.2)",
            borderRadius: "999px",
            fontSize: "12px",
            fontWeight: 700,
            cursor: "pointer",
            letterSpacing: "0.3px",
          }}
        >
          {selectedArticle ? "← Artikel" : "← Beranda"}
        </button>
        <span style={{ opacity: 0.5 }}>›</span>
        <span><BrandText text={menu} /></span>
        <span style={{ opacity: 0.5 }}>›</span>
        <span style={{ color: "#0B3B3A", fontWeight: 700 }}><BrandText text={submenu} /></span>
      </div>

      {/* Content area */}
      {isArtikelPage && selectedArticle ? (
        <ArticleDetail slug={selectedArticle} />
      ) : isArtikelPage ? (
        <ArticleList onSelectArticle={onSelectArticle} />
      ) : isMediaDigitalPage ? (
        <MediaDigitalPage onOpenSubmenu={onOpenSubmenu} />
      ) : isPengenalanPage ? (
        <PengenalanInfotrinkPage onOpenSubmenu={onOpenSubmenu} />
      ) : isLatarBelakangPage ? (
        <LatarBelakangPage onOpenSubmenu={onOpenSubmenu} />
      ) : isTujuanFungsiPage ? (
        <TujuanFungsiPage onOpenSubmenu={onOpenSubmenu} />
      ) : isRuangLingkupPage ? (
        <RuangLingkupPage onOpenSubmenu={onOpenSubmenu} />
      ) : isPrinsipPengelolaanPage ? (
        <PrinsipPengelolaanPage onOpenSubmenu={onOpenSubmenu} />
      ) : null}
    </div>
  );
}

// Header untuk SubmenuPage (logo + nav, sama seperti Beranda tapi tanpa scroll sections)
function SubmenuHeader({
  onNavClick,
  activeMenu,
  lastActiveMenu,
  navItemRefs,
}: {
  onNavClick: (item: string, e: React.MouseEvent) => void;
  activeMenu: string | null;
  lastActiveMenu: string | null;
  navItemRefs: React.RefObject<Record<string, HTMLAnchorElement | null>>;
}) {
  return (
    <header
      style={{
        position: "absolute",
        top: "32px",
        left: "70px",
        right: "70px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        zIndex: 10,
      }}
    >
      {/* Logo group */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "12px",
          padding: "8px 22px 8px 10px",
          background: "rgba(255, 255, 255, 0.85)",
          backdropFilter: "blur(10px)",
          borderRadius: "999px",
          boxShadow: "0 4px 16px rgba(11, 59, 58, 0.12)",
          border: "1px solid rgba(255, 255, 255, 0.6)",
        }}
      >
        <Image
          src="/slide/logo_icon.png"
          alt="Infotrink logo"
          width={42}
          height={42}
          style={{ width: "42px", height: "42px", objectFit: "contain", display: "block", filter: "drop-shadow(0 2px 4px rgba(11, 59, 58, 0.15))" }}
          unoptimized
        />
        <Image
          src="/slide/logo_text.png"
          alt="Infotrink"
          width={125}
          height={40}
          style={{ width: "125px", height: "auto", objectFit: "contain", display: "block" }}
          unoptimized
        />
      </div>

      {/* Navigation menu */}
      <nav
        style={{
          display: "flex",
          alignItems: "center",
          gap: "32px",
          padding: "10px 26px",
          background: "rgba(255, 255, 255, 0.55)",
          backdropFilter: "blur(8px)",
          borderRadius: "999px",
          boxShadow: "0 4px 16px rgba(11, 59, 58, 0.10)",
        }}
      >
        {NAV_ITEMS.map((item) => {
          const isActive = activeMenu === item;
          const isLastActive = lastActiveMenu === item && !activeMenu;
          const isDefaultBeranda = item === "Beranda" && !activeMenu && !lastActiveMenu;
          const isHighlighted = isActive || isLastActive || isDefaultBeranda;
          return (
            <a
              key={item}
              ref={(el) => { navItemRefs.current[item] = el; }}
              href="#"
              onClick={(e) => onNavClick(item, e)}
              style={{
                fontFamily: "'Open Sans', sans-serif",
                fontSize: "15px",
                fontWeight: isHighlighted ? 700 : 600,
                color: isHighlighted ? "#0B6E6A" : "#0B3B3A",
                textDecoration: "none",
                padding: "4px 0",
                borderBottom: isHighlighted ? "2px solid #0B6E6A" : "2px solid transparent",
                transition: "all 0.2s ease",
                letterSpacing: "0.2px",
                cursor: "pointer",
              }}
            >
              <BrandText text={item} />
            </a>
          );
        })}
      </nav>
    </header>
  );
}


// ============================================================

// ============================================================
// ARTICLE LIST — daftar artikel dengan tombol Download Dokumen
// ============================================================
const ARTICLES = [
  {
    slug: "memahami-perkembangan-informasi",
    title: "Memahami Perkembangan Informasi dan Pengetahuan dalam Membentuk Wawasan di Era Modern",
    excerpt: "Artikel ini menjelaskan bagaimana informasi berkembang, bagaimana informasi diolah menjadi pengetahuan, serta peran literasi informasi dalam membentuk wawasan di era modern.",
    category: "Pengetahuan Umum",
    date: "7 November 2026",
    author: "Muhammad Fajri Munawar",
    fileSize: "49 KB",
    color: "#0B6E6A",
  },
];

function ArticleList({ onSelectArticle }: { onSelectArticle: (slug: string) => void }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  const filteredArticles = ARTICLES.filter((a) =>
    a.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalPages = Math.max(1, Math.ceil(filteredArticles.length / itemsPerPage));
  const safePage = Math.min(currentPage, totalPages);
  const startIndex = (safePage - 1) * itemsPerPage;
  const pageArticles = filteredArticles.slice(startIndex, startIndex + itemsPerPage);

  return (
    <div style={{ padding: "165px 70px 60px" }}>
      <div style={{ marginBottom: "28px" }}>
        <h1 style={{ fontSize: "32px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 8px 0", letterSpacing: "-0.5px" }}>
          Artikel Informasi &amp; Penjelasan
        </h1>
        <p style={{ fontSize: "15px", color: "#5B7A78", margin: "0 0 20px 0", lineHeight: 1.7, textAlign: "justify", textJustify: "inter-word" }}>
          Kumpulan tulisan yang menjelaskan berbagai topik, konsep, proses, dan perkembangan dengan bahasa yang terarah, sistematis, dan mudah dipahami. Setiap artikel disusun untuk memberikan pemahaman yang jelas, mulai dari pengertian dasar hingga pembahasan yang lebih mendalam, agar pembaca dapat mengikuti alur penjelasan secara runtut dan menyeluruh.
        </p>

        {/* Search bar + pagination di kanan */}
        <div style={{ display: "flex", alignItems: "center", gap: "16px", flexWrap: "wrap" }}>
          <div style={{ position: "relative", flex: 1, minWidth: "280px", maxWidth: "500px" }}>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
              placeholder="Cari artikel berdasarkan judul, kategori, atau isi..."
              style={{
                width: "100%",
                padding: "12px 16px 12px 44px",
                fontSize: "14px",
                border: "1.5px solid rgba(11, 110, 106, 0.2)",
                borderRadius: "999px",
                outline: "none",
                background: "white",
                color: "#0B3B3A",
                fontFamily: "'Open Sans', sans-serif",
                boxSizing: "border-box",
              }}
              onFocus={(e) => { e.target.style.borderColor = "#0B6E6A"; }}
              onBlur={(e) => { e.target.style.borderColor = "rgba(11, 110, 106, 0.2)"; }}
            />
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
              style={{ position: "absolute", left: "16px", top: "50%", transform: "translateY(-50%)", color: "#9CB3B0", pointerEvents: "none" }}>
              <circle cx="11" cy="11" r="8" stroke="currentColor" strokeWidth="2"/>
              <path d="M21 21l-4.3-4.3" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </div>

          {/* Pagination di kanan */}
          {totalPages > 1 && (
            <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              {/* Prev button */}
              <button
                onClick={() => setCurrentPage(Math.max(1, safePage - 1))}
                disabled={safePage === 1}
                style={{
                  width: "36px", height: "36px", borderRadius: "8px", border: "1px solid rgba(11, 110, 106, 0.2)",
                  background: safePage === 1 ? "#F0FAF8" : "white", color: safePage === 1 ? "#C5D5D3" : "#0B6E6A",
                  cursor: safePage === 1 ? "default" : "pointer", fontSize: "14px", fontWeight: 700,
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}
              >
                ‹
              </button>
              {/* Page numbers */}
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  style={{
                    width: "36px", height: "36px", borderRadius: "8px",
                    border: page === safePage ? "none" : "1px solid rgba(11, 110, 106, 0.2)",
                    background: page === safePage ? "#0B6E6A" : "white",
                    color: page === safePage ? "white" : "#0B6E6A",
                    cursor: "pointer", fontSize: "14px", fontWeight: 700,
                    display: "flex", alignItems: "center", justifyContent: "center",
                  }}
                >
                  {page}
                </button>
              ))}
              {/* Next button */}
              <button
                onClick={() => setCurrentPage(Math.min(totalPages, safePage + 1))}
                disabled={safePage === totalPages}
                style={{
                  width: "36px", height: "36px", borderRadius: "8px", border: "1px solid rgba(11, 110, 106, 0.2)",
                  background: safePage === totalPages ? "#F0FAF8" : "white", color: safePage === totalPages ? "#C5D5D3" : "#0B6E6A",
                  cursor: safePage === totalPages ? "default" : "pointer", fontSize: "14px", fontWeight: 700,
                  display: "flex", alignItems: "center", justifyContent: "center",
                }}
              >
                ›
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Results count */}
      {searchQuery && (
        <div style={{ fontSize: "13px", color: "#5B7A78", marginBottom: "16px" }}>
          {filteredArticles.length > 0
            ? `Ditemukan ${filteredArticles.length} artikel untuk "${searchQuery}"`
            : `Tidak ada artikel yang cocok untuk "${searchQuery}"`}
        </div>
      )}

      {/* Article cards */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: "24px", maxWidth: "900px" }}>
        {pageArticles.map((article) => (
          <div
            key={article.slug}
            onClick={() => onSelectArticle(article.slug)}
            style={{
              background: "white",
              borderRadius: "14px",
              overflow: "hidden",
              boxShadow: "0 4px 16px rgba(11, 59, 58, 0.08)",
              border: "1px solid rgba(11, 110, 106, 0.08)",
              cursor: "pointer",
              display: "flex",
              gap: "0",
              transition: "transform 0.2s ease, box-shadow 0.2s ease",
            }}
            onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 8px 24px rgba(11, 59, 58, 0.15)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "0 4px 16px rgba(11, 59, 58, 0.08)"; }}
          >
            <div style={{ width: "200px", minHeight: "160px", flexShrink: 0, overflow: "hidden" }}>
              <Image src="/slide/office_photo.png" alt={article.title} width={200} height={160}
                style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center", display: "block" }} unoptimized />
            </div>
            <div style={{ padding: "20px 24px", flex: 1, display: "flex", flexDirection: "column" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "8px" }}>
                <span style={{ fontSize: "11px", fontWeight: 700, color: article.color, background: `${article.color}15`, padding: "3px 10px", borderRadius: "6px" }}>
                  {article.category}
                </span>
                <span style={{ fontSize: "11px", color: "#9CB3B0" }}>{article.date}</span>
              </div>
              <h3 style={{ fontSize: "17px", fontWeight: 700, color: "#0B3B3A", margin: "0 0 8px 0", lineHeight: 1.35 }}>
                {article.title}
              </h3>
              <p style={{ fontSize: "13px", color: "#5B7A78", margin: "0 0 12px 0", lineHeight: 1.55, flex: 1 }}>
                {article.excerpt}
              </p>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", borderTop: "1px solid rgba(11, 110, 106, 0.08)", paddingTop: "10px" }}>
                <span style={{ fontSize: "11px", color: "#9CB3B0", display: "flex", alignItems: "center", gap: "4px" }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                  PDF • {article.fileSize}
                </span>
                <span style={{ fontSize: "12px", fontWeight: 700, color: article.color }}>Baca Selengkapnya →</span>
              </div>
            </div>
          </div>
        ))}

        {/* No results */}
        {filteredArticles.length === 0 && (
          <div style={{ textAlign: "center", padding: "60px 20px", color: "#9CB3B0" }}>
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" style={{ margin: "0 auto 16px", display: "block", opacity: 0.4 }}>
              <circle cx="11" cy="11" r="8" stroke="currentColor" strokeWidth="1.5"/>
              <path d="M21 21l-4.3-4.3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
            <p style={{ fontSize: "15px", fontWeight: 600, color: "#5B7A78", margin: "0 0 4px 0" }}>
              Artikel tidak ditemukan
            </p>
            <p style={{ fontSize: "13px", color: "#9CB3B0", margin: 0 }}>
              Coba kata kunci lain atau hapus pencarian.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================
// ARTICLE DETAIL — struktur artikel lengkap sesuai pedoman
// ============================================================
function ArticleDetail({ slug }: { slug: string }) {
  return (
    <div style={{ padding: "165px 70px 60px" }}>
      {/* ===== A. IDENTITAS ARTIKEL ===== */}
      <div style={{ maxWidth: "900px", marginBottom: "32px" }}>
        {/* Kategori + tanggal */}
        <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "16px", flexWrap: "wrap" }}>
          <span style={{ fontSize: "12px", fontWeight: 700, color: "#0B6E6A", background: "rgba(11, 110, 106, 0.1)", padding: "5px 14px", borderRadius: "999px" }}>
            Pengetahuan Umum
          </span>
          <span style={{ fontSize: "13px", color: "#5B7A78" }}>7 November 2026</span>
        </div>

        {/* Judul */}
        <h1 style={{ fontSize: "28px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 16px 0", lineHeight: 1.3, letterSpacing: "-0.5px" }}>
          Memahami Perkembangan Informasi dan Pengetahuan dalam Membentuk Wawasan di Era Modern
        </h1>

        {/* Byline — nama penulis */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "20px" }}>
          <div style={{ width: "36px", height: "36px", borderRadius: "50%", background: "#0B6E6A", display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontSize: "14px", fontWeight: 700 }}>
            MF
          </div>
          <div>
            <div style={{ fontSize: "14px", fontWeight: 700, color: "#0B3B3A" }}>Muhammad Fajri Munawar</div>
            <div style={{ fontSize: "12px", color: "#9CB3B0" }}>Penulis</div>
          </div>
        </div>

        {/* ===== B. ABSTRAK ===== */}
        <div style={{ background: "#F0FAF8", borderLeft: "4px solid #0B6E6A", borderRadius: "0 12px 12px 0", padding: "18px 22px", marginBottom: "20px" }}>
          <div style={{ fontSize: "12px", fontWeight: 700, color: "#0B6E6A", letterSpacing: "1px", marginBottom: "8px" }}>ABSTRAK</div>
          <p style={{ fontSize: "14.5px", lineHeight: 1.7, color: "#1F2937", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>
            Perkembangan teknologi telah mengubah cara informasi diproduksi, disebarkan, dan diakses oleh masyarakat. Artikel ini menjelaskan perbedaan data, informasi, dan pengetahuan, menguraikan transformasi digital yang memengaruhi akses informasi, serta membahas proses pengolahan informasi menjadi wawasan. Pembahasan mencakup literasi informasi, kemampuan berpikir kritis, tantangan disinformasi, dan strategi memanfaatkan informasi secara efektif. Artikel ini bertujuan membantu pembaca memahami bahwa akses informasi perlu disertai kemampuan mengevaluasi dan mengolahnya agar dapat membentuk wawasan yang bermakna.
          </p>
          <div style={{ marginTop: "12px", fontSize: "12px", color: "#0B6E6A", fontWeight: 600 }}>
            <span style={{ fontWeight: 700 }}>Kata Kunci:</span> Informasi; Pengetahuan; Wawasan; Literasi Digital; Era Modern
          </div>
        </div>

        {/* Download button — benar-benar bisa download PDF */}
        <a
          href="/artikel-infotrink.pdf"
          download
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "8px",
            padding: "11px 22px",
            background: "#0B6E6A",
            color: "white",
            border: "none",
            borderRadius: "999px",
            fontSize: "14px",
            fontWeight: 700,
            cursor: "pointer",
            textDecoration: "none",
            letterSpacing: "0.3px",
            boxShadow: "0 4px 12px rgba(11, 110, 106, 0.25)",
          }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          Download Dokumen (PDF)
        </a>
        <span style={{ fontSize: "12px", color: "#9CB3B0", marginLeft: "12px" }}>49 KB</span>
      </div>

      {/* ===== FEATURED IMAGE ===== */}
      <div style={{ width: "100%", maxWidth: "900px", height: "280px", borderRadius: "14px", overflow: "hidden", marginBottom: "8px", boxShadow: "0 4px 16px rgba(11, 59, 58, 0.12)" }}>
        <Image src="/slide/office_photo.png" alt="Perkembangan informasi di era modern" width={900} height={280}
          style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center", display: "block" }} unoptimized />
      </div>
      <p style={{ fontSize: "12px", color: "#9CB3B0", textAlign: "center", margin: "0 0 36px 0", fontStyle: "italic", maxWidth: "900px" }}>
        Gambar 1. Suasana kerja kolaboratif yang merepresentasikan pertukaran informasi di era modern.
      </p>

      {/* ===== C. PENDAHULUAN ===== */}
      <div style={{ maxWidth: "900px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: "#0B3B3A", margin: "0 0 14px 0", lineHeight: 1.3, borderLeft: "4px solid #0B6E6A", paddingLeft: "14px" }}>
          Pendahuluan
        </h2>
        <p style={{ fontSize: "15.5px", lineHeight: 1.8, color: "#1F2937", margin: "0 0 16px 0", textAlign: "justify", textJustify: "inter-word" }}>
          Perkembangan teknologi komunikasi telah mengubah secara mendasar cara masyarakat memperoleh, menyebarkan, dan memanfaatkan informasi. Pada masa lalu, informasi tersebar melalui tulisan tangan, media cetak, radio, dan televisi. Saat ini, internet dan platform digital memungkinkan informasi menyebar dalam hitungan detik ke seluruh penjuru dunia.
        </p>
        <p style={{ fontSize: "15.5px", lineHeight: 1.8, color: "#1F2937", margin: "0 0 16px 0", textAlign: "justify", textJustify: "inter-word" }}>
          Namun, kemudahan akses informasi tidak otomatis menghasilkan pengetahuan. Banyaknya informasi yang beredar justru menimbulkan tantangan baru: bagaimana memilah informasi yang berkualitas dari yang tidak terpercaya, bagaimana mengolah informasi menjadi pemahaman, dan bagaimana memanfaatkan pengetahuan untuk membentuk wawasan yang bermakna.
        </p>
        <p style={{ fontSize: "15.5px", lineHeight: 1.8, color: "#1F2937", margin: "0 0 16px 0", textAlign: "justify", textJustify: "inter-word" }}>
          Artikel ini bertujuan menjelaskan perkembangan informasi dari masa ke masa, membedakan data, informasi, dan pengetahuan, serta membahas bagaimana literasi informasi dan kemampuan berpikir kritis dapat membantu pembentukan wawasan di era modern. Ruang lingkup pembahasan mencakup konsep dasar informasi, transformasi digital, proses pembentukan pengetahuan, literasi informasi, tantangan disinformasi, dan strategi pemanfaatan informasi.
        </p>

        {/* ===== D. PEMBAHASAN UTAMA ===== */}
        {/* Sub 1 */}
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: "#0B3B3A", margin: "32px 0 14px 0", lineHeight: 1.3, borderLeft: "4px solid #0B6E6A", paddingLeft: "14px" }}>
          1. Data, Informasi, dan Pengetahuan
        </h2>
        <p style={{ fontSize: "15.5px", lineHeight: 1.8, color: "#1F2937", margin: "0 0 16px 0", textAlign: "justify", textJustify: "inter-word" }}>
          Data adalah fakta atau angka mentah yang belum memiliki konteks. Informasi adalah data yang telah diberi makna melalui pengorganisasian dan interpretasi. Pengetahuan adalah pemahaman yang diperoleh dari pengolahan informasi melalui pengalaman, analisis, dan penalaran. Ketiganya saling berkaitan: data menjadi informasi ketika diberi konteks, dan informasi menjadi pengetahuan ketika dipahami dan diinternalisasi.
        </p>

        {/* Tabel perbandingan */}
        <div style={{ margin: "24px 0", overflow: "hidden", borderRadius: "12px", border: "1px solid rgba(11, 110, 106, 0.12)" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "13.5px" }}>
            <thead>
              <tr style={{ background: "#0B6E6A" }}>
                <th style={{ padding: "12px 16px", textAlign: "left", color: "white", fontWeight: 700 }}>Konsep</th>
                <th style={{ padding: "12px 16px", textAlign: "left", color: "white", fontWeight: 700 }}>Definisi</th>
                <th style={{ padding: "12px 16px", textAlign: "left", color: "white", fontWeight: 700 }}>Contoh</th>
              </tr>
            </thead>
            <tbody>
              <tr style={{ background: "white" }}>
                <td style={{ padding: "11px 16px", fontWeight: 700, color: "#0B6E6A" }}>Data</td>
                <td style={{ padding: "11px 16px", color: "#1F2937" }}>Fakta mentah tanpa konteks</td>
                <td style={{ padding: "11px 16px", color: "#1F2937" }}>Angka 37°C</td>
              </tr>
              <tr style={{ background: "#F8FAFA" }}>
                <td style={{ padding: "11px 16px", fontWeight: 700, color: "#0B6E6A" }}>Informasi</td>
                <td style={{ padding: "11px 16px", color: "#1F2937" }}>Data yang diberi makna</td>
                <td style={{ padding: "11px 16px", color: "#1F2937" }}>Suhu tubuh 37°C adalah normal</td>
              </tr>
              <tr style={{ background: "white" }}>
                <td style={{ padding: "11px 16px", fontWeight: 700, color: "#0B6E6A" }}>Pengetahuan</td>
                <td style={{ padding: "11px 16px", color: "#1F2937" }}>Pemahaman dari informasi</td>
                <td style={{ padding: "11px 16px", color: "#1F2937" }}>Suhu di atas 38°C menandakan demam</td>
              </tr>
            </tbody>
          </table>
        </div>
        <p style={{ fontSize: "12px", color: "#9CB3B0", margin: "0 0 24px 0", fontStyle: "italic" }}>
          Tabel 1. Perbandingan data, informasi, dan pengetahuan.
        </p>

        {/* Sub 2 */}
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: "#0B3B3A", margin: "32px 0 14px 0", lineHeight: 1.3, borderLeft: "4px solid #0B6E6A", paddingLeft: "14px" }}>
          2. Perkembangan Penyebaran Informasi dari Masa ke Masa
        </h2>
        <p style={{ fontSize: "15.5px", lineHeight: 1.8, color: "#1F2937", margin: "0 0 16px 0", textAlign: "justify", textJustify: "inter-word" }}>
          Penyebaran informasi telah mengalami perubahan signifikan. Pada masa lalu, informasi disampaikan secara lisan dari orang ke orang. Kemudian muncul tulisan dan dokumentasi yang memungkinkan informasi disimpan. Penemuan mesin cetak memungkinkan reproduksi massal, dan radio serta televisi memperluas jangkauan informasi ke jutaan pendengar dan pemirsa.
        </p>
        <p style={{ fontSize: "15.5px", lineHeight: 1.8, color: "#1F2937", margin: "0 0 16px 0", textAlign: "justify", textJustify: "inter-word" }}>
          Internet mengubah lanskap informasi secara radikal. Platform digital, media sosial, dan mesin pencari membuat informasi dapat diakses oleh siapa saja, kapan saja, di mana saja. Kecepatan penyebaran informasi meningkat drastis, tetapi pada saat yang sama, tantangan verifikasi kebenaran informasi juga menjadi lebih kompleks.
        </p>

        {/* Info box */}
        <div style={{ background: "linear-gradient(135deg, #F0FAF8 0%, #E0F5EF 100%)", border: "1px solid rgba(11, 110, 106, 0.15)", borderLeft: "4px solid #0B6E6A", borderRadius: "12px", padding: "16px 20px", margin: "20px 0" }}>
          <div style={{ fontSize: "12px", fontWeight: 700, color: "#0B6E6A", letterSpacing: "0.5px", marginBottom: "6px" }}>POIN PENTING</div>
          <p style={{ fontSize: "14px", lineHeight: 1.65, color: "#1F2937", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>
            Kemudahan akses informasi bukan jaminan kualitas pengetahuan. Yang membedakan adalah kemampuan untuk memilah, memverifikasi, dan mengolah informasi secara kritis.
          </p>
        </div>

        {/* Sub 3 */}
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: "#0B3B3A", margin: "32px 0 14px 0", lineHeight: 1.3, borderLeft: "4px solid #0B6E6A", paddingLeft: "14px" }}>
          3. Proses Pengolahan Informasi menjadi Pengetahuan
        </h2>
        <p style={{ fontSize: "15.5px", lineHeight: 1.8, color: "#1F2937", margin: "0 0 16px 0", textAlign: "justify", textJustify: "inter-word" }}>
          Informasi tidak otomatis menjadi pengetahuan. Diperlukan proses pengolahan yang melibatkan beberapa tahap: pencarian informasi yang relevan, pemilihan sumber yang terpercaya, pemeriksaan keakuratan, perbandingan antar sumber, interpretasi makna, dan penerapan dalam konteks nyata.
        </p>
        <p style={{ fontSize: "15.5px", lineHeight: 1.8, color: "#1F2937", margin: "0 0 16px 0", textAlign: "justify", textJustify: "inter-word" }}>
          Proses ini memerlukan kemampuan berpikir kritis — yaitu kemampuan untuk tidak menerima informasi begitu saja, tetapi mempertanyakan sumbernya, memeriksa buktinya, dan menilai apakah informasi tersebut konsisten dengan fakta yang diketahui.
        </p>

        {/* Quote */}
        <div style={{ margin: "24px 0", padding: "20px 28px", background: "#0B3B3A", borderRadius: "14px" }}>
          <div style={{ fontSize: "48px", color: "#81F6EF", fontFamily: "Georgia, serif", lineHeight: 0.5, marginBottom: "8px", opacity: 0.5 }}>&ldquo;</div>
          <p style={{ fontSize: "16px", lineHeight: 1.6, color: "white", margin: 0, fontStyle: "italic", fontWeight: 600 }}>
            Banyaknya informasi tidak otomatis menghasilkan pengetahuan. Informasi perlu dipahami, diperiksa, dibandingkan, dan diolah secara kritis agar dapat membentuk wawasan.
          </p>
        </div>

        {/* Sub 4 */}
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: "#0B3B3A", margin: "32px 0 14px 0", lineHeight: 1.3, borderLeft: "4px solid #0B6E6A", paddingLeft: "14px" }}>
          4. Literasi Informasi dan Tantangan di Era Modern
        </h2>
        <p style={{ fontSize: "15.5px", lineHeight: 1.8, color: "#1F2937", margin: "0 0 16px 0", textAlign: "justify", textJustify: "inter-word" }}>
          Literasi informasi adalah kemampuan untuk mencari, mengevaluasi, dan menggunakan informasi secara efektif. Di era modern, tantangan utama meliputi disinformasi (informasi palsu yang sengaja disebar), bias informasi, kelebihan informasi (information overload), serta masalah privasi dan keamanan digital.
        </p>
        <p style={{ fontSize: "15.5px", lineHeight: 1.8, color: "#1F2937", margin: "0 0 16px 0", textAlign: "justify", textJustify: "inter-word" }}>
          Strategi memanfaatkan informasi secara efektif meliputi: menentukan kebutuhan informasi, menggunakan sumber terpercaya, memeriksa keakuratan, membandingkan berbagai sumber, mengembangkan kemampuan analisis, serta menyimpan dan mengelola informasi secara terstruktur.
        </p>

        {/* ===== E. ANALISIS ===== */}
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: "#0B3B3A", margin: "32px 0 14px 0", lineHeight: 1.3, borderLeft: "4px solid #0B6E6A", paddingLeft: "14px" }}>
          Analisis dan Perspektif
        </h2>
        <p style={{ fontSize: "15.5px", lineHeight: 1.8, color: "#1F2937", margin: "0 0 16px 0", textAlign: "justify", textJustify: "inter-word" }}>
          Perkembangan informasi menunjukkan pola yang jelas: semakin cepat akses informasi, semakin tinggi kebutuhan untuk mampu memilah dan memverifikasi. Era digital memberikan kemudahan, tetapi juga tanggung jawab. Masyarakat perlu mengembangkan literasi informasi sebagai keterampilan dasar, sama pentingnya dengan literasi membaca dan menulis.
        </p>
        <p style={{ fontSize: "15.5px", lineHeight: 1.8, color: "#1F2937", margin: "0 0 16px 0", textAlign: "justify", textJustify: "inter-word" }}>
          Hubungan antara informasi, pengetahuan, dan wawasan bersifat berjenjang. Informasi adalah bahan baku, pengetahuan adalah hasil olahan, dan wawasan adalah pemahaman yang terbentuk dari akumulasi pengetahuan. Tanpa kemampuan mengolah informasi, seseorang hanya akan menjadi konsumen pasif, bukan pemilik pengetahuan.
        </p>

        {/* ===== F. KESIMPULAN ===== */}
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: "#0B3B3A", margin: "32px 0 14px 0", lineHeight: 1.3, borderLeft: "4px solid #0B6E6A", paddingLeft: "14px" }}>
          Kesimpulan
        </h2>
        <p style={{ fontSize: "15.5px", lineHeight: 1.8, color: "#1F2937", margin: "0 0 16px 0", textAlign: "justify", textJustify: "inter-word" }}>
          Perkembangan teknologi telah mengubah cara informasi diproduksi dan diakses. Namun, akses yang mudah tidak otomatis menghasilkan pengetahuan. Informasi perlu diolah melalui pencarian, verifikasi, perbandingan, dan analisis kritis. Literasi informasi menjadi keterampilan yang semakin penting di era modern, karena tanpa kemampuan mengevaluasi sumber dan memeriksa kebenaran, masyarakat rentan terhadap disinformasi dan bias.
        </p>

        {/* ===== G. REKOMENDASI ===== */}
        <div style={{ background: "linear-gradient(135deg, #F0FAF8 0%, #E0F5EF 100%)", border: "1px solid rgba(11, 110, 106, 0.15)", borderLeft: "4px solid #0B6E6A", borderRadius: "12px", padding: "16px 20px", margin: "20px 0" }}>
          <div style={{ fontSize: "12px", fontWeight: 700, color: "#0B6E6A", letterSpacing: "0.5px", marginBottom: "8px" }}>REKOMENDASI</div>
          <ul style={{ fontSize: "14px", lineHeight: 1.65, color: "#1F2937", margin: 0, paddingLeft: "18px" }}>
            <li style={{ marginBottom: "6px" }}>Gunakan sumber informasi yang terpercaya dan dapat diverifikasi.</li>
            <li style={{ marginBottom: "6px" }}>Bandingkan informasi dari beberapa sumber sebelum menarik kesimpulan.</li>
            <li style={{ marginBottom: "6px" }}>Kembangkan kemampuan berpikir kritis dalam menilai klaim dan argumen.</li>
            <li style={{ marginBottom: "6px" }}>Kelola informasi secara terstruktur agar mudah ditemukan kembali.</li>
            <li>Bagikan pengetahuan kepada orang lain untuk memperkuat pemahaman bersama.</li>
          </ul>
        </div>

        {/* ===== H. REFERENSI ===== */}
        <h2 style={{ fontSize: "20px", fontWeight: 700, color: "#0B3B3A", margin: "32px 0 14px 0", lineHeight: 1.3, borderLeft: "4px solid #0B6E6A", paddingLeft: "14px" }}>
          Daftar Referensi
        </h2>
        <ol style={{ fontSize: "13.5px", lineHeight: 1.7, color: "#1F2937", margin: "0 0 24px 0", paddingLeft: "20px" }}>
          <li style={{ marginBottom: "8px" }}>Muhammad Fajri Munawar. (2026). <em>Pedoman dan Template Penyusunan Artikel: Artikel Informasi dan Penjelasan.</em> INFOTRINK.</li>
          <li style={{ marginBottom: "8px" }}>American Library Association. (2000). <em>Information Literacy Competency Standards for Higher Education.</em> Chicago: ALA.</li>
          <li style={{ marginBottom: "8px" }}>UNESCO. (2018). <em>Global Framework for Media and Information Literacy.</em> Paris: UNESCO.</li>
          <li style={{ marginBottom: "8px" }}>Lankshear, C., &amp; Knobel, M. (2008). <em>Digital Literacies: Concepts, Policies and Practices.</em> New York: Peter Lang.</li>
        </ol>

        {/* ===== TAGS ===== */}
        <div style={{ marginTop: "24px", paddingTop: "20px", borderTop: "1px solid rgba(11, 110, 106, 0.1)", display: "flex", gap: "8px", flexWrap: "wrap" }}>
          {["Informasi", "Pengetahuan", "Wawasan", "Literasi Digital", "Era Modern"].map((tag) => (
            <span key={tag} style={{ fontSize: "12px", fontWeight: 600, color: "#0B6E6A", background: "rgba(11, 110, 106, 0.08)", padding: "5px 12px", borderRadius: "6px" }}>
              #{tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

// ============================================================
// MEDIA DIGITAL PAGE — halaman bidang Media Digital
// ============================================================


// ============================================================
// MEDIA DIGITAL PAGE — 2 sub-kategori: Media Sosial & Media Chatting
// ============================================================

const PLATFORMS_SOSIAL = [
  { name: "Instagram", color: "#E4405F", bg: "linear-gradient(135deg, #F58529 0%, #DD2A7B 50%, #8134AF 100%)", logo: "/slide/logo-instagram.png" },
  { name: "X (Twitter)", color: "#000000", bg: "#000000", logo: "/slide/logo-x.png" },
  { name: "Facebook", color: "#1877F2", bg: "#1877F2", logo: "/slide/logo-facebook.png" },
  { name: "YouTube", color: "#FF0000", bg: "#FF0000", logo: "/slide/logo-youtube.png" },
  { name: "Threads", color: "#000000", bg: "#000000", logo: "/slide/logo-threads.png" },
  { name: "TikTok", color: "#000000", bg: "#000000", logo: "/slide/logo-tiktok.png" },
  { name: "BeReal", color: "#000000", bg: "#000000", logo: "/slide/logo-bereal.png" },
];

const PLATFORMS_CHATTING = [
  { name: "Telegram", color: "#26A5E4", bg: "#26A5E4", svg: "M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" },
  { name: "WhatsApp", color: "#25D366", bg: "#25D366", svg: "M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z" },
  { name: "WeChat", color: "#07C160", bg: "#07C160", logo: "/slide/logo-wechat.png" },
  // OLD_WETCHAT_REMOVED
  // { name: "WeChat_OLD", color: "#07C160", bg: "#07C160", svg: "M9.5 8.5c-.83 0-1.5.67-1.5 1.5s.67 1.5 1.5 1.5 1.5-.67 1.5-1.5-.67-1.5-1.5-1.5zm5 0c-.83 0-1.5.67-1.5 1.5s.67 1.5 1.5 1.5 1.5-.67 1.5-1.5-.67-1.5-1.5-1.5zM12 2C5.93 2 1 6.03 1 11c0 2.77 1.59 5.23 4.07 6.84.16.1.24.29.2.47l-.5 1.87c-.06.23.16.44.39.37l2.25-.7c.16-.05.33-.03.48.05C9.46 19.67 10.7 20 12 20c6.07 0 11-4.03 11-9s-4.93-9-11-9zm6.5 13c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z" },
  { name: "MS Teams", color: "#5059C9", bg: "#5059C9", logo: "/slide/logo-teams.png" },
  // OLD_TEAMS_REMOVED
  // { name: "MS_Teams_OLD", color: "#5059C9", bg: "#5059C9", svg: "M21.5 4h-2v8h2V4zM9.5 4h-4c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2h4c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 10h-4V6h4v8zM15.5 7h-3c-.55 0-1 .45-1 1v9c0 .55.45 1 1 1h3c.55 0 1-.45 1-1V8c0-.55-.45-1-1-1z" },
  { name: "Discord", color: "#5865F2", bg: "#5865F2", svg: "M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994.021-.041.001-.09-.041-.106a13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128c.126-.094.252-.192.372-.291a.074.074 0 0 1 .078-.01c3.927 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .079.009c.12.099.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.891.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.182 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" },
  { name: "Line", color: "#06C755", bg: "#06C755", logo: "/slide/logo-line.png" },
  // OLD_LINE_REMOVED
  // { name: "Line_OLD", color: "#06C755", bg: "#06C755", svg: "M19.365 9.863c.349 0 .63.285.63.631 0 .345-.281.63-.63.63H17.61v1.125h1.755c.349 0 .63.283.63.63 0 .344-.281.629-.63.629h-2.386c-.281 0-.513-.228-.513-.508V8.517c0-.281.232-.509.513-.509h2.386c.349 0 .63.283.63.629 0 .343-.281.63-.63.63H17.61v1.099h1.755zm-3.855 3.017c0 .27-.232.498-.513.498a.516.516 0 0 1-.442-.27l-2.443-3.865v3.638a.508.508 0 0 1-.513.508.508.508 0 0 1-.513-.508V8.517c0-.281.232-.509.513-.509.199 0 .37.109.458.279l2.461 3.879V8.517c0-.281.232-.509.513-.509.282 0 .513.228.513.509v4.363zm-5.339 0c0 .27-.232.498-.513.498a.508.508 0 0 1-.513-.498V8.517c0-.281.232-.509.513-.509.282 0 .513.228.513.509v4.363zm-2.274.498H4.823c-.282 0-.513-.228-.513-.498V8.517c0-.281.231-.509.513-.509.281 0 .513.228.513.509v3.865h1.561c.281 0 .51.228.51.508a.512.512 0 0 1-.51.498zM12 0C5.373 0 0 4.989 0 11.124c0 4.941 3.521 9.155 8.407 10.555.127.041.255.061.381.061.255 0 .51-.071.732-.213a.86.86 0 0 0 .381-.711V19.13c0-.27.232-.498.513-.498h1.086c.281 0 .513.228.513.498v1.686c0 .27.232.498.513.498s.513-.228.513-.498V19.13c0-.27.232-.498.513-.498h1.086c.281 0 .513.228.513.498v1.686c0 .27.232.498.513.498s.513-.228.513-.498V19.13c0-.27.232-.498.513-.498h1.086c.281 0 .513.228.513.498v1.686c0 .27.232.498.513.498s.513-.228.513-.498V19.13c0-.27.232-.498.513-.498h1.086c.281 0 .513.228.513.498v1.686c0 .27.232.498.513.498z" },
  { name: "Slack", color: "#4A154B", bg: "#4A154B", logo: "/slide/logo-slack.png" },
  // OLD_SLACK_REMOVED
  // { name: "Slack_OLD", color: "#4A154B", bg: "#4A154B", svg: "M5.042 15.165a2.528 2.528 0 0 1-2.52 2.523A2.528 2.528 0 0 1 0 15.165a2.527 2.527 0 0 1 2.522-2.52h2.52v2.52zm1.271 0a2.527 2.527 0 0 1 2.521-2.52A2.527 2.527 0 0 1 11.355 15.165v6.313A2.528 2.528 0 0 1 8.834 24a2.528 2.528 0 0 1-2.521-2.522v-6.313zM8.834 5.042a2.528 2.528 0 0 1-2.521-2.52A2.528 2.528 0 0 1 8.834 0a2.528 2.528 0 0 1 2.521 2.522v2.52H8.834zm0 1.271a2.528 2.528 0 0 1 2.521 2.521 2.528 2.528 0 0 1-2.521 2.521H2.522A2.528 2.528 0 0 1 0 8.834a2.528 2.528 0 0 1 2.522-2.521h6.312zm10.122 2.521a2.528 2.528 0 0 1 2.522-2.521A2.528 2.528 0 0 1 24 8.834a2.528 2.528 0 0 1-2.522 2.521h-2.522V8.834zm-1.268 0a2.528 2.528 0 0 1-2.523 2.521 2.527 2.527 0 0 1-2.52-2.521V2.522A2.527 2.527 0 0 1 15.165 0a2.528 2.528 0 0 1 2.523 2.522v6.312zm-2.523 10.122a2.528 2.528 0 0 1 2.523 2.522A2.528 2.528 0 0 1 15.165 24a2.527 2.527 0 0 1-2.52-2.522v-2.522h2.52zm0-1.268a2.527 2.527 0 0 1-2.52-2.523 2.527 2.527 0 0 1 2.52-2.52h6.313A2.527 2.527 0 0 1 24 15.165a2.527 2.527 0 0 1-2.522 2.523h-6.313z" },
];

function MediaDigitalPage({ onOpenSubmenu }: { onOpenSubmenu: (menu: string, submenu: string) => void }) {
  return (
    <div style={{ padding: "165px 70px 60px" }}>
      {/* ===== HEADER ===== */}
      <div style={{ marginBottom: "40px" }}>
        <h1 style={{ fontSize: "36px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 12px 0", letterSpacing: "-0.5px" }}>Media Digital</h1>
        <p style={{ fontSize: "15.5px", color: "#5B7A78", margin: 0, lineHeight: 1.7, textAlign: "justify", textJustify: "inter-word" }}>
          Ruang yang menampilkan perkembangan dan kreativitas aktivitas digital di berbagai platform media sosial dan media chatting, mulai dari pertumbuhan konten, perubahan tren, hingga dokumentasi setiap platform yang terus berkembang seiring waktu. Kehadiran media sosial dan media chatting saling melengkapi — keduanya menjadi bagian dari ekosistem digital yang menghubungkan komunikasi, ekspresi, dan interaksi dalam kehidupan sehari-hari.
        </p>
      </div>

      {/* ===== SUB-KATEGORI 1: MEDIA SOSIAL ===== */}
      <div style={{ marginBottom: "32px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "20px" }}>
          <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: "linear-gradient(135deg, #F58529 0%, #DD2A7B 50%, #8134AF 100%)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M17 2H7a5 5 0 0 0-5 5v10a5 5 0 0 0 5 5h10a5 5 0 0 0 5-5V7a5 5 0 0 0-5-5zm-5 5.5a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9z" stroke="white" strokeWidth="2"/><circle cx="17.5" cy="6.5" r="1" fill="white"/></svg>
          </div>
          <h2 style={{ fontSize: "22px", fontWeight: 800, color: "#0B3B3A", margin: 0 }}>Media Sosial</h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "16px" }}>
          {PLATFORMS_SOSIAL.map((platform) => (
            <div key={platform.name}
              style={{ background: "white", borderRadius: "16px", padding: "24px 16px", textAlign: "center", cursor: "pointer", border: "1px solid rgba(11, 110, 106, 0.06)", boxShadow: "0 4px 12px rgba(11, 59, 58, 0.06)", transition: "transform 0.2s ease, box-shadow 0.2s ease" }}
              onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.boxShadow = "0 8px 20px rgba(11, 59, 58, 0.12)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "0 4px 12px rgba(11, 59, 58, 0.06)"; }}
            >
              <div style={{ width: "56px", height: "56px", borderRadius: "16px", background: "white", margin: "0 auto 12px", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", border: "2px solid rgba(0,0,0,0.06)" }}>
                <Image src={platform.logo} alt={platform.name} width={36} height={36} style={{ width: "36px", height: "36px", objectFit: "contain", display: "block" }} unoptimized />
              </div>
              <div style={{ fontSize: "12px", fontWeight: 700, color: "#0B3B3A" }}>{platform.name}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ===== SUB-KATEGORI 2: MEDIA CHATTING ===== */}
      <div style={{ marginBottom: "40px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "20px" }}>
          <div style={{ width: "32px", height: "32px", borderRadius: "8px", background: "linear-gradient(135deg, #26A5E4 0%, #25D366 100%)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </div>
          <h2 style={{ fontSize: "22px", fontWeight: 800, color: "#0B3B3A", margin: 0 }}>Media Chatting</h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "16px" }}>
          {PLATFORMS_CHATTING.map((platform) => (
            <div key={platform.name}
              style={{ background: "white", borderRadius: "16px", padding: "24px 16px", textAlign: "center", cursor: "pointer", border: "1px solid rgba(11, 110, 106, 0.06)", boxShadow: "0 4px 12px rgba(11, 59, 58, 0.06)", transition: "transform 0.2s ease, box-shadow 0.2s ease" }}
              onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.boxShadow = "0 8px 20px rgba(11, 59, 58, 0.12)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "0 4px 12px rgba(11, 59, 58, 0.06)"; }}
            >
              <div style={{ width: "56px", height: "56px", borderRadius: "16px", background: platform.logo ? "white" : platform.bg, margin: "0 auto 12px", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", border: platform.logo ? "2px solid rgba(0,0,0,0.06)" : "none" }}>
                {platform.logo ? (
                <Image src={platform.logo} alt={platform.name} width={36} height={36} style={{ width: "36px", height: "36px", objectFit: "contain", display: "block" }} unoptimized />
              ) : (
                <svg width="28" height="28" viewBox="0 0 24 24" fill="white"><path d={platform.svg}/></svg>
              )}
              </div>
              <div style={{ fontSize: "12px", fontWeight: 700, color: "#0B3B3A" }}>{platform.name}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ===== BIDANG TERKAIT ===== */}
      <div style={{ background: "white", borderRadius: "16px", padding: "28px 32px", marginBottom: "32px", border: "1px solid rgba(11, 110, 106, 0.06)", boxShadow: "0 2px 8px rgba(11, 59, 58, 0.04)" }}>
        <h3 style={{ fontSize: "16px", fontWeight: 700, color: "#0B3B3A", margin: "0 0 18px 0" }}>Bidang Lainnya</h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "16px" }}>
          {[
            { name: "Pembangunan", color: "#10B981", svg: "M3 21h18M5 21V7l8-4v18M19 21V11l-6-4" },
            { name: "Personal", color: "#F59E0B", svg: "M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0zM12 14a6 6 0 0 0-6 6v1h12v-1a6 6 0 0 0-6-6z" },
            { name: "Bidang Lainnya", color: "#8B5CF6", svg: "M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z" },
          ].map((bidang) => (
            <div key={bidang.name}
              onClick={() => onOpenSubmenu("Kategori", bidang.name)}
              style={{ display: "flex", alignItems: "center", gap: "14px", padding: "16px", background: "#F8FAFA", borderRadius: "12px", border: "1px solid rgba(11, 110, 106, 0.06)", cursor: "pointer", transition: "transform 0.2s ease" }}
              onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-2px)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; }}
            >
              <div style={{ width: "40px", height: "40px", borderRadius: "10px", background: `${bidang.color}15`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d={bidang.svg} stroke={bidang.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
              </div>
              <div>
                <div style={{ fontSize: "14px", fontWeight: 700, color: "#0B3B3A" }}>{bidang.name}</div>
                <div style={{ fontSize: "11px", color: "#9CB3B0" }}>Lihat materi →</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ===== CTA PENUTUP ===== */}
      <div style={{ background: "linear-gradient(135deg, #0B3B3A 0%, #0B6E6A 100%)", borderRadius: "16px", padding: "32px 36px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "24px", overflow: "hidden", position: "relative" }}>
        <div style={{ position: "absolute", top: "-60px", right: "-60px", width: "200px", height: "200px", borderRadius: "50%", background: "rgba(129, 246, 239, 0.06)" }} />
        <div style={{ position: "relative", flex: 1 }}>
          <h3 style={{ fontSize: "20px", fontWeight: 800, color: "white", margin: "0 0 6px 0" }}>Punya materi Media Digital?</h3>
          <p style={{ fontSize: "14px", color: "rgba(255,255,255,0.8)", margin: 0 }}>Publikasikan riset, kajian, atau dokumentasi media digital di sini.</p>
        </div>
        <button
          onClick={() => onOpenSubmenu("Publikasi", SUB_MENUS["Publikasi"].items[0])}
          style={{ position: "relative", padding: "12px 24px", background: "#FDEEC5", color: "#0B3B3A", border: "2px solid #0B3B3A", borderRadius: "999px", fontSize: "14px", fontWeight: 700, cursor: "pointer", flexShrink: 0 }}
        >
          Publikasikan →
        </button>
      </div>
    </div>
  );
}

// ============================================================
// PENGENALAN INFOTRINK PAGE — halaman perkenalan utama
// ============================================================
function PengenalanInfotrinkPage({ onOpenSubmenu }: { onOpenSubmenu: (menu: string, submenu: string) => void }) {
  // ---- shared style tokens ----
  const H2 = {
    fontSize: "22px",
    fontWeight: 800,
    color: "#0B3B3A",
    margin: "0 0 14px 0",
    lineHeight: 1.3,
    letterSpacing: "-0.2px",
  } as const;
  const H2Bar = (color = "#0B6E6A") => ({
    borderLeft: `4px solid ${color}`,
    paddingLeft: "14px",
  });
  const P = {
    fontSize: "15px",
    lineHeight: 1.85,
    color: "#1F2937",
    margin: "0 0 14px 0",
    textAlign: "justify" as const,
    textJustify: "inter-word" as const,
  };
  const CAP = {
    fontSize: "12px",
    color: "#9CB3B0",
    textAlign: "center" as const,
    margin: "8px 0 28px 0",
    fontStyle: "italic" as const,
  };
  const SECTION_NUM: React.CSSProperties = {
    display: "inline-flex",
    alignItems: "center",
    gap: "8px",
    padding: "4px 12px",
    borderRadius: "999px",
    background: "rgba(11, 110, 106, 0.1)",
    fontSize: "11px",
    fontWeight: 800,
    color: "#0B6E6A",
    letterSpacing: "1px",
    marginBottom: "10px",
  };

  return (
    <div style={{ padding: "165px 70px 60px", color: "#1F2937" }}>
      {/* =====================================================
          0. HERO SECTION — judul + deskripsi panjang + gambar
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h1 style={{ fontSize: "42px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 14px 0", letterSpacing: "-0.8px", lineHeight: 1.1 }}>
          Pengenalan <BrandText text="INFOTRINK" />
        </h1>
        <p style={{ fontSize: "16px", color: "#5B7A78", margin: "0 0 22px 0", lineHeight: 1.8, textAlign: "justify", textJustify: "inter-word" }}>
          Halaman ini mengantarkan pembaca pada pemahaman menyeluruh tentang INFOTRINK sebagai sebuah ruang pengetahuan multibidang. Dari pertanyaan dasar tentang apa itu INFOTRINK, mengapa ia perlu ada, untuk siapa ia diperuntukkan, hingga bagaimana seluruh bagian website ini disusun menjadi satu sistem yang saling terhubung — semuanya dibahas berurutan pada bagian-bagian berikut. Tujuannya tunggal: memberi gambaran utuh sebelum pembaca menyelami materi lebih jauh.
        </p>
        {/* hero image */}
        <div style={{ position: "relative", width: "100%", height: "320px", borderRadius: "16px", overflow: "hidden", boxShadow: "0 12px 32px rgba(11, 59, 58, 0.18)" }}>
          <Image src="/slide/pengenalan-hero.png" alt="Visualisasi pengetahuan yang mengalir ke satu pusat platform" width={1280} height={320} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} unoptimized priority />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(90deg, rgba(11,59,58,0.55) 0%, rgba(11,59,58,0.15) 50%, transparent 100%)" }} />
          <div style={{ position: "absolute", left: "26px", bottom: "22px", right: "26px", color: "white" }}>
            <div style={{ fontSize: "11px", fontWeight: 700, letterSpacing: "2px", color: "#81F6EF", marginBottom: "6px" }}>RUMAH BAGI PENGETAHUAN</div>
            <div style={{ fontSize: "20px", fontWeight: 700, lineHeight: 1.3, maxWidth: "560px" }}>
              Berbagai bidang. Satu tempat. Susunan yang dapat dipelajari dan ditelusuri.
            </div>
          </div>
        </div>
      </div>

      {/* =====================================================
          1. APA ITU INFOTRINK — definisi murni, fokus tunggal
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Apa Itu <BrandText text="INFOTRINK" />?</h2>

        {/* 2-col: big quote card + visual metaphor */}
        <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: "22px", alignItems: "stretch", margin: "14px 0 18px 0" }}>
          {/* left: definition card */}
          <div style={{ background: "linear-gradient(135deg, #0B3B3A 0%, #0B6E6A 100%)", borderRadius: "16px", padding: "28px 30px", color: "white", position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", top: "10px", right: "20px", fontSize: "80px", fontFamily: "Georgia, serif", color: "#81F6EF", opacity: 0.35, lineHeight: 1 }}>&ldquo;</div>
            <div style={{ fontSize: "11px", fontWeight: 800, color: "#81F6EF", letterSpacing: "2px", marginBottom: "14px" }}>DEFINISI SEDERHANA</div>
            <p style={{ fontSize: "19px", lineHeight: 1.55, margin: 0, fontWeight: 500 }}>
              <BrandText text="INFOTRINK" /> adalah sebuah <span style={{ color: "#81F6EF", fontWeight: 700 }}>rumah digital</span> tempat berbagai pengetahuan dari banyak bidang dikumpulkan, disusun, dan disajikan agar mudah dipelajari, ditelusuri, dan dimanfaatkan kembali.
            </p>
            <div style={{ marginTop: "20px", paddingTop: "16px", borderTop: "1px solid rgba(129, 246, 239, 0.25)", display: "flex", gap: "24px" }}>
              <div>
                <div style={{ fontSize: "10px", color: "#81F6EF", letterSpacing: "1.5px", fontWeight: 700 }}>APA</div>
                <div style={{ fontSize: "13px", marginTop: "2px" }}>Sebuah platform</div>
              </div>
              <div>
                <div style={{ fontSize: "10px", color: "#81F6EF", letterSpacing: "1.5px", fontWeight: 700 }}>FUNGSI</div>
                <div style={{ fontSize: "13px", marginTop: "2px" }}>Menyimpan & menyusun</div>
              </div>
              <div>
                <div style={{ fontSize: "10px", color: "#81F6EF", letterSpacing: "1.5px", fontWeight: 700 }}>HASIL</div>
                <div style={{ fontSize: "13px", marginTop: "2px" }}>Pengetahuan terpelajar</div>
              </div>
            </div>
          </div>

          {/* right: 3 elemen dasar */}
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            {[
              { label: "Wadah", desc: "Tempat menampung beragam bentuk tulisan dan catatan.", color: "#3B82F6", svg: "M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" },
              { label: "Susunan", desc: "Pengelompokan agar setiap hal mudah ditemukan kembali.", color: "#10B981", svg: "M4 6h16M4 12h16M4 18h7" },
              { label: "Akses", desc: "Cara bagi pengunjung untuk membaca dan mempelajari.", color: "#F59E0B", svg: "M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" },
            ].map((el) => (
              <div key={el.label} style={{ flex: 1, background: "white", borderRadius: "12px", padding: "14px 16px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 2px 8px rgba(11, 59, 58, 0.04)", display: "flex", alignItems: "center", gap: "12px" }}>
                <div style={{ width: "38px", height: "38px", borderRadius: "10px", background: `${el.color}15`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d={el.svg} stroke={el.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
                <div>
                  <div style={{ fontSize: "14px", fontWeight: 700, color: "#0B3B3A" }}>{el.label}</div>
                  <div style={{ fontSize: "12px", color: "#5B7A78", lineHeight: 1.45 }}>{el.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <p style={P}>
          Kalimat di atas adalah inti yang perlu dipahami terlebih dahulu. Detail seperti sumber materi, jenis publikasi, dan mekanisme pengelolaan akan dijelaskan pada bagian-bagian tersendiri agar tidak menumpuk pada satu titik. Bagian ini hanya menjawab satu pertanyaan: <strong>apa yang dimaksud dengan INFOTRINK</strong>.
        </p>
      </div>

      {/* =====================================================
          2. MENGAPA INFOTRINK ADA — latar kebutuhan
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#3B82F6") }}>Mengapa <BrandText text="INFOTRINK" /> Diperlukan?</h2>
        <p style={P}>
          Pengetahuan saat ini tersebar di banyak tempat: catatan pribadi di aplikasi pesan, dokumen di folder laptop, unggahan di media sosial, hingga laporan yang tersembunyi di arsip lembaga. Tidak ada satu pun tempat yang menyatukannya. Akibatnya, banyak hal yang sebenarnya berharga jadi sulit ditemukan kembali, mudah terlupakan, atau terputus dari konteksnya.
        </p>

        {/* 3 tantangan utama */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "14px", margin: "18px 0 8px 0" }}>
          {[
            { num: "01", title: "Informasi Terpencar", desc: "Catatan, dokumen, dan unggahan tersebar di banyak platform berbeda tanpa satu titik temu.", color: "#EF4444", svg: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" },
            { num: "02", title: "Dokumentasi Hilang", desc: "Proses dan perkembangan suatu kegiatan kerap tidak tercatat, sehingga rekam jejaknya musnah.", color: "#F59E0B", svg: "M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0H5m14 0h2m-16 0H3m2 0V5a2 2 0 012-2h6a2 2 0 012 2v14" },
            { num: "03", title: "Sulit Ditelusuri", desc: "Tanpa pengelompokan yang jelas, mencari kembali satu topik menjadi lambat dan melelahkan.", color: "#8B5CF6", svg: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" },
          ].map((c) => (
            <div key={c.num} style={{ background: "white", borderRadius: "14px", padding: "18px 18px 16px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 12px rgba(11, 59, 58, 0.05)", borderTop: `3px solid ${c.color}` }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "10px" }}>
                <div style={{ width: "34px", height: "34px", borderRadius: "8px", background: `${c.color}15`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d={c.svg} stroke={c.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
                <span style={{ fontSize: "20px", fontWeight: 800, color: c.color, opacity: 0.3 }}>{c.num}</span>
              </div>
              <h4 style={{ fontSize: "14.5px", fontWeight: 700, color: "#0B3B3A", margin: "0 0 6px 0" }}>{c.title}</h4>
              <p style={{ fontSize: "12.5px", lineHeight: 1.55, color: "#5B7A78", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{c.desc}</p>
            </div>
          ))}
        </div>
        <p style={{ ...P, marginTop: "18px" }}>
          <BrandText text="INFOTRINK" /> hadir untuk menjawab ketiga persoalan tersebut: menyatukan yang terpencar, mencatat yang belum terdokumentasi, dan menyusun agar semua mudah ditelusuri. Ini adalah alasan keberadaannya, bukan sekadar deskripsi tampilan.
        </p>
      </div>

      {/* =====================================================
          3. TIGA PILAR NILAI — perkembangan diri/sosial/profesional
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#8B5CF6") }}>Tiga Pilar Nilai <BrandText text="INFOTRINK" /></h2>
        <p style={P}>
          Setiap materi yang dihimpun diarahkan pada tiga jenis perkembangan yang saling melengkapi. Pilar ini menjadi alasan mengapa suatu tulisan layak dimasukkan — bukan sekadar karena ia ada, melainkan karena ia menumbuhkan sesuatu pada pembacanya.
        </p>

        {/* visual: 3 pilar image */}
        <div style={{ margin: "16px 0", width: "100%", height: "200px", borderRadius: "14px", overflow: "hidden", boxShadow: "0 6px 18px rgba(11, 59, 58, 0.1)" }}>
          <Image src="/slide/pengenalan-pilar.png" alt="Tiga pilar nilai INFOTRINK: perkembangan diri, sosial, dan profesional" width={1280} height={200} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center", display: "block" }} unoptimized />
        </div>
        <p style={CAP}>Gambar 1. Tiga pilar yang menjadi arah nilai setiap materi di INFOTRINK.</p>

        {/* 3 pilar cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "16px" }}>
          {[
            {
              tag: "PILAR 1",
              title: "Perkembangan Diri",
              tagline: "Untuk tumbuh sebagai individu",
              desc: "Materi yang membantu pembaca memahami diri, memperluas wawasan, membangun kebiasaan, serta mengasah cara berpikir. Cocok untuk yang sedang belajar hal baru atau menjelajah bidang di luar keahliannya.",
              color: "#3B82F6",
              items: ["Belajar konsep baru", "Membangun kebiasaan & mindzet", "Eksplorasi minat"],
              svg: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z",
            },
            {
              tag: "PILAR 2",
              title: "Perkembangan Sosial",
              tagline: "Untuk berelasi & berkontribusi",
              desc: "Materi yang membantu pembaca memahami orang lain, membangun relasi, berkolaborasi dalam komunitas, dan turut serta dalam perkembangan lingkungannya.",
              color: "#10B981",
              items: ["Komunikasi & relasi", "Kolaborasi komunitas", "Kontribusi sosial"],
              svg: "M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-1.13a4 4 0 10-4-4 4 4 0 004 4zm6 0a3 3 0 10-2-5.24M7 13a3 3 0 10-2 5.24",
            },
            {
              tag: "PILAR 3",
              title: "Perkembangan Profesional",
              tagline: "Untuk memperdalam keahlian",
              desc: "Materi yang membantu pembaca memperdalam bidang kerjanya, membangun rekam jejak, dan berbagi praktik dengan sesama praktisi atau profesional lain.",
              color: "#F59E0B",
              items: ["Pendalaman keahlian", "Rekam jejak kerja", "Praktik & standar industri"],
              svg: "M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z",
            },
          ].map((p) => (
            <div key={p.tag} style={{ background: "white", borderRadius: "16px", overflow: "hidden", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 6px 18px rgba(11, 59, 58, 0.06)" }}>
              <div style={{ background: `linear-gradient(135deg, ${p.color} 0%, ${p.color}cc 100%)`, padding: "18px 20px 14px", color: "white" }}>
                <div style={{ fontSize: "10px", fontWeight: 800, letterSpacing: "2px", opacity: 0.85 }}>{p.tag}</div>
                <div style={{ display: "flex", alignItems: "center", gap: "10px", marginTop: "8px" }}>
                  <div style={{ width: "36px", height: "36px", borderRadius: "10px", background: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d={p.svg} stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  </div>
                  <div>
                    <div style={{ fontSize: "16px", fontWeight: 800 }}>{p.title}</div>
                    <div style={{ fontSize: "11px", opacity: 0.9, marginTop: "1px" }}>{p.tagline}</div>
                  </div>
                </div>
              </div>
              <div style={{ padding: "16px 20px 18px" }}>
                <p style={{ fontSize: "13px", lineHeight: 1.65, color: "#1F2937", margin: "0 0 12px 0", textAlign: "justify", textJustify: "inter-word" }}>{p.desc}</p>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "6px" }}>
                  {p.items.map((it) => (
                    <span key={it} style={{ fontSize: "11px", fontWeight: 600, padding: "4px 10px", background: `${p.color}12`, color: p.color, borderRadius: "999px" }}>{it}</span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
        <p style={{ ...P, marginTop: "16px" }}>
          Tiga pilar di atas berlaku untuk seluruh bidang yang dihimpun. Bidang-bidang tersebut dijelaskan terpisah pada bagian berikutnya agar tidak tertumpuk dengan pembahasan nilai.
        </p>
      </div>

      {/* =====================================================
          4. TIGA BIDANG UTAMA — kategori konkret
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#10B981") }}>Tiga Bidang Utama</h2>
        <p style={P}>
          Pada tahap awal, INFOTRINK menghimpun materi dari tiga bidang yang saling melengkapi. Setiap bidang punya fokus, sumber, dan bentuk publikasi yang berbeda — perbedaan inilah yang menjadi alasan mengapa mereka dipisah, bukan disatukan.
        </p>

        {/* alternating rows */}
        <div style={{ display: "flex", flexDirection: "column", gap: "16px", marginTop: "18px" }}>
          {[
            {
              num: "01", name: "Media Digital", color: "#3B82F6",
              tagline: "Memahami perkembangan media & teknologi digital",
              focus: "Fokus pada kajian dan dokumentasi tentang platform media sosial, aplikasi chatting, tren konten, serta perubahan perilaku yang ditimbulkan oleh teknologi digital.",
              examples: ["Profil & perbandingan platform", "Tren & perubahan perilaku digital", "Dokumentasi praktik media digital"],
              svg: "M9 17v-2m4 2v-4m4 4v-6M2 5l8 4 8-4M2 5v10a2 2 0 002 2h12a2 2 0 002-2V5",
            },
            {
              num: "02", name: "Pembangunan", color: "#10B981",
              tagline: "Mencatat proses, perencanaan, dan hasil pembangunan",
              focus: "Fokus pada informasi mengenai perencanaan, pelaksanaan, hingga dokumentasi proyek pembangunan — baik fisik maupun nonfisik — agar setiap tahap tercatat dan dapat dipelajari.",
              examples: ["Perencanaan & rancangan", "Catatan pelaksanaan proyek", "Laporan hasil & evaluasi"],
              svg: "M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0H5m14 0h2m-16 0H3m11-9l-3 3 2 2 5-5m-5 0V8",
            },
            {
              num: "03", name: "Personal", color: "#F59E0B",
              tagline: "Ruang untuk pemikiran, karya, dan catatan pribadi",
              focus: "Fokus pada hasil pemikiran, gagasan, karya, proyek pribadi, serta catatan perkembangan diri. Bidang ini memberi ruang bagi individu untuk menulis dan mendokumentasikan apa yang sedang ia kerjakan atau pelajari.",
              examples: ["Pemikiran & gagasan", "Proyek & karya pribadi", "Catatan perkembangan diri"],
              svg: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z",
            },
          ].map((b) => (
            <div key={b.num} style={{ display: "grid", gridTemplateColumns: "110px 1fr 220px", gap: "20px", alignItems: "center", background: "white", borderRadius: "16px", padding: "20px 22px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", borderLeft: `4px solid ${b.color}` }}>
              {/* number badge */}
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: "6px" }}>
                <div style={{ width: "70px", height: "70px", borderRadius: "16px", background: `linear-gradient(135deg, ${b.color} 0%, ${b.color}cc 100%)`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none"><path d={b.svg} stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
                <span style={{ fontSize: "11px", fontWeight: 800, color: b.color, letterSpacing: "1.5px" }}>BIDANG {b.num}</span>
              </div>
              {/* text */}
              <div>
                <div style={{ fontSize: "19px", fontWeight: 800, color: "#0B3B3A", marginBottom: "4px" }}>{b.name}</div>
                <div style={{ fontSize: "13px", color: b.color, fontWeight: 600, marginBottom: "8px", fontStyle: "italic" }}>{b.tagline}</div>
                <p style={{ fontSize: "13.5px", lineHeight: 1.65, color: "#1F2937", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{b.focus}</p>
              </div>
              {/* example list */}
              <div style={{ background: `${b.color}08`, borderRadius: "10px", padding: "12px 14px" }}>
                <div style={{ fontSize: "10px", fontWeight: 800, color: b.color, letterSpacing: "1.2px", marginBottom: "8px" }}>CONTOH MATERI</div>
                <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>
                  {b.examples.map((ex) => (
                    <li key={ex} style={{ fontSize: "12px", color: "#1F2937", lineHeight: 1.5, marginBottom: "5px", display: "flex", gap: "6px", alignItems: "flex-start" }}>
                      <span style={{ color: b.color, fontWeight: 800, marginTop: "1px" }}>›</span>
                      <span>{ex}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
        <p style={{ ...P, marginTop: "18px" }}>
          Bidang lain dapat ditambahkan seiring perkembangan, namun tiga bidang di atas menjadi fondasi awal yang sudah punya rancangan struktur dan sumber materi yang jelas.
        </p>
      </div>

      {/* =====================================================
          5. KARAKTERISTIK & IDENTITAS — 4 quadrant
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#F59E0B") }}>Karakteristik &amp; Identitas</h2>
        <p style={P}>
          Empat sifat berikut menjadi pembeda INFOTRINK dari sekadar kumpulan dokumen biasa. Setiap sifat menjawab pertanyaan yang berbeda — bukan mengulang definisi yang sama dengan kata lain.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginTop: "18px" }}>
          {[
            {
              q: "Apa yang dihimpun?",
              a: "Multibidang",
              desc: "Lebih dari satu disiplin. Materi tidak dibatasi pada satu topik agar pembaca dapat menjelajah berbagai bidang dalam satu tempat.",
              color: "#3B82F6",
              svg: "M4 6h16M4 12h16M4 18h16",
            },
            {
              q: "Bagaimana disusun?",
              a: "Terstruktur",
              desc: "Setiap materi dikelompokkan berdasarkan bidang, kategori, dan jenis — bukan ditumpuk dalam satu daftar panjang tanpa urutan.",
              color: "#10B981",
              svg: "M9 17H7a2 2 0 01-2-2V7a2 2 0 012-2h10a2 2 0 012 2v8a2 2 0 01-2 2h-2M9 7h6M9 11h6M9 15h3",
            },
            {
              q: "Bagaimana tumbuh?",
              a: "Berkembang",
              desc: "Materi tidak statis. Setiap tulisan dapat diperbarui, dilengkapi, atau dikoreksi seiring adanya perkembangan baru.",
              color: "#F59E0B",
              svg: "M13 10V3L4 14h7v7l9-11h-7z",
            },
            {
              q: "Bagaimana dicatat?",
              a: "Terdokumentasi",
              desc: "Setiap publikasi meninggalkan jejak. Pembaca dapat mengetahui kapan suatu hal ditulis dan bagaimana ia berkembang.",
              color: "#8B5CF6",
              svg: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z",
            },
          ].map((c) => (
            <div key={c.a} style={{ background: "white", borderRadius: "14px", padding: "22px 24px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", position: "relative", overflow: "hidden" }}>
              <div style={{ position: "absolute", right: "-20px", top: "-20px", width: "100px", height: "100px", borderRadius: "50%", background: `${c.color}08` }} />
              <div style={{ position: "relative", display: "flex", alignItems: "flex-start", gap: "14px" }}>
                <div style={{ width: "44px", height: "44px", borderRadius: "12px", background: `linear-gradient(135deg, ${c.color} 0%, ${c.color}cc 100%)`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d={c.svg} stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: "11px", fontWeight: 700, color: c.color, letterSpacing: "1px", marginBottom: "4px" }}>{c.q}</div>
                  <div style={{ fontSize: "20px", fontWeight: 800, color: "#0B3B3A", marginBottom: "8px" }}>{c.a}</div>
                  <p style={{ fontSize: "13px", lineHeight: 1.65, color: "#1F2937", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{c.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* =====================================================
          6. POSISI INFOTRINK — comparison table with check/cross
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Posisi <BrandText text="INFOTRINK" /></h2>
        <p style={P}>
          Agar tidak keliru, berikut perbandingan INFOTRINK dengan beberapa jenis platform lain yang sering dianggap mirip. Tanda <span style={{ color: "#10B981", fontWeight: 700 }}>✓</span> menandakan cocok, <span style={{ color: "#EF4444", fontWeight: 700 }}>✕</span> menandakan tidak.
        </p>

        <div style={{ margin: "16px 0", overflow: "hidden", borderRadius: "14px", border: "1px solid rgba(11, 110, 106, 0.12)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "13px" }}>
            <thead>
              <tr style={{ background: "linear-gradient(90deg, #0B3B3A 0%, #0B6E6A 100%)" }}>
                <th style={{ padding: "14px 16px", textAlign: "left", color: "white", fontWeight: 700, width: "26%" }}>Aspek</th>
                <th style={{ padding: "14px 16px", textAlign: "center", color: "white", fontWeight: 700, background: "rgba(129, 246, 239, 0.18)" }}><BrandText text="INFOTRINK" /></th>
                <th style={{ padding: "14px 16px", textAlign: "center", color: "white", fontWeight: 700 }}>Portal Berita</th>
                <th style={{ padding: "14px 16px", textAlign: "center", color: "white", fontWeight: 700 }}>Blog Pribadi</th>
                <th style={{ padding: "14px 16px", textAlign: "center", color: "white", fontWeight: 700 }}>Ensiklopedia</th>
              </tr>
            </thead>
            <tbody>
              {[
                ["Multibidang", true, false, false, true],
                ["Terstruktur per kategori", true, true, false, true],
                ["Dapat diperbarui seiring waktu", true, false, true, true],
                ["Menghimpun dokumentasi proses", true, false, false, false],
                ["Fokus pada kedalaman, bukan kecepatan", true, false, true, true],
                ["Berpura-pura netral & akademis", false, false, false, true],
              ].map((row, ri) => (
                <tr key={ri} style={{ background: ri % 2 === 0 ? "white" : "#F4FBFA", borderBottom: "1px solid rgba(11, 110, 106, 0.06)" }}>
                  <td style={{ padding: "12px 16px", color: "#1F2937", fontWeight: 700 }}>{row[0] as string}</td>
                  {(row.slice(1) as boolean[]).map((val, ci) => (
                    <td key={ci} style={{ padding: "12px 16px", textAlign: "center" }}>
                      {val ? (
                        <span style={{ display: "inline-flex", width: "22px", height: "22px", borderRadius: "50%", background: "#10B98115", alignItems: "center", justifyContent: "center", color: "#10B981", fontWeight: 800, fontSize: "13px" }}>✓</span>
                      ) : (
                        <span style={{ display: "inline-flex", width: "22px", height: "22px", borderRadius: "50%", background: "#EF444415", alignItems: "center", justifyContent: "center", color: "#EF4444", fontWeight: 800, fontSize: "13px" }}>✕</span>
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p style={CAP}>Tabel 1. Posisi INFOTRINK dibandingkan tiga jenis platform umum lainnya.</p>
        <p style={P}>
          INFOTRINK bukan berita harian yang mengejar kecepatan, bukan blog yang melayani satu suara, dan bukan pula ensiklopedia yang menuntut kenetralan akademis. Ia adalah wadah penghimpunan yang menempatkan keteraturan, kedalaman, dan keberlanjutan sebagai prioritas.
        </p>
      </div>

      {/* =====================================================
          7. UNTUK SIAPA — audience cards
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#3B82F6") }}>Untuk Siapa <BrandText text="INFOTRINK" />?</h2>
        <p style={P}>
          INFOTRINK tidak ditujukan untuk satu golongan saja. Berikut enam kelompok yang menjadi sasaran utama, beserta alasan mengapa mereka dapat memperoleh manfaat dari platform ini.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "14px", marginTop: "18px" }}>
          {[
            { name: "Pelajar & Mahasiswa", role: "Yang sedang belajar", desc: "Mencari bahan bacaan tambahan untuk memperluas pemahaman di luar materi kuliah.", color: "#3B82F6", svg: "M12 14l9-5-9-5-9 5 9 5zm0 0v6" },
            { name: "Peneliti & Akademisi", role: "Yang meneliti", desc: "Membagikan hasil riset dan kajian kepada pembaca yang lebih luas di luar lingkup kampus.", color: "#10B981", svg: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" },
            { name: "Profesional & Praktisi", role: "Yang bekerja", desc: "Mendokumentasikan pengalaman kerja dan berbagi praktik dengan sesama praktisi.", color: "#F59E0B", svg: "M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01" },
            { name: "Kreator & Penulis", role: "Yang berkarya", desc: "Menerbitkan gagasan, konsep, atau karya yang membutuhkan ruang publikasi yang rapi.", color: "#8B5CF6", svg: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" },
            { name: "Komunitas & Organisasi", role: "Yang berkelompok", desc: "Mengarsipkan kegiatan, dokumentasi proyek, dan catatan perkembangan secara terstruktur.", color: "#EC4899", svg: "M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-1.13a4 4 0 10-4-4 4 4 0 004 4z" },
            { name: "Masyarakat Umum", role: "Yang ingin tahu", desc: "Membaca dan mempelajari hal baru tanpa harus menjadi bagian dari lembaga tertentu.", color: "#0EA5E9", svg: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" },
          ].map((a) => (
            <div key={a.name} style={{ background: "white", borderRadius: "14px", padding: "18px 18px 16px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 12px rgba(11, 59, 58, 0.05)", display: "flex", flexDirection: "column" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "10px" }}>
                <div style={{ width: "40px", height: "40px", borderRadius: "50%", background: `linear-gradient(135deg, ${a.color} 0%, ${a.color}cc 100%)`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d={a.svg} stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
                <div>
                  <div style={{ fontSize: "14px", fontWeight: 700, color: "#0B3B3A", lineHeight: 1.2 }}>{a.name}</div>
                  <div style={{ fontSize: "11px", color: a.color, fontWeight: 600, marginTop: "2px" }}>{a.role}</div>
                </div>
              </div>
              <p style={{ fontSize: "12.5px", lineHeight: 1.6, color: "#5B7A78", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{a.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* =====================================================
          8. VISI & MISI
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Visi &amp; Misi</h2>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.5fr", gap: "18px", marginTop: "16px" }}>
          {/* visi */}
          <div style={{ background: "linear-gradient(135deg, #0B3B3A 0%, #0B6E6A 100%)", borderRadius: "16px", padding: "26px 28px", color: "white", position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", top: "20px", right: "20px", width: "60px", height: "60px", borderRadius: "50%", border: "2px solid rgba(129, 246, 239, 0.25)" }} />
            <div style={{ position: "absolute", top: "32px", right: "32px", width: "36px", height: "36px", borderRadius: "50%", border: "2px solid rgba(129, 246, 239, 0.4)" }} />
            <div style={{ position: "relative" }}>
              <div style={{ fontSize: "11px", fontWeight: 800, color: "#81F6EF", letterSpacing: "2px", marginBottom: "14px" }}>VISI</div>
              <p style={{ fontSize: "17px", lineHeight: 1.5, margin: 0, fontWeight: 600 }}>
                Menjadi ruang pengetahuan multibidang yang tertata, hidup, dan berkelanjutan — tempat berbagai kalangan dapat belajar, menulis, dan menelusuri tanpa harus berpindah-pindah tempat.
              </p>
            </div>
          </div>
          {/* misi */}
          <div style={{ background: "white", borderRadius: "16px", padding: "24px 28px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)" }}>
            <div style={{ fontSize: "11px", fontWeight: 800, color: "#0B6E6A", letterSpacing: "2px", marginBottom: "14px" }}>MISI</div>
            <ol style={{ margin: 0, paddingLeft: "22px", fontSize: "13.5px", lineHeight: 1.75, color: "#1F2937" }}>
              <li style={{ marginBottom: "8px" }}><strong>Menyatukan</strong> materi dari berbagai bidang ke dalam satu sistem pengelolaan.</li>
              <li style={{ marginBottom: "8px" }}><strong>Mengelompokkan</strong> setiap publikasi agar mudah ditemukan kembali.</li>
              <li style={{ marginBottom: "8px" }}><strong>Menyajikan</strong> informasi dengan konteks yang jelas dan bahasa yang dapat dipahami.</li>
              <li style={{ marginBottom: "8px" }}><strong>Menjaga</strong> rekam jejak setiap tulisan agar perkembangannya dapat ditelusuri.</li>
              <li><strong>Membuka</strong> ruang bagi pembaca dan penulis untuk tumbuh bersama.</li>
            </ol>
          </div>
        </div>
      </div>

      {/* =====================================================
          9. STRUKTUR WEBSITE — visual SVG tree diagram
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#8B5CF6") }}>Struktur Website <BrandText text="INFOTRINK" /></h2>
        <p style={P}>
          Untuk memudahkan navigasi, INFOTRINK dibagi menjadi lima bagian utama. Setiap bagian punya peran yang berbeda — tidak saling mengulang — sehingga pengunjung tahu harus pergi ke mana tergantung pada tujuannya.
        </p>

        {/* visual tree */}
        <div style={{ background: "white", borderRadius: "16px", padding: "30px 26px 24px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", margin: "16px 0" }}>
          {/* root */}
          <div style={{ display: "flex", justifyContent: "center", marginBottom: "6px" }}>
            <div style={{ background: "linear-gradient(135deg, #0B3B3A 0%, #0B6E6A 100%)", color: "white", padding: "12px 32px", borderRadius: "12px", fontSize: "16px", fontWeight: 800, letterSpacing: "1px", boxShadow: "0 4px 14px rgba(11, 110, 106, 0.3)" }}>
              <BrandText text="INFOTRINK" />
            </div>
          </div>
          {/* connector */}
          <svg width="100%" height="40" viewBox="0 0 1140 40" preserveAspectRatio="none" style={{ display: "block" }}>
            <line x1="570" y1="0" x2="570" y2="14" stroke="#0B6E6A" strokeWidth="2" />
            <line x1="114" y1="14" x2="1026" y2="14" stroke="#0B6E6A" strokeWidth="2" />
            {[114, 342, 570, 798, 1026].map((x) => (
              <line key={x} x1={x} y1="14" x2={x} y2="40" stroke="#0B6E6A" strokeWidth="2" />
            ))}
          </svg>
          {/* children */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: "12px" }}>
            {[
              { name: "Beranda", color: "#3B82F6", role: "Pintu masuk & ringkasan", svg: "M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" },
              { name: "Publikasi", color: "#10B981", role: "Daftar materi terbit", svg: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" },
              { name: "Kategori", color: "#F59E0B", role: "Pengelompokan bidang", svg: "M4 6h16M4 12h16M4 18h16" },
              { name: "Galeri", color: "#8B5CF6", role: "Arsip visual", svg: "M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" },
              { name: "Mengenal INFOTRINK", color: "#EC4899", role: "Penjelasan konsep", svg: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" },
            ].map((c) => (
              <div key={c.name} style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center" }}>
                <div style={{ width: "48px", height: "48px", borderRadius: "12px", background: `${c.color}15`, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "8px", border: `2px solid ${c.color}30` }}>
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d={c.svg} stroke={c.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
                <div style={{ fontSize: "12.5px", fontWeight: 700, color: "#0B3B3A", marginBottom: "3px" }}>{c.name}</div>
                <div style={{ fontSize: "10.5px", color: "#5B7A78", lineHeight: 1.4 }}>{c.role}</div>
              </div>
            ))}
          </div>
        </div>

        {/* detail table */}
        <div style={{ margin: "16px 0", overflow: "hidden", borderRadius: "12px", border: "1px solid rgba(11, 110, 106, 0.12)" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "13px" }}>
            <thead>
              <tr style={{ background: "#0B6E6A" }}>
                <th style={{ padding: "12px 16px", textAlign: "left", color: "white", fontWeight: 700, width: "22%" }}>Bagian</th>
                <th style={{ padding: "12px 16px", textAlign: "left", color: "white", fontWeight: 700, width: "30%" }}>Peran</th>
                <th style={{ padding: "12px 16px", textAlign: "left", color: "white", fontWeight: 700 }}>Isi Utama</th>
              </tr>
            </thead>
            <tbody>
              {[
                ["Beranda", "Pintu masuk", "Judul, ringkasan, ajakan eksplorasi"],
                ["Publikasi", "Daftar materi", "Artikel, riset, kajian, laporan, data, gagasan"],
                ["Kategori", "Pengelompokan", "Media Digital, Pembangunan, Personal, lainnya"],
                ["Galeri", "Arsip visual", "Foto, video, infografis dari berbagai kegiatan"],
                ["Mengenal INFOTRINK", "Penjelasan konsep", "Pengenalan, latar, tujuan, ruang lingkup, prinsip"],
              ].map((row, ri) => (
                <tr key={ri} style={{ background: ri % 2 === 0 ? "white" : "#F4FBFA", borderBottom: "1px solid rgba(11, 110, 106, 0.06)" }}>
                  <td style={{ padding: "11px 16px", fontWeight: 700, color: "#0B3B3A" }}>{ri === 4 ? <BrandText text={row[0]} /> : row[0]}</td>
                  <td style={{ padding: "11px 16px", color: "#1F2937" }}>{row[1]}</td>
                  <td style={{ padding: "11px 16px", color: "#5B7A78" }}>{row[2]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p style={CAP}>Tabel 2. Rincian peran dan isi dari masing-masing bagian struktur INFOTRINK.</p>
      </div>

      {/* =====================================================
          10. ALUR PENGETAHUAN — flow diagram
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#10B981") }}>Alur Pengetahuan di <BrandText text="INFOTRINK" /></h2>
        <p style={P}>
          Setiap materi yang masuk ke INFOTRINK mengikuti lima tahap berikut. Tahap-tahap ini menjawab bagaimana sebuah tulisan berubah dari sekadar catatan menjadi bagian dari pengetahuan yang dapat dimanfaatkan.
        </p>

        {/* horizontal flow */}
        <div style={{ background: "linear-gradient(135deg, #F0FAF8 0%, #E8FEFC 100%)", borderRadius: "16px", padding: "28px 24px", margin: "18px 0", border: "1px solid rgba(11, 110, 106, 0.1)" }}>
          <div style={{ display: "flex", alignItems: "stretch", gap: "0" }}>
            {[
              { num: "1", title: "Himpun", desc: "Materi dikumpulkan dari berbagai sumber.", color: "#3B82F6" },
              { num: "2", title: "Susun", desc: "Dikelompokkan berdasarkan bidang & jenis.", color: "#10B981" },
              { num: "3", title: "Sajikan", desc: "Ditampilkan dengan konteks yang jelas.", color: "#F59E0B" },
              { num: "4", title: "Telusuri", desc: "Dapat dicari & ditemukan kembali.", color: "#8B5CF6" },
              { num: "5", title: "Manfaatkan", desc: "Dipakai untuk belajar atau berkarya.", color: "#EC4899" },
            ].map((step, i, arr) => (
              <div key={step.num} style={{ flex: 1, display: "flex", alignItems: "stretch" }}>
                <div style={{ flex: 1, textAlign: "center", padding: "0 8px" }}>
                  <div style={{ width: "52px", height: "52px", margin: "0 auto 10px", borderRadius: "50%", background: `linear-gradient(135deg, ${step.color} 0%, ${step.color}cc 100%)`, display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontSize: "20px", fontWeight: 800, boxShadow: `0 4px 14px ${step.color}40` }}>
                    {step.num}
                  </div>
                  <div style={{ fontSize: "14px", fontWeight: 800, color: "#0B3B3A", marginBottom: "4px" }}>{step.title}</div>
                  <div style={{ fontSize: "11.5px", lineHeight: 1.5, color: "#5B7A78", maxWidth: "150px", margin: "0 auto" }}>{step.desc}</div>
                </div>
                {i < arr.length - 1 && (
                  <div style={{ display: "flex", alignItems: "center", paddingTop: "16px" }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M5 12h14m0 0l-6-6m6 6l-6 6" stroke="#0B6E6A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
        <p style={{ ...P, marginTop: "6px" }}>
          Tahap pertama sampai ketiga adalah tanggung jawab pengelola; tahap keempat dan kelima adalah hak pembaca. Pemisahan ini menjelaskan siapa bertanggung jawab atas apa — bukan mengulang bahwa INFOTRINK menghimpun pengetahuan.
        </p>
      </div>

      {/* =====================================================
          11. MANFAAT — pembaca vs kontributor
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#F59E0B") }}>Manfaat Utama</h2>
        <p style={P}>
          Manfaat INFOTRINK berbeda tergantung pada peran penggunanya. Berikut perbandingan langsung antara mereka yang membaca dan mereka yang menulis.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginTop: "18px" }}>
          {/* pembaca */}
          <div style={{ background: "white", borderRadius: "16px", overflow: "hidden", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)" }}>
            <div style={{ background: "linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)", padding: "16px 22px", color: "white", display: "flex", alignItems: "center", gap: "12px" }}>
              <div style={{ width: "36px", height: "36px", borderRadius: "10px", background: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 6.253v13m0-13C10.138 6.253 8.439 7.197 7 8.5m5-2.253c1.862 0 3.561.944 5 2.253M7 8.5v13m0-13C5.439 9.797 4.5 11.497 4.5 13.5m2.5-5v13" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </div>
              <div>
                <div style={{ fontSize: "10px", fontWeight: 800, letterSpacing: "2px", opacity: 0.85 }}>UNTUK PEMBACA</div>
                <div style={{ fontSize: "16px", fontWeight: 800 }}>Yang Membaca</div>
              </div>
            </div>
            <ul style={{ margin: 0, padding: "18px 22px 20px", listStyle: "none" }}>
              {[
                "Menemukan bahan bacaan dari berbagai bidang dalam satu tempat.",
                "Memperluas wawasan tanpa harus berpindah-pindah platform.",
                "Menelusuri topik tertentu melalui kategori yang rapi.",
                "Mempelajari perkembangan suatu kegiatan dari catatan terdokumentasi.",
              ].map((b, i) => (
                <li key={i} style={{ display: "flex", gap: "10px", padding: "8px 0", borderBottom: i < 3 ? "1px solid rgba(11, 110, 106, 0.06)" : "none", fontSize: "13px", lineHeight: 1.55, color: "#1F2937" }}>
                  <span style={{ color: "#3B82F6", fontWeight: 800, marginTop: "1px" }}>✓</span>
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* kontributor */}
          <div style={{ background: "white", borderRadius: "16px", overflow: "hidden", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)" }}>
            <div style={{ background: "linear-gradient(135deg, #10B981 0%, #059669 100%)", padding: "16px 22px", color: "white", display: "flex", alignItems: "center", gap: "12px" }}>
              <div style={{ width: "36px", height: "36px", borderRadius: "10px", background: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </div>
              <div>
                <div style={{ fontSize: "10px", fontWeight: 800, letterSpacing: "2px", opacity: 0.85 }}>UNTUK KONTRIBUTOR</div>
                <div style={{ fontSize: "16px", fontWeight: 800 }}>Yang Menulis</div>
              </div>
            </div>
            <ul style={{ margin: 0, padding: "18px 22px 20px", listStyle: "none" }}>
              {[
                "Menerbitkan tulisan pada ruang yang sudah tertata per kategori.",
                "Membangun rekam jejak karya yang dapat ditelusuri dari waktu ke waktu.",
                "Menjangkau pembaca di luar lingkup personal media sosial.",
                "Menyimpan dokumentasi proses agar tidak hilang seiring waktu.",
              ].map((b, i) => (
                <li key={i} style={{ display: "flex", gap: "10px", padding: "8px 0", borderBottom: i < 3 ? "1px solid rgba(11, 110, 106, 0.06)" : "none", fontSize: "13px", lineHeight: 1.55, color: "#1F2937" }}>
                  <span style={{ color: "#10B981", fontWeight: 800, marginTop: "1px" }}>✓</span>
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* =====================================================
          12. CARA MULAI — numbered timeline
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#3B82F6") }}>Cara Mulai Mengeksplorasi</h2>
        <p style={P}>
          Bagi pembaca baru, berikut urutan yang paling mudah untuk mengenal INFOTRINK secara bertahap.
        </p>

        <div style={{ marginTop: "18px", position: "relative" }}>
          {/* vertical line */}
          <div style={{ position: "absolute", left: "20px", top: "10px", bottom: "10px", width: "2px", background: "linear-gradient(180deg, #3B82F6 0%, #10B981 33%, #F59E0B 66%, #EC4899 100%)" }} />
          <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
            {[
              { step: "1", title: "Mulai dari Beranda", desc: "Baca ringkasan singkat untuk mendapat gambaran umum tentang INFOTRINK.", color: "#3B82F6" },
              { step: "2", title: "Telusuri Publikasi", desc: "Buka menu Publikasi untuk melihat daftar materi yang sudah diterbitkan.", color: "#10B981" },
              { step: "3", title: "Pilih Kategori", desc: "Gunakan menu Kategori jika ingin fokus pada satu bidang tertentu.", color: "#F59E0B" },
              { step: "4", title: "Lihat Galeri", desc: "Cek Galeri untuk konteks visual dari berbagai kegiatan yang didokumentasikan.", color: "#8B5CF6" },
              { step: "5", title: "Pahami Konsepnya", desc: "Kembali ke Mengenal INFOTRINK untuk memperdalam pemahaman tentang platform ini.", color: "#EC4899" },
            ].map((s) => (
              <div key={s.step} style={{ display: "flex", gap: "16px", alignItems: "flex-start", paddingLeft: "0" }}>
                <div style={{ width: "42px", height: "42px", borderRadius: "50%", background: `linear-gradient(135deg, ${s.color} 0%, ${s.color}cc 100%)`, display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontSize: "16px", fontWeight: 800, flexShrink: 0, boxShadow: `0 4px 12px ${s.color}40`, position: "relative", zIndex: 1 }}>
                  {s.step}
                </div>
                <div style={{ flex: 1, background: "white", borderRadius: "12px", padding: "14px 18px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 2px 8px rgba(11, 59, 58, 0.04)" }}>
                  <div style={{ fontSize: "14px", fontWeight: 700, color: "#0B3B3A", marginBottom: "4px" }}>{s.title}</div>
                  <div style={{ fontSize: "12.5px", lineHeight: 1.55, color: "#5B7A78", textAlign: "justify", textJustify: "inter-word" }}>{s.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* =====================================================
          13. PENUTUP + NAVIGATION
      ===================================================== */}
      <div style={{ marginBottom: "20px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Penutup</h2>
        <p style={P}>
          Halaman ini menjelaskan apa, mengapa, untuk siapa, dan bagaimana INFOTRINK bekerja sebagai satu kesatuan. Setiap bagian di atas dirancang untuk menjawab satu pertanyaan tunggal agar tidak ada penjelasan yang berputar. Untuk memperdalam aspek tertentu, lanjutkan ke salah satu halaman berikut.
        </p>

        {/* navigation cards */}
        <div style={{ marginTop: "24px", paddingTop: "24px", borderTop: "1px solid rgba(11, 110, 106, 0.1)" }}>
          <h3 style={{ fontSize: "15px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 14px 0", display: "flex", alignItems: "center", gap: "8px" }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M13 7l5 5m0 0l-5 5m5-5H6" stroke="#0B6E6A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
            Lanjutkan ke Bagian Lainnya
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "14px" }}>
            {[
              { name: "Latar Belakang", menu: "Mengenal INFOTRINK", submenu: "Latar Belakang", color: "#3B82F6", svg: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" },
              { name: "Tujuan dan Fungsi", menu: "Mengenal INFOTRINK", submenu: "Tujuan dan Fungsi", color: "#10B981", svg: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" },
              { name: "Ruang Lingkup", menu: "Mengenal INFOTRINK", submenu: "Ruang Lingkup", color: "#F59E0B", svg: "M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" },
              { name: "Prinsip Pengelolaan", menu: "Mengenal INFOTRINK", submenu: "Prinsip Pengelolaan", color: "#8B5CF6", svg: "M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" },
            ].map((item) => (
              <div
                key={item.name}
                onClick={() => onOpenSubmenu(item.menu, item.submenu)}
                style={{ cursor: "pointer", background: "white", borderRadius: "14px", padding: "18px 16px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 12px rgba(11, 59, 58, 0.05)", transition: "all 0.2s ease", borderTop: `3px solid ${item.color}` }}
                onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = "0 8px 20px rgba(11, 59, 58, 0.1)"; }}
                onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "0 4px 12px rgba(11, 59, 58, 0.05)"; }}
              >
                <div style={{ width: "38px", height: "38px", borderRadius: "10px", background: `${item.color}15`, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "10px" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d={item.svg} stroke={item.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
                <div style={{ fontSize: "13.5px", fontWeight: 800, color: "#0B3B3A", marginBottom: "4px", lineHeight: 1.25 }}>{item.name}</div>
                <div style={{ display: "flex", alignItems: "center", gap: "4px", fontSize: "11px", color: item.color, fontWeight: 700 }}>
                  Baca selengkapnya
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M5 12h14m0 0l-6-6m6 6l-6 6" stroke={item.color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// LATAR BELAKANG PAGE — menjelaskan alasan keberadaan INFOTRINK
// ============================================================
function LatarBelakangPage({ onOpenSubmenu }: { onOpenSubmenu: (menu: string, submenu: string) => void }) {
  const H2 = {
    fontSize: "22px",
    fontWeight: 800,
    color: "#0B3B3A",
    margin: "0 0 14px 0",
    lineHeight: 1.3,
    letterSpacing: "-0.2px",
  } as const;
  const H2Bar = (color = "#0B6E6A") => ({
    borderLeft: `4px solid ${color}`,
    paddingLeft: "14px",
  });
  const P = {
    fontSize: "15px",
    lineHeight: 1.85,
    color: "#1F2937",
    margin: "0 0 14px 0",
    textAlign: "justify" as const,
    textJustify: "inter-word" as const,
  };
  const CAP = {
    fontSize: "12px",
    color: "#9CB3B0",
    textAlign: "center" as const,
    margin: "8px 0 28px 0",
    fontStyle: "italic" as const,
  };
  const SECTION_NUM: React.CSSProperties = {
    display: "inline-flex",
    alignItems: "center",
    gap: "8px",
    padding: "4px 12px",
    borderRadius: "999px",
    background: "rgba(11, 110, 106, 0.1)",
    fontSize: "11px",
    fontWeight: 800,
    color: "#0B6E6A",
    letterSpacing: "1px",
    marginBottom: "10px",
  };

  // data: 5 jejak yang terputus
  const jejak = [
    {
      num: "01",
      tag: "HASIL RISET",
      title: "Jejak Penelitian yang Terputus",
      metaphor: "Riset selesai, laporan tersimpan, lalu hilang ditelan arsip.",
      desc: "Banyak hasil penelitian, kajian, dan analisis berharga berakhir di folder pribadi atau arsip lembaga yang sulit dijangkau. Temuan yang seharusnya menjadi pijakan pengetahuan berikutnya justru terputus dari pembaca yang membutuhkan.",
      example: "Sebuah kajian tentang pola konsumsi media lokal tersimpan rapi di laptop peneliti selama tiga tahun. Tidak ada yang membacanya lagi. Sementara di sisi lain, seseorang sedang menulis topik yang sama dari nol tanpa menyadari kajian itu sudah ada.",
      color: "#3B82F6",
      svg: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z",
    },
    {
      num: "02",
      tag: "KETERAMPILAN",
      title: "Jejak Keterampilan yang Tertinggal",
      metaphor: "Dunia bergerak lebih cepat daripada bahan belajar yang tersedia.",
      desc: "Kebutuhan keterampilan berubah cepat seiring perkembangan teknologi dan praktik baru. Namun bahan belajar yang menyertai perubahan tersebut seringkali belum tersusun, belum tertata, atau bahkan belum ditulis. Akibatnya, banyak orang tertinggal tanpa arah yang jelas.",
      example: "Sebuah platform baru muncul, banyak orang ingin mempelajarinya, namun tidak ada catatan terstruktur yang menjelaskannya. Yang ada hanyalah potongan-potongan informasi di banyak tempat dengan kualitas yang tidak merata.",
      color: "#10B981",
      svg: "M13 10V3L4 14h7v7l9-11h-7z",
    },
    {
      num: "03",
      tag: "KOMPETENSI",
      title: "Jejak Kompetensi yang Tidak Tertandingi",
      metaphor: "Yang dibutuhkan tidak sama dengan yang tersedia.",
      desc: "Antara apa yang dibutuhkan oleh suatu peran, pekerjaan, atau bidang dengan apa yang benar-benar tersedia sebagai bahan pembelajaran sering tidak cocok. Kompetensi yang seharusnya berkembang menjadi tertahan, sementara kebutuhan terus berjalan.",
      example: "Sebuah bidang kerja menuntut penguasaan tertentu, namun bahan untuk membangun penguasaan itu terpencar di banyak sumber dengan kedalaman yang berbeda-beda. Tidak ada satu pun tempat yang menyajikannya secara utuh dan berurutan.",
      color: "#F59E0B",
      svg: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z",
    },
    {
      num: "04",
      tag: "ANTAR GENERASI",
      title: "Jejak Yang Terputus Antar Generasi",
      metaphor: "Pengalaman senior berjalan keluar saat ia pensiun.",
      desc: "Pengetahuan yang dimiliki oleh generasi yang lebih berpengalaman sering tidak terdokumentasi dengan baik. Saat mereka pensiun, pindah, atau berhenti, pengetahuan tersebut ikut pergi. Generasi berikutnya harus mulai dari nol, mengulang jalan yang sudah pernah ditempuh.",
      example: "Seorang praktisi senior dengan tiga dekade pengalaman pensiun tanpa meninggalkan catatan. Penggantinya mewarisi jabatan, tetapi tidak mewarisi pemahaman. Banyak keputusan harus diambil tanpa konteks yang seharusnya sudah ada.",
      color: "#8B5CF6",
      svg: "M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-1.13a4 4 0 10-4-4 4 4 0 004 4zm6 0a3 3 0 10-2-5.24M7 13a3 3 0 10-2 5.24",
    },
    {
      num: "05",
      tag: "PENGALAMAN",
      title: "Jejak Pengalaman yang Tidak Tertulis",
      metaphor: "Pelajaran dari lapangan lenyap karena tidak pernah dicatat.",
      desc: "Setiap kegiatan, proyek, atau peristiwa menghasilkan pelajaran. Namun tanpa kebiasaan mendokumentasikan, pelajaran tersebut menguap begitu saja. Yang tersisa hanyalah hasil akhir, sementara proses, kesalahan, dan wawasannya hilang.",
      example: "Sebuah proyek selesai dengan hasil yang baik. Tetapi tidak ada catatan tentang hambatan yang dihadapi, keputusan yang diambil, atau alasan di baliknya. Ketika proyek serupa akan dijalankan lagi, tim harus mengulang proses belajar dari awal.",
      color: "#EC4899",
      svg: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z",
    },
  ];

  return (
    <div style={{ padding: "165px 70px 60px", color: "#1F2937" }}>
      {/* =====================================================
          0. HERO
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h1 style={{ fontSize: "42px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 12px 0", letterSpacing: "-0.8px", lineHeight: 1.1 }}>
          Latar Belakang <BrandText text="INFOTRINK" />
        </h1>
        <p style={{ fontSize: "16px", color: "#5B7A78", margin: "0 0 22px 0", lineHeight: 1.8, textAlign: "justify", textJustify: "inter-word" }}>
          Halaman ini menjelaskan alasan mendasar mengapa INFOTRINK perlu ada. Penjelasan disusun berurutan: dimulai dari konteks zaman yang penuh informasi namun miskin pengetahuan, kemudian memetakan lima jejak yang sering terputus di banyak bidang, menelusuri akar penyebabnya, mengidentifikasi dampak yang ditimbulkannya, hingga merumuskan arah yang dipegang platform ini sebagai kaki dan tangan yang membawa website berjalan ke depan secara terarah.
        </p>
        {/* hero image */}
        <div style={{ position: "relative", width: "100%", height: "320px", borderRadius: "16px", overflow: "hidden", boxShadow: "0 12px 32px rgba(11, 59, 58, 0.18)" }}>
          <Image src="/slide/latar-jejak.png" alt="Visualisasi lima aliran pengetahuan yang berhimpun ke satu pusat" width={1280} height={320} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} unoptimized priority />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(90deg, rgba(11,59,58,0.65) 0%, rgba(11,59,58,0.2) 55%, transparent 100%)" }} />
          <div style={{ position: "absolute", left: "26px", bottom: "22px", right: "26px", color: "white" }}>
            <div style={{ fontSize: "11px", fontWeight: 700, letterSpacing: "2px", color: "#81F6EF", marginBottom: "6px" }}>MENGAPA ADA</div>
            <div style={{ fontSize: "20px", fontWeight: 700, lineHeight: 1.3, maxWidth: "620px" }}>
              Lima jejak pengetahuan yang terputus. Satu ruang yang menyatukannya kembali.
            </div>
          </div>
        </div>
      </div>

      {/* =====================================================
          1. KONTEKS ZAMAN
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#3B82F6") }}>Zaman yang Penuh Informasi, tapi Miskin Pengetahuan</h2>
        <p style={P}>
          Tidak pernah ada zaman dengan informasi sebanyak sekarang. Setiap hari, ribuan tulisan, video, catatan, dan dokumen diproduksi dan dibagikan. Namun kelimpahan ini menyimpan paradoks: semakin banyak informasi, semakin sulit menemukan pengetahuan yang utuh, terkonteks, dan dapat dipercaya. Banyak hal yang sebenarnya berharga tenggelam di antara ribuan hal yang tidak.
        </p>

        {/* 3 stat blocks - tanpa icon, kalimat diperpanjang */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "16px", margin: "20px 0 8px 0" }}>
          {[
            { stat: "∞", label: "Informasi tersedia", desc: "Setiap hari lahir ribuan tulisan, catatan, dokumen, dan unggahan baru di berbagai platform. Volume informasi yang beredar tumbuh tanpa henti, namun tidak semua memiliki kualitas dan keterbacaan yang sama.", color: "#3B82F6" },
            { stat: "?", label: "Pengetahuan yang utuh", desc: "Sedikit dari informasi tersebut tersusun dengan konteks, keterkaitan, dan latar belakang yang jelas. Akibatnya, pembaca sulit memahami secara menyeluruh topik yang sedang dipelajarinya.", color: "#F59E0B" },
            { stat: "↻", label: "Pengulangan dari nol", desc: "Karena pengetahuan tidak tertata, banyak orang memulai topik yang sebenarnya sudah pernah dikerjakan orang lain. Waktu dan tenaga terbuang untuk mengulang proses yang sama.", color: "#EC4899" },
          ].map((s) => (
            <div key={s.label} style={{ background: "white", borderRadius: "14px", padding: "24px 24px 22px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", position: "relative", overflow: "hidden", borderTop: `4px solid ${s.color}` }}>
              <div style={{ position: "absolute", right: "-20px", top: "-20px", width: "100px", height: "100px", borderRadius: "50%", background: `${s.color}08` }} />
              <div style={{ position: "relative" }}>
                <div style={{ fontSize: "44px", fontWeight: 800, color: s.color, lineHeight: 1, marginBottom: "12px" }}>{s.stat}</div>
                <div style={{ fontSize: "15px", fontWeight: 700, color: "#0B3B3A", marginBottom: "8px" }}>{s.label}</div>
                <p style={{ fontSize: "13px", lineHeight: 1.7, color: "#5B7A78", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
        <p style={{ ...P, marginTop: "16px" }}>
          Konteks inilah yang menjadi panggung INFOTRINK. Bukan menambahkan kebisingan informasi, melainkan menyusun ulang apa yang sudah ada agar berdaya guna. Bagian berikutnya menjelaskan lima bentuk putusan yang menjadi alasan lebih spesifik.
        </p>
      </div>

      {/* =====================================================
          2. LIMA JEJAK YANG TERPUTUS — main content
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#8B5CF6") }}>Lima Jejak yang Terputus</h2>
        <p style={P}>
          Berikut lima bentuk putusan yang berulang di banyak bidang. Setiap jejak dijelaskan dengan metafora singkat, penjelasan, dan satu contoh konkret yang sering dijumpai di lapangan. Kelimanya berbeda akar, namun bermuara pada kebutuhan yang sama: ruang untuk menyatukan kembali.
        </p>

        {/* 5 alternating detail rows */}
        <div style={{ display: "flex", flexDirection: "column", gap: "20px", marginTop: "20px" }}>
          {jejak.map((j, idx) => (
            <div key={j.num} style={{ background: "white", borderRadius: "18px", overflow: "hidden", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 6px 20px rgba(11, 59, 58, 0.06)" }}>
              {/* header strip */}
              <div style={{ background: `linear-gradient(90deg, ${j.color} 0%, ${j.color}cc 100%)`, padding: "16px 24px", color: "white", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
                  <div style={{ width: "44px", height: "44px", borderRadius: "12px", background: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d={j.svg} stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  </div>
                  <div>
                    <div style={{ fontSize: "10px", fontWeight: 800, letterSpacing: "2px", opacity: 0.85 }}>JEJAK {j.num} · {j.tag}</div>
                    <div style={{ fontSize: "17px", fontWeight: 800, marginTop: "2px" }}>{j.title}</div>
                  </div>
                </div>
                <div style={{ fontSize: "26px", fontWeight: 800, opacity: 0.4, fontFamily: "Georgia, serif" }}>{j.num}</div>
              </div>
              {/* body */}
              <div style={{ display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: "0" }}>
                {/* left: desc + metaphor */}
                <div style={{ padding: "22px 26px", borderRight: "1px solid rgba(11, 110, 106, 0.06)" }}>
                  <div style={{ fontSize: "13px", fontStyle: "italic", color: j.color, fontWeight: 700, marginBottom: "10px", lineHeight: 1.4 }}>
                    &ldquo;{j.metaphor}&rdquo;
                  </div>
                  <p style={{ fontSize: "14px", lineHeight: 1.75, color: "#1F2937", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{j.desc}</p>
                </div>
                {/* right: example */}
                <div style={{ padding: "22px 26px", background: `${j.color}06` }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "10px" }}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke={j.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                    <span style={{ fontSize: "10px", fontWeight: 800, color: j.color, letterSpacing: "1.5px" }}>CONTOH DI LAPANGAN</span>
                  </div>
                  <p style={{ fontSize: "12.5px", lineHeight: 1.65, color: "#1F2937", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{j.example}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        <p style={{ ...P, marginTop: "20px" }}>
          Kelima jejak di atas bukan daftar tertutup. Masih banyak bentuk putusan lain yang bisa dijumpai di bidang-bidang tertentu. Namun kelimanya menjadi titik awal yang paling sering muncul ketika menelusuri alasan mengapa banyak pengetahuan tidak sampai ke pembaca yang membutuhkan.
        </p>
      </div>

      {/* =====================================================
          3. VISUALISASI KONVERGENSI — SVG diagram
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#10B981") }}>Lima Jejak, Satu Pertemuan</h2>
        <p style={P}>
          Bagaimana lima jejak yang berbeda bisa berhimpun? Bagian ini menampilkan visualisasi sederhana: lima aliran yang sebelumnya terpisah menemukan satu ruang yang menyediakan struktur, akses, dan keberlanjutan.
        </p>

        {/* convergence SVG — redesigned: lingkaran lebih besar, label tidak nabrak */}
        <div style={{ background: "white", borderRadius: "16px", padding: "32px 26px 26px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", margin: "18px 0" }}>
          <svg width="100%" height="420" viewBox="0 0 1140 420" style={{ display: "block" }}>
            {/* 5 source nodes on left - lebih besar, lebih spasi */}
            {[
              { y: 50, color: "#3B82F6", label: "Hasil Riset" },
              { y: 130, color: "#10B981", label: "Keterampilan" },
              { y: 210, color: "#F59E0B", label: "Kompetensi" },
              { y: 290, color: "#8B5CF6", label: "Antar Generasi" },
              { y: 370, color: "#EC4899", label: "Pengalaman" },
            ].map((src, i) => {
              const startX = 240;
              const endX = 720;
              const startY = src.y;
              const endY = 210;
              const midX = (startX + endX) / 2;
              return (
                <g key={i}>
                  {/* outer ring */}
                  <circle cx="100" cy={src.y} r="42" fill={src.color} opacity="0.12" />
                  {/* main circle - bigger now */}
                  <circle cx="100" cy={src.y} r="30" fill={src.color} />
                  <text x="100" y={src.y + 5} textAnchor="middle" fontSize="14" fontWeight="800" fill="white">{i + 1}</text>
                  {/* label positioned to the RIGHT of circle, with breathing room */}
                  <text x="150" y={src.y + 5} textAnchor="start" fontSize="13" fontWeight="700" fill="#0B3B3A">{src.label}</text>
                  {/* curve to center - starts from edge of source circle */}
                  <path d={`M ${startX} ${startY} C ${midX} ${startY}, ${midX} ${endY}, ${endX} ${endY}`} stroke={src.color} strokeWidth="2.5" fill="none" opacity="0.6" />
                </g>
              );
            })}
            {/* center hub - bigger */}
            <circle cx="780" cy="210" r="100" fill="#0B6E6A" opacity="0.1" />
            <circle cx="780" cy="210" r="75" fill="url(#hubGrad)" />
            <defs>
              <linearGradient id="hubGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#0B3B3A" />
                <stop offset="100%" stopColor="#0B6E6A" />
              </linearGradient>
            </defs>
            <text x="780" y="205" textAnchor="middle" fontSize="17" fontWeight="800" fill="white">INFOTRINK</text>
            <text x="780" y="225" textAnchor="middle" fontSize="9.5" fontWeight="600" fill="#81F6EF" letterSpacing="1.5">RUMAH PENGETAHUAN</text>
            {/* output arrows - start from edge of hub */}
            <path d="M 880 180 L 980 130" stroke="#0B6E6A" strokeWidth="2.5" strokeDasharray="5 5" />
            <path d="M 885 210 L 980 210" stroke="#0B6E6A" strokeWidth="2.5" strokeDasharray="5 5" />
            <path d="M 880 240 L 980 290" stroke="#0B6E6A" strokeWidth="2.5" strokeDasharray="5 5" />
            {/* output labels - in pill backgrounds */}
            <rect x="985" y="115" width="105" height="28" rx="14" fill="#0B6E6A" opacity="0.1" />
            <text x="1037" y="134" textAnchor="middle" fontSize="12" fontWeight="800" fill="#0B6E6A">Tertata</text>
            <rect x="985" y="196" width="105" height="28" rx="14" fill="#0B6E6A" opacity="0.1" />
            <text x="1037" y="215" textAnchor="middle" fontSize="12" fontWeight="800" fill="#0B6E6A">Terpelajar</text>
            <rect x="985" y="277" width="115" height="28" rx="14" fill="#0B6E6A" opacity="0.1" />
            <text x="1042" y="296" textAnchor="middle" fontSize="12" fontWeight="800" fill="#0B6E6A">Berkelanjutan</text>
          </svg>
        </div>
        <p style={CAP}>Gambar 1. Lima aliran pengetahuan yang sebelumnya terpisah menemukan pertemuan di INFOTRINK, lalu keluar sebagai pengetahuan yang tertata, terpelajar, dan berkelanjutan.</p>
      </div>

      {/* =====================================================
          4. AKAR PENYEBAB
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#F59E0B") }}>Akar Penyebab</h2>
        <p style={P}>
          Lima jejak di atas adalah gejala. Di baliknya ada empat akar yang lebih dalam — hal-hal yang membuat putusan terjadi berulang kali di banyak bidang. Mengatasi gejala tanpa menyentuh akar akan membuat masalah kembali dalam bentuk lain.
        </p>

        {/* 4 root cards - tanpa icon, layout rapih */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px", marginTop: "18px" }}>
          {[
            { num: "1", title: "Tidak Ada Tempat Bersama", desc: "Setiap orang dan kelompok menyimpan pengetahuannya di tempatnya sendiri. Tidak ada satu pun ruang yang menjadi titik temu.", color: "#3B82F6" },
            { num: "2", title: "Tidak Ada Kebiasaan Mencatat", desc: "Banyak orang tidak terbiasa menuliskan proses, keputusan, dan pelajaran. Akibatnya, pengetahuan tinggal di kepala dan ikut ketika orangnya pergi.", color: "#10B981" },
            { num: "3", title: "Tidak Ada Pengelompokan", desc: "Bahkan ketika catatan ada, ia tidak dikelompokkan berdasarkan bidang atau topik. Pencarian kembali menjadi lambat dan melelahkan.", color: "#F59E0B" },
            { num: "4", title: "Tidak Ada Keberlanjutan", desc: "Banyak dokumentasi bersifat satu kali: dibuat, lalu ditinggalkan. Padahal pengetahuan perlu terus diperbarui seiring perkembangan.", color: "#8B5CF6" },
          ].map((r) => (
            <div key={r.num} style={{ background: "white", borderRadius: "14px", padding: "22px 24px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", borderTop: `4px solid ${r.color}` }}>
              <div style={{ display: "flex", alignItems: "center", gap: "14px", marginBottom: "10px" }}>
                <div style={{ width: "36px", height: "36px", borderRadius: "10px", background: `${r.color}15`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, color: r.color, fontSize: "17px", fontWeight: 800 }}>
                  {r.num}
                </div>
                <h4 style={{ fontSize: "15.5px", fontWeight: 700, color: "#0B3B3A", margin: 0, flex: 1 }}>{r.title}</h4>
              </div>
              <p style={{ fontSize: "13.5px", lineHeight: 1.7, color: "#5B7A78", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{r.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* =====================================================
          5. DAMPAK
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#EF4444") }}>Dampak yang Terjadi</h2>
        <p style={P}>
          Jika lima jejak dibiarkan tanpa ruang yang menyatukan, dampaknya muncul di banyak sisi. Berikut empat dampak utama yang berulang ketika pengetahuan tidak dihimpun dengan baik.
        </p>

        {/* impact cards 2x2 - tanpa icon, layout rapih */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginTop: "18px" }}>
          {[
            { impact: "Pengulangan", desc: "Banyak orang mengerjakan ulang hal yang sudah pernah dikerjakan orang lain, karena tidak tahu bahwa catatannya sudah ada.", color: "#EF4444" },
            { impact: "Kehilangan", desc: "Pengetahuan yang dimiliki seseorang hilang bersama kepergiannya, tanpa sempat diturunkan ke siapa pun.", color: "#F59E0B" },
            { impact: "Tertinggal", desc: "Keterampilan dan kompetensi yang dibutuhkan tidak bisa dipelajari tepat waktu, sehingga banyak orang tertinggal dari perubahan.", color: "#8B5CF6" },
            { impact: "Terputus", desc: "Generasi muda tidak mewarisi pengalaman generasi sebelumnya, sehingga banyak keputusan diambil tanpa konteks.", color: "#EC4899" },
          ].map((d) => (
            <div key={d.impact} style={{ background: "white", borderRadius: "14px", padding: "22px 24px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", borderLeft: `4px solid ${d.color}` }}>
              <h4 style={{ fontSize: "16px", fontWeight: 800, color: d.color, margin: "0 0 10px 0" }}>{d.impact}</h4>
              <p style={{ fontSize: "13.5px", lineHeight: 1.7, color: "#5B7A78", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{d.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* =====================================================
          6. ARAH INFOTRINK — kaki dan tangan
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Arah yang Dipegang <BrandText text="INFOTRINK" /></h2>
        <p style={P}>
          Halaman ini adalah kaki dan tangan INFOTRINK. Kaki menentukan ke mana website berjalan; tangan menentukan apa yang dipegang dan dijaga sepanjang jalan. Berikut lima arah yang dipegang, satu untuk setiap jejak di atas — bukan mengulang penjelasan jejak, melainkan menjelaskan bagaimana INFOTRINK meresponsnya.
        </p>

        {/* 5 directions - centered jejak → arrow → arah */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: "14px", marginTop: "20px" }}>
          {[
            { num: "1", jejak: "Hasil Riset", arah: "Menjadi rumah terbitan", desc: "Riset, kajian, dan analisis yang tersebar dapat dihimpun ke dalam satu ruang publikasi yang tertata per kategori.", color: "#3B82F6" },
            { num: "2", jejak: "Keterampilan", arah: "Menyusun jalur belajar", desc: "Topik baru yang belum punya bahan belajar terstruktur dapat ditulis dan disusun secara bertahap.", color: "#10B981" },
            { num: "3", jejak: "Kompetensi", arah: "Membangun referensi bidang", desc: "Setiap bidang dapat dihimpun menjadi referensi yang utuh sehingga kompetensi dapat dibangun berurutan.", color: "#F59E0B" },
            { num: "4", jejak: "Antar Generasi", arah: "Menjadi jembatan penurunan", desc: "Pengalaman generasi berpengalaman dapat dituliskan agar tidak hilang, dan diakses generasi berikutnya.", color: "#8B5CF6" },
            { num: "5", jejak: "Pengalaman", arah: "Mencatat proses, bukan hasil", desc: "Setiap kegiatan dapat didokumentasikan prosesnya, bukan hanya hasilnya, sehingga pelajaran tertinggal.", color: "#EC4899" },
          ].map((d) => (
            <div key={d.num} style={{ background: "white", borderRadius: "16px", padding: "20px 16px 18px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", borderTop: `4px solid ${d.color}`, display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center" }}>
              {/* number badge */}
              <div style={{ width: "44px", height: "44px", borderRadius: "50%", background: `linear-gradient(135deg, ${d.color} 0%, ${d.color}cc 100%)`, display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontSize: "18px", fontWeight: 800, boxShadow: `0 4px 12px ${d.color}40`, marginBottom: "14px" }}>{d.num}</div>

              {/* JEJAK label + value - centered */}
              <div style={{ width: "100%", marginBottom: "10px" }}>
                <div style={{ fontSize: "9.5px", fontWeight: 800, color: "#9CB3B0", letterSpacing: "1.5px", marginBottom: "5px" }}>JEJAK {d.num}</div>
                <div style={{ fontSize: "14px", fontWeight: 800, color: "#1F2937", lineHeight: 1.3, minHeight: "36px", display: "flex", alignItems: "center", justifyContent: "center" }}>{d.jejak}</div>
              </div>

              {/* Arrow centered */}
              <div style={{ width: "32px", height: "32px", borderRadius: "50%", background: `${d.color}12`, display: "flex", alignItems: "center", justifyContent: "center", margin: "6px 0 10px 0" }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M19 14l-7 7m0 0l-7-7m7 7V3" stroke={d.color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </div>

              {/* ARAH label + value - centered */}
              <div style={{ width: "100%", marginBottom: "12px" }}>
                <div style={{ fontSize: "9.5px", fontWeight: 800, color: d.color, letterSpacing: "1.5px", marginBottom: "5px" }}>ARAH</div>
                <div style={{ fontSize: "14px", fontWeight: 800, color: d.color, lineHeight: 1.3, minHeight: "36px", display: "flex", alignItems: "center", justifyContent: "center" }}>{d.arah}</div>
              </div>

              {/* description */}
              <div style={{ width: "100%", paddingTop: "10px", borderTop: "1px solid rgba(11, 110, 106, 0.08)" }}>
                <p style={{ fontSize: "11.5px", lineHeight: 1.6, color: "#5B7A78", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{d.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* =====================================================
          7. PETA JALAN
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#3B82F6") }}>Peta Jalan <BrandText text="INFOTRINK" /></h2>
        <p style={P}>
          Arah yang sudah dijelaskan di atas diterjemahkan menjadi tiga tahap perjalanan. Tahap-tahap ini bukan janji, melainkan kerangka berpikir agar website tetap berjalan ke depan dan tidak berhenti di sekadar peluncuran.
        </p>

        {/* visual: roadmap image */}
        <div style={{ margin: "16px 0", width: "100%", height: "180px", borderRadius: "14px", overflow: "hidden", boxShadow: "0 6px 18px rgba(11, 59, 58, 0.1)" }}>
          <Image src="/slide/latar-jalan.png" alt="Visualisasi perjalanan dari titik-titik terpencar menuju satu arah" width={1280} height={180} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center", display: "block" }} unoptimized />
        </div>
        <p style={CAP}>Gambar 2. Peta jalan INFOTRINK: dari himpunan menuju keteraturan, lalu berkembang.</p>

        {/* 3-stage roadmap - tanpa icon */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "16px", marginTop: "8px" }}>
          {[
            { stage: "Tahap 1", title: "Himpun", focus: "Mengumpulkan materi yang sudah ada di banyak tempat", items: ["Publikasi artikel & kajian", "Dokumentasi kegiatan", "Pengelompokan bidang"], color: "#3B82F6" },
            { stage: "Tahap 2", title: "Tertata", focus: "Menyusun agar mudah ditelusuri dan dipelajari", items: ["Pengelompokan kategori", "Sistem penelusuran", "Konteks yang jelas"], color: "#10B981" },
            { stage: "Tahap 3", title: "Berkembang", focus: "Menjaga agar terus tumbuh seiring waktu", items: ["Pembaruan materi", "Penambahan bidang baru", "Dokumentasi berkelanjutan"], color: "#F59E0B" },
          ].map((s) => (
            <div key={s.stage} style={{ background: "white", borderRadius: "16px", overflow: "hidden", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)" }}>
              <div style={{ background: `linear-gradient(135deg, ${s.color} 0%, ${s.color}cc 100%)`, padding: "20px 22px 18px", color: "white" }}>
                <div style={{ fontSize: "10px", fontWeight: 800, letterSpacing: "2px", opacity: 0.85, marginBottom: "6px" }}>{s.stage.toUpperCase()}</div>
                <div style={{ fontSize: "20px", fontWeight: 800 }}>{s.title}</div>
              </div>
              <div style={{ padding: "18px 22px 20px" }}>
                <p style={{ fontSize: "13px", lineHeight: 1.65, color: "#5B7A78", margin: "0 0 14px 0", fontStyle: "italic", textAlign: "justify", textJustify: "inter-word" }}>{s.focus}</p>
                <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>
                  {s.items.map((it) => (
                    <li key={it} style={{ display: "flex", gap: "8px", alignItems: "flex-start", fontSize: "13px", color: "#1F2937", marginBottom: "7px", lineHeight: 1.5 }}>
                      <span style={{ color: s.color, fontWeight: 800 }}>›</span>
                      <span>{it}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* =====================================================
          8. POSISI HALAMAN INI
      ===================================================== */}
      <div style={{ marginBottom: "44px" }}>
        <h2 style={{ ...H2, ...H2Bar("#8B5CF6") }}>Posisi Halaman Ini dalam Keseluruhan</h2>
        <p style={P}>
          Halaman Pengenalan INFOTRINK menjelaskan apa; halaman ini menjelaskan mengapa. Dua halaman tersebut menjadi pasangan: pengenalan memberi gambaran, latar belakang memberi alasan. Tanpa salah satu, pemahaman pembaca terhadap INFOTRINK akan pincang.
        </p>

        {/* 2-column: position visualization */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginTop: "18px" }}>
          {/* apa card */}
          <div style={{ background: "white", borderRadius: "14px", padding: "20px 22px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", borderTop: "3px solid #3B82F6" }}>
            <div style={{ fontSize: "11px", fontWeight: 800, color: "#3B82F6", letterSpacing: "1.5px", marginBottom: "8px" }}>PENGENALAN INFOTRINK</div>
            <h4 style={{ fontSize: "16px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 8px 0" }}>Menjawab Apa</h4>
            <p style={{ fontSize: "13px", lineHeight: 1.65, color: "#5B7A78", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>
              Memberi gambaran umum: apa itu INFOTRINK, untuk siapa, dan bagaimana ia disusun. Bagi pembaca baru, ini jadi pintu masuk.
            </p>
          </div>
          {/* mengapa card - this page */}
          <div style={{ background: "linear-gradient(135deg, #0B3B3A 0%, #0B6E6A 100%)", borderRadius: "14px", padding: "20px 22px", color: "white", borderTop: "3px solid #81F6EF", position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", right: "-15px", top: "-15px", width: "70px", height: "70px", borderRadius: "50%", background: "rgba(129, 246, 239, 0.1)" }} />
            <div style={{ position: "relative" }}>
              <div style={{ fontSize: "11px", fontWeight: 800, color: "#81F6EF", letterSpacing: "1.5px", marginBottom: "8px" }}>LATAR BELAKANG · HALAMAN INI</div>
              <h4 style={{ fontSize: "16px", fontWeight: 800, margin: "0 0 8px 0" }}>Menjawab Mengapa</h4>
              <p style={{ fontSize: "13px", lineHeight: 1.65, margin: 0, textAlign: "justify", textJustify: "inter-word", opacity: 0.95 }}>
                Memberi alasan keberadaan: lima jejak yang terputus, akar penyebabnya, dan arah yang dipegang INFOTRINK untuk menjawabnya.
              </p>
            </div>
          </div>
        </div>

        {/* next pages preview */}
        <div style={{ marginTop: "16px", background: "white", borderRadius: "14px", padding: "18px 22px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)" }}>
          <div style={{ fontSize: "11px", fontWeight: 800, color: "#9CB3B0", letterSpacing: "1.5px", marginBottom: "10px" }}>LANJUTAN SETELAH HALAMAN INI</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "12px" }}>
            {[
              { name: "Tujuan dan Fungsi", focus: "Menjawab Untuk Apa", color: "#10B981" },
              { name: "Ruang Lingkup", focus: "Menjawab Sampai Mana", color: "#F59E0B" },
              { name: "Prinsip Pengelolaan", focus: "Menjawab Bagaimana", color: "#8B5CF6" },
            ].map((nx) => (
              <div key={nx.name} style={{ display: "flex", alignItems: "center", gap: "10px", padding: "10px 12px", background: `${nx.color}08`, borderRadius: "10px", borderLeft: `3px solid ${nx.color}` }}>
                <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: nx.color, flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: "12.5px", fontWeight: 700, color: "#0B3B3A" }}>{nx.name}</div>
                  <div style={{ fontSize: "10.5px", color: "#5B7A78", marginTop: "1px" }}>{nx.focus}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* =====================================================
          9. PENUTUP + NAVIGATION
      ===================================================== */}
      <div style={{ marginBottom: "20px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Penutup</h2>
        <p style={P}>
          Setiap alasan keberadaan INFOTRINK bermuara pada satu hal: pengetahuan yang berharga sering terputus di tengah jalan, dan ruang yang menyatukannya kembali sangat dibutuhkan. Halaman ini menjelaskan mengapa — bukan untuk mengulang apa yang sudah dijelaskan di Pengenalan, melainkan untuk memberi alasan yang membuat arah INFOTRINK menjadi masuk akal.
        </p>
        <p style={P}>
          Dengan lima jejak yang sudah dipetakan, empat akar yang sudah diidentifikasi, dan lima arah yang sudah dipegang, INFOTRINK berjalan dengan kaki yang jelas dan tangan yang ringkas. Ke mana langkah berikutnya, akan dijelaskan pada halaman-halaman setelah ini.
        </p>

        {/* navigation cards */}
        <div style={{ marginTop: "24px", paddingTop: "24px", borderTop: "1px solid rgba(11, 110, 106, 0.1)" }}>
          <h3 style={{ fontSize: "15px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 14px 0", display: "flex", alignItems: "center", gap: "8px" }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M13 7l5 5m0 0l-5 5m5-5H6" stroke="#0B6E6A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
            Lanjutkan ke Bagian Lainnya
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "14px" }}>
            {[
              { name: "Pengenalan INFOTRINK", menu: "Mengenal INFOTRINK", submenu: "Pengenalan INFOTRINK", color: "#3B82F6", svg: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" },
              { name: "Tujuan dan Fungsi", menu: "Mengenal INFOTRINK", submenu: "Tujuan dan Fungsi", color: "#10B981", svg: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" },
              { name: "Ruang Lingkup", menu: "Mengenal INFOTRINK", submenu: "Ruang Lingkup", color: "#F59E0B", svg: "M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" },
              { name: "Prinsip Pengelolaan", menu: "Mengenal INFOTRINK", submenu: "Prinsip Pengelolaan", color: "#8B5CF6", svg: "M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" },
            ].map((item) => (
              <div
                key={item.name}
                onClick={() => onOpenSubmenu(item.menu, item.submenu)}
                style={{ cursor: "pointer", background: "white", borderRadius: "14px", padding: "18px 16px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 12px rgba(11, 59, 58, 0.05)", transition: "all 0.2s ease", borderTop: `3px solid ${item.color}` }}
                onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = "0 8px 20px rgba(11, 59, 58, 0.1)"; }}
                onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "0 4px 12px rgba(11, 59, 58, 0.05)"; }}
              >
                <div style={{ width: "38px", height: "38px", borderRadius: "10px", background: `${item.color}15`, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "10px" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d={item.svg} stroke={item.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
                <div style={{ fontSize: "13.5px", fontWeight: 800, color: "#0B3B3A", marginBottom: "4px", lineHeight: 1.25 }}>{item.name}</div>
                <div style={{ display: "flex", alignItems: "center", gap: "4px", fontSize: "11px", color: item.color, fontWeight: 700 }}>
                  Baca selengkapnya
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M5 12h14m0 0l-6-6m6 6l-6 6" stroke={item.color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// TUJUAN DAN FUNGSI PAGE — menjawab "untuk apa" INFOTRINK ada
// ============================================================
function TujuanFungsiPage({ onOpenSubmenu }: { onOpenSubmenu: (menu: string, submenu: string) => void }) {
  const H2 = {
    fontSize: "22px",
    fontWeight: 800,
    color: "#0B3B3A",
    margin: "0 0 14px 0",
    lineHeight: 1.3,
    letterSpacing: "-0.2px",
  } as const;
  const H2Bar = (color = "#0B6E6A") => ({
    borderLeft: `4px solid ${color}`,
    paddingLeft: "14px",
  });
  const P = {
    fontSize: "15px",
    lineHeight: 1.85,
    color: "#1F2937",
    margin: "0 0 14px 0",
    textAlign: "justify" as const,
    textJustify: "inter-word" as const,
  };
  const CAP = {
    fontSize: "12px",
    color: "#9CB3B0",
    textAlign: "center" as const,
    margin: "8px 0 28px 0",
    fontStyle: "italic" as const,
  };

  return (
    <div style={{ padding: "165px 70px 60px", color: "#1F2937" }}>
      {/* =====================================================
          0. HERO — split layout (image kanan + content kiri)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1.15fr 1fr", gap: "32px", alignItems: "center" }}>
          {/* left: title + description */}
          <div>
            <h1 style={{ fontSize: "40px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 16px 0", letterSpacing: "-0.8px", lineHeight: 1.1 }}>
              Tujuan &amp; Fungsi <BrandText text="INFOTRINK" />
            </h1>
            <p style={{ fontSize: "15.5px", lineHeight: 1.8, color: "#5B7A78", margin: "0 0 20px 0", textAlign: "justify", textJustify: "inter-word" }}>
              Halaman ini menjelaskan dua hal yang sering dianggap sama namun sebenarnya berbeda: tujuan (sasaran yang ingin dicapai ke depan) dan fungsi (peran yang dijalankan saat ini). Keduanya dijelaskan terpisah agar tidak tertukar, kemudian disambung dengan skenario penggunaan konkret yang menunjukkan bagaimana tujuan dan fungsi tersebut terwujud dalam praktik sehari-hari.
            </p>
            {/* 4 stat cards - boxed rapih */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "12px", marginTop: "20px" }}>
              {[
                { num: "1", label: "Tujuan Umum", desc: "Sasaran tertinggi", color: "#0B6E6A" },
                { num: "6", label: "Tujuan Khusus", desc: "Penjabaran konkret", color: "#3B82F6" },
                { num: "6", label: "Fungsi Utama", desc: "Peran yang dijalankan", color: "#10B981" },
                { num: "4", label: "Skenario Nyata", desc: "Contoh penggunaan", color: "#F59E0B" },
              ].map((s) => (
                <div key={s.label} style={{ background: "white", borderRadius: "12px", padding: "16px 14px 14px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 2px 8px rgba(11, 59, 58, 0.04)", borderTop: `3px solid ${s.color}`, textAlign: "center" }}>
                  <div style={{ fontSize: "30px", fontWeight: 800, color: s.color, lineHeight: 1, marginBottom: "8px" }}>{s.num}</div>
                  <div style={{ fontSize: "12px", fontWeight: 800, color: "#0B3B3A", marginBottom: "2px" }}>{s.label}</div>
                  <div style={{ fontSize: "10.5px", color: "#9CB3B0", fontStyle: "italic" }}>{s.desc}</div>
                </div>
              ))}
            </div>
          </div>
          {/* right: image */}
          <div style={{ position: "relative", borderRadius: "16px", overflow: "hidden", height: "340px", boxShadow: "0 12px 32px rgba(11, 59, 58, 0.18)" }}>
            <Image src="/slide/tujuan-arah.png" alt="Kompas dan target yang merepresentasikan arah dan tujuan" width={640} height={340} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} unoptimized priority />
            <div style={{ position: "absolute", inset: 0, background: "linear-gradient(135deg, transparent 50%, rgba(11, 59, 58, 0.4) 100%)" }} />
            <div style={{ position: "absolute", right: "18px", bottom: "18px", left: "18px", textAlign: "right", color: "white" }}>
              <div style={{ fontSize: "11px", fontWeight: 700, letterSpacing: "2px", color: "#81F6EF", marginBottom: "4px" }}>ARAH &amp; SASARAN</div>
              <div style={{ fontSize: "14px", fontWeight: 600, opacity: 0.95 }}>Dari niat menyatukan, menuju hasil termanfaatkan</div>
            </div>
          </div>
        </div>
      </div>

      {/* =====================================================
          1. TUJUAN UMUM — single big quote card
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Tujuan Umum</h2>
        <p style={P}>
          Tujuan umum adalah sasaran tertinggi yang ingin dicapai INFOTRINK dalam jangka panjang. Segala tujuan khusus dan fungsi yang dijalankan saat ini bermuara ke sini. Tujuan ini sengaja dibuat tunggal agar arah platform tidak bercabang.
        </p>

        {/* big quote card */}
        <div style={{ background: "linear-gradient(135deg, #0B3B3A 0%, #0B6E6A 100%)", borderRadius: "18px", padding: "40px 44px", color: "white", position: "relative", overflow: "hidden", margin: "20px 0" }}>
          {/* decorative big quote */}
          <div style={{ position: "absolute", top: "20px", right: "30px", fontSize: "120px", fontFamily: "Georgia, serif", color: "#81F6EF", opacity: 0.2, lineHeight: 0.8 }}>&rdquo;</div>
          {/* decorative circles */}
          <div style={{ position: "absolute", bottom: "-50px", right: "-50px", width: "180px", height: "180px", borderRadius: "50%", background: "rgba(129, 246, 239, 0.08)" }} />
          <div style={{ position: "absolute", bottom: "-30px", right: "-30px", width: "120px", height: "120px", borderRadius: "50%", background: "rgba(129, 246, 239, 0.12)" }} />

          <div style={{ position: "relative" }}>
            <div style={{ display: "inline-block", padding: "5px 14px", background: "rgba(129, 246, 239, 0.2)", borderRadius: "999px", marginBottom: "18px" }}>
              <span style={{ fontSize: "10px", fontWeight: 800, color: "#81F6EF", letterSpacing: "2px" }}>SASARAN TERTINGGI</span>
            </div>
            <p style={{ fontSize: "22px", lineHeight: 1.55, margin: 0, fontWeight: 600, maxWidth: "880px" }}>
              Membangun satu ruang pengetahuan multibidang yang <span style={{ color: "#81F6EF" }}>tertata, hidup, dan berkelanjutan</span> — tempat berbagai kalangan dapat menulis, membaca, dan menelusuri tanpa harus berpindah-pindah tempat.
            </p>
            <div style={{ marginTop: "24px", paddingTop: "18px", borderTop: "1px solid rgba(129, 246, 239, 0.25)", display: "flex", gap: "32px", flexWrap: "wrap" }}>
              <div>
                <div style={{ fontSize: "10px", color: "#81F6EF", letterSpacing: "1.5px", fontWeight: 700 }}>Apa</div>
                <div style={{ fontSize: "13px", marginTop: "3px" }}>Satu ruang pengetahuan</div>
              </div>
              <div>
                <div style={{ fontSize: "10px", color: "#81F6EF", letterSpacing: "1.5px", fontWeight: 700 }}>Sifat</div>
                <div style={{ fontSize: "13px", marginTop: "3px" }}>Tertata, hidup, berkelanjutan</div>
              </div>
              <div>
                <div style={{ fontSize: "10px", color: "#81F6EF", letterSpacing: "1.5px", fontWeight: 700 }}>Untuk Siapa</div>
                <div style={{ fontSize: "13px", marginTop: "3px" }}>Berbagai kalangan</div>
              </div>
              <div>
                <div style={{ fontSize: "10px", color: "#81F6EF", letterSpacing: "1.5px", fontWeight: 700 }}>Hasil</div>
                <div style={{ fontSize: "13px", marginTop: "3px" }}>Menulis, baca, telusuri</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* =====================================================
          2. TUJUAN KHUSUS — 6 cards zigzag alternating layout
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#3B82F6") }}>Enam Tujuan Khusus</h2>
        <p style={P}>
          Tujuan khusus adalah penjabaran tujuan umum menjadi sasaran-sasaran yang lebih konkret. Setiap tujuan khusus menjawab satu pertanyaan berbeda — tidak ada yang tumpang-tindih — agar setiap usaha pengelolaan dapat ditelusuri kembali ke sasarannya masing-masing.
        </p>

        {/* zigzag alternating rows — different from previous pages */}
        <div style={{ display: "flex", flexDirection: "column", gap: "14px", marginTop: "22px" }}>
          {[
            { num: "01", q: "Apa yang dikumpulkan?", title: "Menghimpun Pengetahuan dari Berbagai Sumber", desc: "Mengumpulkan hasil riset, kajian, pemikiran, gagasan, laporan, dan dokumentasi dari beragam bidang ke dalam satu sistem yang menyatukan apa yang sebelumnya terpencar.", color: "#3B82F6" },
            { num: "02", q: "Bagaimana disusun?", title: "Menyusun Materi Agar Mudah Ditelusuri", desc: "Mengelompokkan setiap publikasi berdasarkan bidang, kategori, dan jenis sehingga pencarian kembali menjadi cepat dan tidak melelahkan.", color: "#10B981" },
            { num: "03", q: "Bagaimana disajikan?", title: "Menyajikan Informasi dengan Konteks Jelas", desc: "Melengkapi setiap materi dengan keterangan asal, waktu, dan latar belakangnya agar makna informasi tetap utuh ketika dibaca kembali.", color: "#F59E0B" },
            { num: "04", q: "Bagaimana dicatat?", title: "Membangun Dokumentasi yang Berkelanjutan", desc: "Mencatat proses, keputusan, dan perkembangan dari setiap kegiatan sehingga rekam jejaknya tidak hilang seiring waktu.", color: "#8B5CF6" },
            { num: "05", q: "Siapa dilayani?", title: "Membuka Akses bagi Berbagai Kalangan", desc: "Menyediakan ruang yang dapat diakses oleh pelajar, peneliti, profesional, kreator, komunitas, maupun masyarakat umum tanpa batasan lembaga.", color: "#EC4899" },
            { num: "06", q: "Apa yang ditumbuhkan?", title: "Menumbuhkan Kebiasaan Belajar dan Berkarya", desc: "Mendorong pembaca untuk terus memperluas wawasan dan kontributor untuk terus menulis, sehingga pengetahuan tumbuh dari dua arah.", color: "#0EA5E9" },
          ].map((t, idx) => {
            const isEven = idx % 2 === 0;
            return (
              <div key={t.num} style={{ display: "grid", gridTemplateColumns: isEven ? "80px 1fr 1fr" : "1fr 1fr 80px", gap: "20px", alignItems: "stretch", background: "white", borderRadius: "16px", padding: "20px 22px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)" }}>
                {/* number badge — positioned based on even/odd */}
                <div style={{ order: isEven ? 1 : 3, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <div style={{ width: "60px", height: "60px", borderRadius: "16px", background: `linear-gradient(135deg, ${t.color} 0%, ${t.color}cc 100%)`, display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontSize: "22px", fontWeight: 800, boxShadow: `0 6px 16px ${t.color}40` }}>
                    {t.num}
                  </div>
                </div>
                {/* question */}
                <div style={{ order: isEven ? 2 : 2, display: "flex", flexDirection: "column", justifyContent: "center", borderLeft: isEven ? "none" : `3px solid ${t.color}`, borderRight: isEven ? `3px solid ${t.color}` : "none", paddingLeft: isEven ? 0 : 16, paddingRight: isEven ? 16 : 0 }}>
                  <div style={{ fontSize: "10px", fontWeight: 800, color: t.color, letterSpacing: "1.5px", marginBottom: "6px" }}>PERTANYAAN</div>
                  <div style={{ fontSize: "14px", fontWeight: 700, color: "#0B3B3A", lineHeight: 1.4 }}>{t.q}</div>
                </div>
                {/* title + desc */}
                <div style={{ order: isEven ? 3 : 1, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <h4 style={{ fontSize: "15.5px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 6px 0", lineHeight: 1.3 }}>{t.title}</h4>
                  <p style={{ fontSize: "12.5px", lineHeight: 1.65, color: "#5B7A78", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{t.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* =====================================================
          3. FUNGSI INFOTRINK — circular orbit diagram (NEW design)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#10B981") }}>Enam Fungsi Utama</h2>
        <p style={P}>
          Fungsi adalah peran yang dijalankan INFOTRINK saat ini, hari ini, bukan sasaran ke depan. Enam fungsi berikut saling melengkapi — jika satu fungsi hilang, peran INFOTRINK menjadi pincang. Diagram orbital menunjukkan posisi setiap fungsi yang mengelilingi inti platform.
        </p>

        {/* orbit diagram — different from previous convergence */}
        <div style={{ background: "white", borderRadius: "18px", padding: "32px 26px 26px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", margin: "20px 0" }}>
          <svg width="100%" height="500" viewBox="0 0 1140 500" style={{ display: "block" }}>
            {/* outer orbit ring */}
            <circle cx="570" cy="250" r="220" fill="none" stroke="#0B6E6A" strokeWidth="1.5" strokeDasharray="3 6" opacity="0.3" />
            <circle cx="570" cy="250" r="160" fill="none" stroke="#0B6E6A" strokeWidth="1.5" strokeDasharray="3 6" opacity="0.2" />

            {/* connector lines from center to each function */}
            {[
              { angle: -90, color: "#3B82F6" },
              { angle: -30, color: "#10B981" },
              { angle: 30, color: "#F59E0B" },
              { angle: 90, color: "#8B5CF6" },
              { angle: 150, color: "#EC4899" },
              { angle: 210, color: "#0EA5E9" },
            ].map((f, i) => {
              const rad = (f.angle * Math.PI) / 180;
              const x = 570 + 220 * Math.cos(rad);
              const y = 250 + 220 * Math.sin(rad);
              return <line key={i} x1="570" y1="250" x2={x} y2={y} stroke={f.color} strokeWidth="1.5" opacity="0.4" strokeDasharray="2 4" />;
            })}

            {/* 6 function nodes around orbit */}
            {[
              { angle: -90, color: "#3B82F6", title: "Wadah", desc: "Penyatuan" },
              { angle: -30, color: "#10B981", title: "Pusat", desc: "Penelusuran" },
              { angle: 30, color: "#F59E0B", title: "Sarana", desc: "Publikasi" },
              { angle: 90, color: "#8B5CF6", title: "Arsip", desc: "Dokumentasi" },
              { angle: 150, color: "#EC4899", title: "Ruang", desc: "Pembelajaran" },
              { angle: 210, color: "#0EA5E9", title: "Jembatan", desc: "Antar Generasi" },
            ].map((f, i) => {
              const rad = (f.angle * Math.PI) / 180;
              const x = 570 + 220 * Math.cos(rad);
              const y = 250 + 220 * Math.sin(rad);
              return (
                <g key={i}>
                  <circle cx={x} cy={y} r="50" fill={f.color} opacity="0.12" />
                  <circle cx={x} cy={y} r="38" fill={f.color} />
                  <text x={x} y={y - 2} textAnchor="middle" fontSize="13" fontWeight="800" fill="white">{f.title}</text>
                  <text x={x} y={y + 14} textAnchor="middle" fontSize="9" fontWeight="600" fill="white" opacity="0.9">{f.desc}</text>
                </g>
              );
            })}

            {/* center hub — INFOTRINK */}
            <circle cx="570" cy="250" r="100" fill="#0B6E6A" opacity="0.08" />
            <circle cx="570" cy="250" r="75" fill="url(#fungsiGrad)" />
            <defs>
              <linearGradient id="fungsiGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#0B3B3A" />
                <stop offset="100%" stopColor="#0B6E6A" />
              </linearGradient>
            </defs>
            <text x="570" y="246" textAnchor="middle" fontSize="16" fontWeight="800" fill="white">INFOTRINK</text>
            <text x="570" y="266" textAnchor="middle" fontSize="9.5" fontWeight="600" fill="#81F6EF" letterSpacing="1.5">PERAN INTI</text>
          </svg>
        </div>
        <p style={CAP}>Gambar 1. Enam fungsi INFOTRINK yang mengelilingi inti platform, saling melengkapi.</p>

        {/* function detail grid */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "14px", marginTop: "16px" }}>
          {[
            { title: "Wadah Penyatuan", desc: "Menyatukan materi yang tersebar di banyak tempat menjadi satu sistem.", color: "#3B82F6" },
            { title: "Pusat Penelusuran", desc: "Menyediakan cara cepat untuk mencari dan menemukan kembali materi.", color: "#10B981" },
            { title: "Sarana Publikasi", desc: "Memberi ruang bagi penulis untuk menerbitkan karya secara tertata.", color: "#F59E0B" },
            { title: "Arsip Dokumentasi", desc: "Menyimpan rekam jejak kegiatan dan perkembangan dari waktu ke waktu.", color: "#8B5CF6" },
            { title: "Ruang Pembelajaran", desc: "Menyediakan bahan bacaan yang dapat dipelajari secara berurutan.", color: "#EC4899" },
            { title: "Jembatan Antar Generasi", desc: "Menyalurkan pengalaman generasi senior ke generasi berikutnya.", color: "#0EA5E9" },
          ].map((f) => (
            <div key={f.title} style={{ background: "white", borderRadius: "12px", padding: "16px 18px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 2px 8px rgba(11, 59, 58, 0.04)", borderLeft: `4px solid ${f.color}` }}>
              <h4 style={{ fontSize: "13.5px", fontWeight: 800, color: f.color, margin: "0 0 6px 0" }}>{f.title}</h4>
              <p style={{ fontSize: "12px", lineHeight: 1.6, color: "#5B7A78", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* =====================================================
          4. TUJUAN vs FUNGSI — comparison
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#F59E0B") }}>Tujuan vs Fungsi</h2>
        <p style={P}>
          Dua hal ini sering tertukar. Tujuan adalah sasaran yang ingin dicapai di masa depan; fungsi adalah peran yang dijalankan hari ini. Berikut perbandingan langsung agar perbedaannya jelas.
        </p>

        {/* 2-column comparison */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginTop: "20px" }}>
          {/* tujuan */}
          <div style={{ background: "white", borderRadius: "16px", overflow: "hidden", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)" }}>
            <div style={{ background: "linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)", padding: "18px 24px", color: "white" }}>
              <div style={{ fontSize: "10px", fontWeight: 800, letterSpacing: "2px", opacity: 0.85 }}>SASARAN KE DEPAN</div>
              <div style={{ fontSize: "20px", fontWeight: 800, marginTop: "4px" }}>Tujuan</div>
            </div>
            <div style={{ padding: "20px 24px" }}>
              <p style={{ fontSize: "13.5px", lineHeight: 1.7, color: "#1F2937", margin: "0 0 14px 0", textAlign: "justify", textJustify: "inter-word" }}>
                Apa yang ingin dicapai INFOTRINK dalam jangka panjang. Tujuan memberi arah — tanpa tujuan, semua usaha berjalan tanpa tahu ke mana harus sampai.
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: "8px", paddingTop: "12px", borderTop: "1px solid rgba(11, 110, 106, 0.08)" }}>
                <div style={{ display: "flex", gap: "8px", fontSize: "12px" }}>
                  <span style={{ color: "#3B82F6", fontWeight: 800 }}>Waktu:</span>
                  <span style={{ color: "#5B7A78" }}>&nbsp;Masa depan</span>
                </div>
                <div style={{ display: "flex", gap: "8px", fontSize: "12px" }}>
                  <span style={{ color: "#3B82F6", fontWeight: 800 }}>Sifat:</span>
                  <span style={{ color: "#5B7A78" }}>&nbsp;Sasaran yang dicapai</span>
                </div>
                <div style={{ display: "flex", gap: "8px", fontSize: "12px" }}>
                  <span style={{ color: "#3B82F6", fontWeight: 800 }}>Pertanyaan:</span>
                  <span style={{ color: "#5B7A78" }}>&nbsp;"Ke mana?"</span>
                </div>
              </div>
            </div>
          </div>

          {/* fungsi */}
          <div style={{ background: "white", borderRadius: "16px", overflow: "hidden", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)" }}>
            <div style={{ background: "linear-gradient(135deg, #10B981 0%, #059669 100%)", padding: "18px 24px", color: "white" }}>
              <div style={{ fontSize: "10px", fontWeight: 800, letterSpacing: "2px", opacity: 0.85 }}>PERAN SAAT INI</div>
              <div style={{ fontSize: "20px", fontWeight: 800, marginTop: "4px" }}>Fungsi</div>
            </div>
            <div style={{ padding: "20px 24px" }}>
              <p style={{ fontSize: "13.5px", lineHeight: 1.7, color: "#1F2937", margin: "0 0 14px 0", textAlign: "justify", textJustify: "inter-word" }}>
                Apa yang dijalankan INFOTRINK saat ini. Fungsi memberi dasar — tanpa fungsi, tujuan hanya menjadi angan-angan tanpa cara untuk mencapainya.
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: "8px", paddingTop: "12px", borderTop: "1px solid rgba(11, 110, 106, 0.08)" }}>
                <div style={{ display: "flex", gap: "8px", fontSize: "12px" }}>
                  <span style={{ color: "#10B981", fontWeight: 800 }}>Waktu:</span>
                  <span style={{ color: "#5B7A78" }}>&nbsp;Saat ini</span>
                </div>
                <div style={{ display: "flex", gap: "8px", fontSize: "12px" }}>
                  <span style={{ color: "#10B981", fontWeight: 800 }}>Sifat:</span>
                  <span style={{ color: "#5B7A78" }}>&nbsp;Peran yang dijalankan</span>
                </div>
                <div style={{ display: "flex", gap: "8px", fontSize: "12px" }}>
                  <span style={{ color: "#10B981", fontWeight: 800 }}>Pertanyaan:</span>
                  <span style={{ color: "#5B7A78" }}>&nbsp;"Apa yang dilakukan?"</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* =====================================================
          5. SKENARIO PENGGUNAAN — storyboard cards
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#8B5CF6") }}>Skenario Penggunaan Nyata</h2>
        <p style={P}>
          Tujuan dan fungsi yang sudah dijelaskan mungkin terdengar abstrak. Berikut empat skenario konkret yang menunjukkan bagaimana keduanya bekerja dalam praktik sehari-hari, dengan siapa, dan untuk apa.
        </p>

        {/* visual: function image */}
        <div style={{ margin: "18px 0", width: "100%", height: "180px", borderRadius: "14px", overflow: "hidden", boxShadow: "0 6px 18px rgba(11, 59, 58, 0.1)" }}>
          <Image src="/slide/tujuan-fungsi.png" alt="Struktur fondasi yang merepresentasikan fungsi-fungsi INFOTRINK" width={1280} height={180} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center", display: "block" }} unoptimized />
        </div>
        <p style={CAP}>Gambar 2. Fungsi-fungsi INFOTRINK sebagai fondasi yang menopang berbagai skenario penggunaan.</p>

        {/* 4 scenario storyboard cards */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginTop: "8px" }}>
          {[
            {
              num: "01", person: "Pelajar", situation: "Mengerjakan tugas sekolah",
              need: "Mencari bahan bacaan tambahan di luar materi kuliah.",
              how: "Membuka menu Publikasi, memilih kategori yang relevan, membaca materi yang tersusun per tingkat pemahaman.",
              outcome: "Tugas selesai dengan referensi yang jelas asalnya.",
              color: "#3B82F6",
            },
            {
              num: "02", person: "Peneliti", situation: "Membagikan hasil riset",
              need: "Riset sudah selesai, ingin dibaca oleh pembaca di luar kampus.",
              how: "Menerbitkan riset di INFOTRINK dengan kategori yang sesuai, lengkap dengan abstrak dan referensi.",
              outcome: "Riset terjangkau pembaca yang lebih luas dan tidak hilang di arsip pribadi.",
              color: "#10B981",
            },
            {
              num: "03", person: "Profesional", situation: "Mendokumentasikan proyek",
              need: "Proyek selesai, ingin mencatat pelajaran agar tidak terulang kesalahan yang sama.",
              how: "Menulis laporan proses di INFOTRINK, lengkap dengan hambatan, keputusan, dan alasan di baliknya.",
              outcome: "Proyek berikutnya dapat berjalan lebih cepat karena ada catatan sebelumnya.",
              color: "#F59E0B",
            },
            {
              num: "04", person: "Komunitas", situation: "Mengarsipkan kegiatan",
              need: "Banyak kegiatan dilakukan, tapi tidak ada catatan permanen yang dapat diakses anggota baru.",
              how: "Mengunggah dokumentasi setiap kegiatan ke INFOTRINK dengan kategori komunitas.",
              outcome: "Anggota baru dapat memahami sejarah dan konteks komunitas dengan cepat.",
              color: "#EC4899",
            },
          ].map((s) => (
            <div key={s.num} style={{ background: "white", borderRadius: "16px", overflow: "hidden", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)" }}>
              {/* header */}
              <div style={{ background: `linear-gradient(135deg, ${s.color} 0%, ${s.color}cc 100%)`, padding: "14px 20px", color: "white", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <div>
                  <div style={{ fontSize: "10px", fontWeight: 800, letterSpacing: "2px", opacity: 0.85 }}>SKENARIO {s.num}</div>
                  <div style={{ fontSize: "16px", fontWeight: 800, marginTop: "2px" }}>{s.person}</div>
                </div>
                <div style={{ fontSize: "11px", opacity: 0.9, fontStyle: "italic", textAlign: "right", maxWidth: "180px" }}>{s.situation}</div>
              </div>
              {/* body — 3 step flow */}
              <div style={{ padding: "16px 20px 18px" }}>
                {/* need */}
                <div style={{ marginBottom: "12px" }}>
                  <div style={{ fontSize: "9.5px", fontWeight: 800, color: s.color, letterSpacing: "1.5px", marginBottom: "4px" }}>KEBUTUHAN</div>
                  <p style={{ fontSize: "12.5px", lineHeight: 1.6, color: "#1F2937", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{s.need}</p>
                </div>
                {/* how */}
                <div style={{ marginBottom: "12px" }}>
                  <div style={{ fontSize: "9.5px", fontWeight: 800, color: s.color, letterSpacing: "1.5px", marginBottom: "4px" }}>CARA DI INFOTRINK</div>
                  <p style={{ fontSize: "12.5px", lineHeight: 1.6, color: "#1F2937", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{s.how}</p>
                </div>
                {/* outcome */}
                <div style={{ padding: "10px 12px", background: `${s.color}08`, borderRadius: "8px", borderLeft: `3px solid ${s.color}` }}>
                  <div style={{ fontSize: "9.5px", fontWeight: 800, color: s.color, letterSpacing: "1.5px", marginBottom: "3px" }}>HASIL</div>
                  <p style={{ fontSize: "12.5px", lineHeight: 1.55, color: "#1F2937", margin: 0, fontWeight: 600 }}>{s.outcome}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* =====================================================
          6. PEMANGKU KEPENTINGAN — actual table
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#EC4899") }}>Pemangku Kepentingan &amp; Tujuan Mereka</h2>
        <p style={P}>
          Setiap kelompok yang dilayani INFOTRINK punya tujuan masing-masing. Tabel berikut memetakan siapa mereka, apa tujuan mereka, dan bagaimana INFOTRINK menjawab tujuan tersebut.
        </p>

        {/* stakeholder table */}
        <div style={{ margin: "18px 0", overflow: "hidden", borderRadius: "14px", border: "1px solid rgba(11, 110, 106, 0.12)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "13.5px" }}>
            <thead>
              <tr style={{ background: "linear-gradient(90deg, #0B3B3A 0%, #0B6E6A 100%)" }}>
                <th style={{ padding: "14px 16px", textAlign: "left", color: "white", fontWeight: 700, width: "22%" }}>Pemangku</th>
                <th style={{ padding: "14px 16px", textAlign: "left", color: "white", fontWeight: 700, width: "34%" }}>Tujuan Mereka</th>
                <th style={{ padding: "14px 16px", textAlign: "left", color: "white", fontWeight: 700 }}>Jawaban INFOTRINK</th>
              </tr>
            </thead>
            <tbody>
              {[
                ["Pembaca Umum", "Mencari bahan bacaan yang dapat dipercaya", "Materi tersusun per kategori dengan konteks yang jelas"],
                ["Pelajar & Mahasiswa", "Memperluas pemahaman di luar materi kuliah", "Bahan bacaan tambahan dari berbagai bidang"],
                ["Peneliti & Akademisi", "Membagikan hasil riset ke pembaca luas", "Ruang publikasi dengan struktur akademis"],
                ["Profesional & Praktisi", "Mendokumentasikan pengalaman kerja", "Sistem dokumentasi yang dapat ditelusuri"],
                ["Kreator & Penulis", "Menerbitkan gagasan dan karya", "Tempat publikasi yang tertata per kategori"],
                ["Komunitas & Organisasi", "Mengarsipkan kegiatan dan proyek", "Arsip visual dan dokumentasi terstruktur"],
              ].map((row, ri) => (
                <tr key={ri} style={{ background: ri % 2 === 0 ? "white" : "#F4FBFA", borderBottom: "1px solid rgba(11, 110, 106, 0.06)" }}>
                  <td style={{ padding: "12px 16px", color: "#0B3B3A", fontWeight: 700 }}>{row[0]}</td>
                  <td style={{ padding: "12px 16px", color: "#1F2937", lineHeight: 1.55 }}>{row[1]}</td>
                  <td style={{ padding: "12px 16px", color: "#5B7A78", lineHeight: 1.55, fontStyle: "italic" }}>{row[2]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p style={CAP}>Tabel 1. Pemetaan pemangku kepentingan INFOTRINK dengan tujuan dan jawaban mereka.</p>
      </div>

      {/* =====================================================
          7. INDIKATOR KUALITAS — progress bars (NEW design)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0EA5E9") }}>Indikator Kualitas</h2>
        <p style={P}>
          Untuk mengetahui apakah tujuan dan fungsi benar-benar tercapai, dibutuhkan indikator yang dapat diukur. Berikut lima indikator kualitas yang menjadi tolok ukur, beserta target tingkat pencapaiannya.
        </p>

        {/* progress bars — NEW design type */}
        <div style={{ background: "white", borderRadius: "16px", padding: "26px 28px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", margin: "18px 0" }}>
          {[
            { label: "Keteraturan Materi", target: "Setiap materi punya kategori & konteks yang jelas", level: 80, color: "#3B82F6" },
            { label: "Kemudahan Penelusuran", target: "Pencarian kembali cepat & tidak melelahkan", level: 75, color: "#10B981" },
            { label: "Kelengkapan Dokumentasi", target: "Proses, keputusan, dan hasil tercatat utuh", level: 60, color: "#F59E0B" },
            { label: "Keberagaman Bidang", target: "Materi mencakup berbagai bidang, tidak satu topik", level: 70, color: "#8B5CF6" },
            { label: "Keberlanjutan Pembaruan", target: "Materi terus diperbarui seiring perkembangan", level: 65, color: "#EC4899" },
          ].map((ind, i) => (
            <div key={ind.label} style={{ marginBottom: i < 4 ? "20px" : "0" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: "8px" }}>
                <div>
                  <span style={{ fontSize: "14px", fontWeight: 800, color: "#0B3B3A" }}>{ind.label}</span>
                  <span style={{ fontSize: "11.5px", color: "#9CB3B0", marginLeft: "10px", fontStyle: "italic" }}>{ind.target}</span>
                </div>
                <span style={{ fontSize: "16px", fontWeight: 800, color: ind.color }}>Target {ind.level}%</span>
              </div>
              {/* progress bar */}
              <div style={{ position: "relative", width: "100%", height: "10px", background: "#F1F5F4", borderRadius: "999px", overflow: "hidden" }}>
                <div style={{ position: "absolute", top: 0, left: 0, height: "100%", width: `${ind.level}%`, background: `linear-gradient(90deg, ${ind.color} 0%, ${ind.color}cc 100%)`, borderRadius: "999px", boxShadow: `0 1px 4px ${ind.color}40` }} />
              </div>
            </div>
          ))}
        </div>
        <p style={CAP}>Tabel 2. Indikator kualitas dengan target tingkat pencapaian yang ingin diraih.</p>
      </div>

      {/* =====================================================
          8. POSISI HALAMAN — flow diagram
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Posisi Halaman Ini</h2>
        <p style={P}>
          Halaman ini adalah bagian ketiga dari rangkaian Mengenal INFOTRINK. Setelah memahami apa (Pengenalan) dan mengapa (Latar Belakang), pembaca kini memahami untuk apa (Tujuan dan Fungsi). Berikut alur lengkapnya.
        </p>

        {/* horizontal flow with this page highlighted */}
        <div style={{ background: "white", borderRadius: "16px", padding: "28px 24px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", margin: "18px 0" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "8px" }}>
            {[
              { name: "Pengenalan", q: "Apa", color: "#3B82F6", current: false },
              { name: "Latar Belakang", q: "Mengapa", color: "#8B5CF6", current: false },
              { name: "Tujuan & Fungsi", q: "Untuk Apa", color: "#0B6E6A", current: true },
              { name: "Ruang Lingkup", q: "Sampai Mana", color: "#F59E0B", current: false },
              { name: "Prinsip", q: "Bagaimana", color: "#EC4899", current: false },
            ].map((p, i, arr) => (
              <div key={p.name} style={{ flex: 1, display: "flex", alignItems: "center" }}>
                <div style={{ flex: 1, textAlign: "center", padding: p.current ? "16px 8px" : "12px 8px", background: p.current ? "linear-gradient(135deg, #0B3B3A 0%, #0B6E6A 100%)" : `${p.color}08`, borderRadius: "12px", border: p.current ? "2px solid #0B6E6A" : `1px solid ${p.color}25`, boxShadow: p.current ? "0 6px 18px rgba(11, 110, 106, 0.25)" : "none", transform: p.current ? "scale(1.05)" : "scale(1)" }}>
                  <div style={{ fontSize: "9px", fontWeight: 800, color: p.current ? "#81F6EF" : p.color, letterSpacing: "1.5px", marginBottom: "4px" }}>{p.q.toUpperCase()}</div>
                  <div style={{ fontSize: "12px", fontWeight: 800, color: p.current ? "white" : "#0B3B3A" }}>{p.name}</div>
                  {p.current && <div style={{ fontSize: "9px", color: "#81F6EF", marginTop: "3px", fontWeight: 700 }}>&#9658; HALAMAN INI</div>}
                </div>
                {i < arr.length - 1 && (
                  <div style={{ display: "flex", alignItems: "center", padding: "0 4px" }}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M5 12h14m0 0l-6-6m6 6l-6 6" stroke="#0B6E6A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* =====================================================
          9. PENUTUP + NAVIGATION
      ===================================================== */}
      <div style={{ marginBottom: "20px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Penutup</h2>
        <p style={P}>
          Tujuan memberi arah, fungsi memberi dasar. INFOTRINK menjalankan enam fungsi hari ini untuk mencapai satu tujuan umum di masa depan, yang dijabarkan kembali menjadi enam tujuan khusus yang dapat ditelusuri. Setiap skenario penggunaan, pemangku kepentingan, dan indikator kualitas di atas berhubungan dengan keduanya — bukan mengulang penjelasan, melainkan menunjukkan bagaimana tujuan dan fungsi terwujud dalam praktik.
        </p>
        <p style={P}>
          Setelah memahami untuk apa INFOTRINK ada, langkah berikutnya adalah mengetahui sampai di mana cakupannya — yang akan dijelaskan pada halaman Ruang Lingkup.
        </p>

        {/* navigation cards */}
        <div style={{ marginTop: "24px", paddingTop: "24px", borderTop: "1px solid rgba(11, 110, 106, 0.1)" }}>
          <h3 style={{ fontSize: "15px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 14px 0", display: "flex", alignItems: "center", gap: "8px" }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M13 7l5 5m0 0l-5 5m5-5H6" stroke="#0B6E6A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
            Lanjutkan ke Bagian Lainnya
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "14px" }}>
            {[
              { name: "Pengenalan INFOTRINK", menu: "Mengenal INFOTRINK", submenu: "Pengenalan INFOTRINK", color: "#3B82F6", svg: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" },
              { name: "Latar Belakang", menu: "Mengenal INFOTRINK", submenu: "Latar Belakang", color: "#10B981", svg: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" },
              { name: "Ruang Lingkup", menu: "Mengenal INFOTRINK", submenu: "Ruang Lingkup", color: "#F59E0B", svg: "M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" },
              { name: "Prinsip Pengelolaan", menu: "Mengenal INFOTRINK", submenu: "Prinsip Pengelolaan", color: "#8B5CF6", svg: "M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" },
            ].map((item) => (
              <div
                key={item.name}
                onClick={() => onOpenSubmenu(item.menu, item.submenu)}
                style={{ cursor: "pointer", background: "white", borderRadius: "14px", padding: "18px 16px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 12px rgba(11, 59, 58, 0.05)", transition: "all 0.2s ease", borderTop: `3px solid ${item.color}` }}
                onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = "0 8px 20px rgba(11, 59, 58, 0.1)"; }}
                onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "0 4px 12px rgba(11, 59, 58, 0.05)"; }}
              >
                <div style={{ width: "38px", height: "38px", borderRadius: "10px", background: `${item.color}15`, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "10px" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d={item.svg} stroke={item.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
                <div style={{ fontSize: "13.5px", fontWeight: 800, color: "#0B3B3A", marginBottom: "4px", lineHeight: 1.25 }}>{item.name}</div>
                <div style={{ display: "flex", alignItems: "center", gap: "4px", fontSize: "11px", color: item.color, fontWeight: 700 }}>
                  Baca selengkapnya
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M5 12h14m0 0l-6-6m6 6l-6 6" stroke={item.color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// RUANG LINGKUP PAGE — menjawab "sampai mana" cakupan INFOTRINK
// ============================================================
function RuangLingkupPage({ onOpenSubmenu }: { onOpenSubmenu: (menu: string, submenu: string) => void }) {
  const H2 = {
    fontSize: "22px",
    fontWeight: 800,
    color: "#0B3B3A",
    margin: "0 0 14px 0",
    lineHeight: 1.3,
    letterSpacing: "-0.2px",
  } as const;
  const H2Bar = (color = "#0B6E6A") => ({
    borderLeft: `4px solid ${color}`,
    paddingLeft: "14px",
  });
  const P = {
    fontSize: "15px",
    lineHeight: 1.85,
    color: "#1F2937",
    margin: "0 0 14px 0",
    textAlign: "justify" as const,
    textJustify: "inter-word" as const,
  };
  const CAP = {
    fontSize: "12px",
    color: "#9CB3B0",
    textAlign: "center" as const,
    margin: "8px 0 28px 0",
    fontStyle: "italic" as const,
  };

  return (
    <div style={{ padding: "165px 70px 60px", color: "#1F2937" }}>
      {/* =====================================================
          0. HERO — full-width banner dengan overlay teks (NEW style)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <div style={{ position: "relative", width: "100%", height: "380px", borderRadius: "18px", overflow: "hidden", boxShadow: "0 12px 36px rgba(11, 59, 58, 0.2)", marginBottom: "28px" }}>
          <Image src="/slide/ruang-boundary.png" alt="Cakupan ruang lingkup INFOTRINK yang meluas dari pusat" width={1280} height={380} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} unoptimized priority />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(90deg, rgba(11,59,58,0.85) 0%, rgba(11,59,58,0.4) 60%, rgba(11,59,58,0.15) 100%)" }} />
          <div style={{ position: "absolute", left: "40px", top: "40px", right: "40px", bottom: "40px", color: "white", display: "flex", flexDirection: "column", justifyContent: "center" }}>
            <div style={{ fontSize: "11px", fontWeight: 800, color: "#81F6EF", letterSpacing: "2.5px", marginBottom: "12px" }}>SAMPAI MANA CAKUPAN INFOTRINK</div>
            <h1 style={{ fontSize: "44px", fontWeight: 800, margin: "0 0 14px 0", letterSpacing: "-0.8px", lineHeight: 1.05, maxWidth: "700px" }}>
              Ruang Lingkup <BrandText text="INFOTRINK" />
            </h1>
            <p style={{ fontSize: "15.5px", lineHeight: 1.7, margin: 0, maxWidth: "680px", opacity: 0.95, textAlign: "justify", textJustify: "inter-word" }}>
              Halaman ini menjelaskan batas yang jelas antara apa yang masuk ruang lingkup INFOTRINK dan apa yang tidak, kedalaman materi yang dicakup, siapa pembaca yang dilayani, hingga arah perluasan ke depan. Tanpa pemahaman batas, platform bisa kehilangan fokus dan menampung hal-hal yang seharusnya tidak menjadi bagiannya.
            </p>
          </div>
        </div>
      </div>

      {/* =====================================================
          1. TIGA DIMENSI CAKUPAN — pyramid stack diagram (NEW)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Tiga Dimensi Cakupan</h2>
        <p style={P}>
          Ruang lingkup INFOTRINK tidak hanya soal topik, melainkan tiga dimensi yang saling menentukan: cakupan topik (bidang apa saja), cakupan kedalaman (sampai seberapa dalam), dan cakupan pembaca (untuk siapa). Ketiganya digambarkan sebagai lapisan yang menopang satu sama lain.
        </p>

        {/* pyramid/stacked layers diagram */}
        <div style={{ background: "white", borderRadius: "18px", padding: "36px 28px 28px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", margin: "20px 0" }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "10px" }}>
            {/* layer 1 - top (narrow) */}
            <div style={{ width: "55%", background: "linear-gradient(135deg, #0B3B3A 0%, #0B6E6A 100%)", color: "white", padding: "20px 30px", borderRadius: "12px", textAlign: "center", boxShadow: "0 6px 18px rgba(11, 110, 106, 0.25)" }}>
              <div style={{ fontSize: "10px", fontWeight: 800, color: "#81F6EF", letterSpacing: "2px", marginBottom: "6px" }}>LAPISAN ATAS</div>
              <div style={{ fontSize: "18px", fontWeight: 800, marginBottom: "4px" }}>Cakupan Pembaca</div>
              <div style={{ fontSize: "12px", opacity: 0.9 }}>Untuk siapa materi ditujukan</div>
            </div>
            {/* layer 2 - middle */}
            <div style={{ width: "75%", background: "linear-gradient(135deg, #10B981 0%, #059669 100%)", color: "white", padding: "20px 30px", borderRadius: "12px", textAlign: "center", boxShadow: "0 6px 18px rgba(16, 185, 129, 0.25)" }}>
              <div style={{ fontSize: "10px", fontWeight: 800, color: "white", opacity: 0.85, letterSpacing: "2px", marginBottom: "6px" }}>LAPISAN TENGAH</div>
              <div style={{ fontSize: "18px", fontWeight: 800, marginBottom: "4px" }}>Cakupan Kedalaman</div>
              <div style={{ fontSize: "12px", opacity: 0.9 }}>Sampai seberapa dalam materi dibahas</div>
            </div>
            {/* layer 3 - bottom (widest) */}
            <div style={{ width: "95%", background: "linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)", color: "white", padding: "20px 30px", borderRadius: "12px", textAlign: "center", boxShadow: "0 6px 18px rgba(59, 130, 246, 0.25)" }}>
              <div style={{ fontSize: "10px", fontWeight: 800, color: "white", opacity: 0.85, letterSpacing: "2px", marginBottom: "6px" }}>LAPISAN DASAR</div>
              <div style={{ fontSize: "18px", fontWeight: 800, marginBottom: "4px" }}>Cakupan Topik</div>
              <div style={{ fontSize: "12px", opacity: 0.9 }}>Bidang-bidang apa saja yang dihimpun</div>
            </div>
          </div>
          <p style={{ fontSize: "12.5px", color: "#9CB3B0", textAlign: "center", margin: "22px 0 0 0", fontStyle: "italic" }}>Gambar 1. Tiga lapisan dimensi cakupan INFOTRINK — topik sebagai dasar, kedalaman di tengah, pembaca di puncak.</p>
        </div>
      </div>

      {/* =====================================================
          2. YANG TERMASUK — honeycomb pattern (NEW)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#10B981") }}>Yang Termasuk dalam Ruang Lingkup</h2>
        <p style={P}>
          Berikut enam jenis materi yang masuk ruang lingkup INFOTRINK. Setiap jenis punya ciri yang berbeda — bukan tumpang-tindih — agar pembaca tahu apa yang bisa diharapkan dari platform ini.
        </p>

        {/* honeycomb grid - 6 hexagon-style cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "14px", marginTop: "22px" }}>
          {[
            { num: "01", title: "Artikel Informasi", desc: "Tulisan yang menjelaskan suatu hal secara terstruktur, dimulai dari pengenalan, pembahasan, hingga penutup.", color: "#3B82F6" },
            { num: "02", title: "Hasil Riset", desc: "Laporan penelitian dengan metodologi yang jelas, hasil yang dapat ditelusuri, dan kesimpulan yang berdasar.", color: "#10B981" },
            { num: "03", title: "Kajian & Analisis", desc: "Pembahasan mendalam terhadap suatu topik, lengkap dengan tinjauan, perbandingan, dan sudut pandang tertentu.", color: "#F59E0B" },
            { num: "04", title: "Laporan Kegiatan", desc: "Catatan proses dan hasil dari suatu kegiatan atau proyek, lengkap dengan hambatan, keputusan, dan pelajaran.", color: "#8B5CF6" },
            { num: "05", title: "Data & Referensi", desc: "Kumpulan data, statistik, atau referensi yang dapat digunakan sebagai bahan pendukung pembahasan lain.", color: "#EC4899" },
            { num: "06", title: "Gagasan & Konsep", desc: "Pemikiran, ide, atau rancangan konsep yang belum tentu berbentuk penelitian formal, namun memiliki nilai.", color: "#0EA5E9" },
          ].map((m) => (
            <div key={m.num} style={{ position: "relative", background: "white", borderRadius: "16px", padding: "22px 22px 20px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", overflow: "hidden" }}>
              {/* corner accent — diagonal stripe (NEW pattern) */}
              <div style={{ position: "absolute", top: "-30px", right: "-30px", width: "70px", height: "70px", background: `linear-gradient(135deg, transparent 50%, ${m.color}20 50%)`, transform: "rotate(0deg)" }} />
              <div style={{ position: "relative" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "12px" }}>
                  <span style={{ fontSize: "11px", fontWeight: 800, color: m.color, letterSpacing: "2px", padding: "3px 10px", background: `${m.color}12`, borderRadius: "999px" }}>#{m.num}</span>
                  <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: m.color }} />
                </div>
                <h4 style={{ fontSize: "15.5px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 8px 0" }}>{m.title}</h4>
                <p style={{ fontSize: "12.5px", lineHeight: 1.65, color: "#5B7A78", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{m.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* =====================================================
          3. YANG TIDAK TERMASUK — exclusion zone (NEW)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#EF4444") }}>Yang TIDAK Termasuk dalam Ruang Lingkup</h2>
        <p style={P}>
          Sama pentingnya dengan mengetahui apa yang masuk, adalah mengetahui apa yang tidak. Berikut empat hal yang sengaja dikeluarkan dari ruang lingkup INFOTRINK — bukan karena tidak penting, melainkan karena bukan bagian dari peran platform ini.
        </p>

        {/* 4 exclusion cards - red zone style */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "16px", marginTop: "20px" }}>
          {[
            { title: "Berita Harian", desc: "INFOTRINK bukan portal berita yang mengejar kecepatan pemberitaan harian. Berita peristiwa terkini diserahkan pada media yang memang fokus pada hal itu.", alasan: "Fokus INFOTRINK pada kedalaman, bukan kecepatan." },
            { title: "Transaksi & Jual-Beli", desc: "INFOTRINK tidak menyediakan fitur jual-beli, lelang, atau transaksi finansial. Platform ini berisi pengetahuan, bukan barang atau jasa.", alasan: "Pengetahuan dibagikan, bukan diperdagangkan." },
            { title: "Konten Tanpa Konteks", desc: "Unggahan singkat tanpa latar belakang, tanpa keterangan asal, atau tanpa keterkaitan dengan topik tertentu tidak masuk ruang lingkup.", alasan: "Setiap materi harus punya konteks yang jelas." },
            { title: "Opini Tanpa Dasar", desc: "Pandangan pribadi yang tidak didukung data, referensi, atau penjelasan tidak masuk ruang lingkup. Opini boleh, asal berlandaskan sesuatu.", alasan: "Setiap gagasan perlu dapat ditelusuri." },
          ].map((x) => (
            <div key={x.title} style={{ background: "white", borderRadius: "14px", padding: "20px 22px", border: "1px solid rgba(239, 68, 68, 0.18)", boxShadow: "0 4px 14px rgba(239, 68, 68, 0.06)", display: "flex", gap: "16px", alignItems: "flex-start", position: "relative" }}>
              {/* red X badge */}
              <div style={{ width: "40px", height: "40px", borderRadius: "12px", background: "rgba(239, 68, 68, 0.12)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><path d="M6 18L18 6M6 6l12 12" stroke="#EF4444" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
              </div>
              <div style={{ flex: 1 }}>
                <h4 style={{ fontSize: "15.5px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 8px 0", textDecoration: "line-through", textDecorationColor: "#EF4444", textDecorationThickness: "2px" }}>{x.title}</h4>
                <p style={{ fontSize: "13px", lineHeight: 1.65, color: "#1F2937", margin: "0 0 10px 0", textAlign: "justify", textJustify: "inter-word" }}>{x.desc}</p>
                <div style={{ padding: "8px 12px", background: "rgba(239, 68, 68, 0.06)", borderRadius: "8px", borderLeft: "3px solid #EF4444" }}>
                  <span style={{ fontSize: "10px", fontWeight: 800, color: "#EF4444", letterSpacing: "1.2px" }}>ALASAN: </span>
                  <span style={{ fontSize: "12px", color: "#5B7A78", fontStyle: "italic" }}>{x.alasan}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* =====================================================
          4. CAKUPAN PER BIDANG — horizontal bar scale (NEW)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#3B82F6") }}>Cakupan per Bidang</h2>
        <p style={P}>
          Tiga bidang utama menjadi fondasi awal INFOTRINK. Cakupan setiap bidang berbeda — ada yang sudah punya banyak materi, ada yang masih berkembang. Berikut kondisi cakupan saat ini, dengan indikator skala yang menunjukkan tingkat pengembangan masing-masing bidang.
        </p>

        {/* horizontal bar scale visualization */}
        <div style={{ background: "white", borderRadius: "16px", padding: "26px 28px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", margin: "18px 0" }}>
          {[
            { bidang: "Media Digital", focus: "Platform media sosial, aplikasi chatting, tren digital", skala: 75, color: "#3B82F6", kategori: "Sudah berkembang" },
            { bidang: "Pembangunan", focus: "Perencanaan, pelaksanaan, dokumentasi proyek", skala: 50, color: "#10B981", kategori: "Sedang berkembang" },
            { bidang: "Personal", focus: "Pemikiran, karya, catatan perkembangan diri", skala: 40, color: "#F59E0B", kategori: "Tahap awal" },
            { bidang: "Bidang Lainnya", focus: "Terbuka untuk perkembangan bidang baru", skala: 15, color: "#8B5CF6", kategori: "Akan datang" },
          ].map((b, i, arr) => (
            <div key={b.bidang} style={{ marginBottom: i < arr.length - 1 ? "22px" : "0" }}>
              <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", marginBottom: "8px" }}>
                <div>
                  <span style={{ fontSize: "15px", fontWeight: 800, color: "#0B3B3A" }}>{b.bidang}</span>
                  <span style={{ fontSize: "12px", color: "#5B7A78", marginLeft: "10px" }}>— {b.focus}</span>
                </div>
                <span style={{ fontSize: "11px", fontWeight: 700, color: b.color, padding: "3px 10px", background: `${b.color}12`, borderRadius: "999px" }}>{b.kategori}</span>
              </div>
              {/* bar */}
              <div style={{ position: "relative", width: "100%", height: "14px", background: "#F1F5F4", borderRadius: "999px", overflow: "hidden" }}>
                <div style={{ position: "absolute", top: 0, left: 0, height: "100%", width: `${b.skala}%`, background: `linear-gradient(90deg, ${b.color} 0%, ${b.color}dd 100%)`, borderRadius: "999px", display: "flex", alignItems: "center", justifyContent: "flex-end", paddingRight: "8px" }}>
                  <span style={{ fontSize: "10px", fontWeight: 800, color: "white" }}>{b.skala}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        <p style={CAP}>Gambar 2. Indikator skala cakupan per bidang — bukan tolok ukur kesuksesan, melainkan gambaran kondisi pengembangan saat ini.</p>
      </div>

      {/* =====================================================
          5. TINGKAT KEDALAMAN MATERI — stair-step ascending (NEW)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#F59E0B") }}>Tingkat Kedalaman Materi</h2>
        <p style={P}>
          INFOTRINK menampung materi dari yang paling dasar sampai yang paling mendalam. Empat tingkat berikut menunjukkan rentang kedalaman yang dicakup — pembaca pemula bisa mulai dari bawah, yang sudah berpengalaman bisa langsung ke atas.
        </p>

        {/* visual: kedalaman image */}
        <div style={{ margin: "18px 0", width: "100%", height: "180px", borderRadius: "14px", overflow: "hidden", boxShadow: "0 6px 18px rgba(11, 59, 58, 0.1)" }}>
          <Image src="/slide/ruang-kedalaman.png" alt="Tangga kedalaman materi dari dasar sampai lanjutan" width={1280} height={180} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center", display: "block" }} unoptimized />
        </div>

        {/* stair-step ascending diagram */}
        <div style={{ background: "white", borderRadius: "18px", padding: "32px 28px 28px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", margin: "18px 0" }}>
          <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: "12px", height: "280px" }}>
            {[
              { level: "Tingkat 1", title: "Pemula", desc: "Pengenalan dasar untuk yang baru mengenal topik", height: "30%", color: "#3B82F6" },
              { level: "Tingkat 2", title: "Menengah", desc: "Pembahasan lebih dalam dengan beberapa contoh", height: "55%", color: "#10B981" },
              { level: "Tingkat 3", title: "Lanjutan", desc: "Analisis menyeluruh dengan referensi pendukung", height: "78%", color: "#F59E0B" },
              { level: "Tingkat 4", title: "Ahli", desc: "Bahasan teknis mendalam untuk yang sudah berpengalaman", height: "100%", color: "#8B5CF6" },
            ].map((t) => (
              <div key={t.level} style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "flex-end", height: "100%" }}>
                {/* step block */}
                <div style={{ background: `linear-gradient(180deg, ${t.color} 0%, ${t.color}dd 100%)`, color: "white", padding: "18px 14px", borderRadius: "12px 12px 0 0", height: t.height, display: "flex", flexDirection: "column", justifyContent: "flex-start", boxShadow: `0 4px 14px ${t.color}30` }}>
                  <div style={{ fontSize: "9px", fontWeight: 800, color: "white", opacity: 0.85, letterSpacing: "1.5px", marginBottom: "4px" }}>{t.level.toUpperCase()}</div>
                  <div style={{ fontSize: "16px", fontWeight: 800, marginBottom: "8px" }}>{t.title}</div>
                  <p style={{ fontSize: "11px", lineHeight: 1.55, color: "white", opacity: 0.95, margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{t.desc}</p>
                </div>
              </div>
            ))}
          </div>
          {/* baseline */}
          <div style={{ height: "3px", background: "linear-gradient(90deg, #3B82F6 0%, #10B981 33%, #F59E0B 66%, #8B5CF6 100%)", borderRadius: "999px", margin: "0 0 16px 0" }} />
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: "11px", color: "#9CB3B0", fontWeight: 600 }}>
            <span>DASAR</span>
            <span style={{ fontSize: "13px", color: "#0B6E6A", fontWeight: 800 }}>↗ MENAIK BERURUTAN</span>
            <span>MENDALAM</span>
          </div>
        </div>
        <p style={CAP}>Gambar 3. Empat tingkat kedalaman materi yang dicakup INFOTRINK, dari pemula sampai ahli.</p>
      </div>

      {/* =====================================================
          6. MATRIX PEMBACA × KEDALAMAN — actual matrix grid (NEW)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#EC4899") }}>Siapa Pembaca, di Tingkat Apa</h2>
        <p style={P}>
          Untuk memahami ruang lingkup secara utuh, perlu diketahui siapa pembaca yang dilayani dan di tingkat kedalaman apa mereka berada. Matriks berikut memetakan kedua dimensi tersebut sekaligus — agar tidak ada pembaca yang tertinggal di antara tingkat.
        </p>

        {/* matrix table — pembaca × kedalaman */}
        <div style={{ margin: "20px 0", overflow: "hidden", borderRadius: "14px", border: "1px solid rgba(11, 110, 106, 0.12)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "13px" }}>
            <thead>
              <tr style={{ background: "linear-gradient(90deg, #0B3B3A 0%, #0B6E6A 100%)" }}>
                <th style={{ padding: "14px 16px", textAlign: "left", color: "white", fontWeight: 700, width: "22%" }}>Pembaca</th>
                <th style={{ padding: "14px 12px", textAlign: "center", color: "white", fontWeight: 700 }}>Pemula</th>
                <th style={{ padding: "14px 12px", textAlign: "center", color: "white", fontWeight: 700 }}>Menengah</th>
                <th style={{ padding: "14px 12px", textAlign: "center", color: "white", fontWeight: 700 }}>Lanjutan</th>
                <th style={{ padding: "14px 12px", textAlign: "center", color: "white", fontWeight: 700 }}>Ahli</th>
              </tr>
            </thead>
            <tbody>
              {[
                { reader: "Pelajar & Mahasiswa", levels: [true, true, false, false], color: "#3B82F6" },
                { reader: "Peneliti & Akademisi", levels: [false, true, true, true], color: "#10B981" },
                { reader: "Profesional & Praktisi", levels: [false, true, true, true], color: "#F59E0B" },
                { reader: "Kreator & Penulis", levels: [true, true, true, false], color: "#8B5CF6" },
                { reader: "Komunitas & Organisasi", levels: [true, true, false, false], color: "#EC4899" },
                { reader: "Masyarakat Umum", levels: [true, true, false, false], color: "#0EA5E9" },
              ].map((row, ri) => (
                <tr key={ri} style={{ background: ri % 2 === 0 ? "white" : "#F4FBFA", borderBottom: "1px solid rgba(11, 110, 106, 0.06)" }}>
                  <td style={{ padding: "12px 16px", color: row.color, fontWeight: 800 }}>{row.reader}</td>
                  {row.levels.map((val, ci) => (
                    <td key={ci} style={{ padding: "12px", textAlign: "center" }}>
                      {val ? (
                        <span style={{ display: "inline-flex", width: "26px", height: "26px", borderRadius: "8px", background: `${row.color}18`, alignItems: "center", justifyContent: "center", color: row.color, fontWeight: 800 }}>
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke={row.color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /></svg>
                        </span>
                      ) : (
                        <span style={{ display: "inline-flex", width: "26px", height: "26px", borderRadius: "8px", background: "#F1F5F4", alignItems: "center", justifyContent: "center", color: "#9CB3B0", fontWeight: 800, fontSize: "14px" }}>—</span>
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p style={CAP}>Tabel 1. Matriks pembaca × tingkat kedalaman — menunjukkan di tingkat mana setiap kelompok pembaca dilayani.</p>
        <p style={P}>
          Dari matriks di atas terlihat bahwa INFOTRINK melayani pembaca di berbagai tingkat, namun tidak setiap pembaca masuk ke semua tingkat. Pelajar lebih banyak dilayani di tingkat pemula-menengah, sementara peneliti dan profesional lebih banyak di tingkat lanjutan-ahli. Ini bukan pembatasan, melainkan penyesuaian dengan kebutuhan masing-masing kelompok.
        </p>
      </div>

      {/* =====================================================
          7. PERLUASAN RUANG LINGKUP — concentric expanding rings (NEW)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0EA5E9") }}>Perluasan Ruang Lingkup ke Depan</h2>
        <p style={P}>
          Ruang lingkup INFOTRINK tidak statis. Ia berkembang secara berlapis — mulai dari inti yang sudah ada, melebar ke bidang yang sedang disusun, hingga ke arah yang masih akan dipertimbangkan. Diagram berikut menunjukkan tiga lapis perluasan tersebut.
        </p>

        {/* redesigned: 2-column clean layout — diagram kiri, legend cards kanan */}
        <div style={{ background: "white", borderRadius: "18px", padding: "32px 32px 28px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", margin: "20px 0" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "32px", alignItems: "center" }}>
            {/* left: clean concentric rings SVG */}
            <div style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
              <svg width="100%" height="360" viewBox="0 0 460 360" style={{ display: "block", maxWidth: "460px" }}>
                {/* outer ring - akan dipertimbangkan */}
                <circle cx="230" cy="180" r="165" fill="#0EA5E9" fillOpacity="0.06" stroke="#0EA5E9" strokeWidth="2" strokeDasharray="6 6" strokeOpacity="0.5" />
                {/* middle ring - sedang disusun */}
                <circle cx="230" cy="180" r="115" fill="#10B981" fillOpacity="0.08" stroke="#10B981" strokeWidth="2" strokeOpacity="0.6" />
                {/* inner ring - sudah ada */}
                <circle cx="230" cy="180" r="70" fill="#0B6E6A" fillOpacity="0.12" stroke="#0B6E6A" strokeWidth="2.5" />
                {/* center hub */}
                <defs>
                  <linearGradient id="rlGrad" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#0B3B3A" />
                    <stop offset="100%" stopColor="#0B6E6A" />
                  </linearGradient>
                </defs>
                <circle cx="230" cy="180" r="48" fill="url(#rlGrad)" />
                <text x="230" y="176" textAnchor="middle" fontSize="13" fontWeight="800" fill="white">INFOTRINK</text>
                <text x="230" y="192" textAnchor="middle" fontSize="8.5" fontWeight="700" fill="#81F6EF" letterSpacing="1.5">INTI</text>

                {/* small connector dots on each ring (top of each ring) */}
                <circle cx="230" cy="115" r="5" fill="#0B6E6A" />
                <circle cx="230" cy="65" r="5" fill="#10B981" />
                <circle cx="230" cy="15" r="5" fill="#0EA5E9" />
              </svg>
            </div>

            {/* right: 3 stacked legend cards */}
            <div style={{ display: "flex", flexDirection: "column", gap: "14px" }}>
              {[
                { num: "1", label: "LAPISAN 1", status: "SUDAH ADA", title: "Inti yang Sudah Berjalan", desc: "Media Digital, Pembangunan, dan Personal — tiga bidang utama yang sudah punya struktur dan materi.", color: "#0B6E6A", ring: "lingkaran terdalam" },
                { num: "2", label: "LAPISAN 2", status: "SEDANG DISUSUN", title: "Pendalaman yang Berjalan", desc: "Pendalaman tiap bidang yang sudah ada — materi lebih kaya, contoh lebih banyak, kategori lebih rinci.", color: "#10B981", ring: "lingkaran tengah" },
                { num: "3", label: "LAPISAN 3", status: "AKAN DIPERTIMBANGKAN", title: "Bidang Baru di Masa Depan", desc: "Bidang baru yang relevan seiring perkembangan — terbuka untuk perluasan ketika sudah waktunya.", color: "#0EA5E9", ring: "lingkaran terluar", dashed: true },
              ].map((l) => (
                <div key={l.num} style={{ display: "flex", gap: "14px", alignItems: "stretch", padding: "16px 18px", background: `${l.color}06`, borderRadius: "14px", border: `1px solid ${l.color}25`, borderLeft: `4px solid ${l.color}` }}>
                  {/* number badge */}
                  <div style={{ width: "38px", height: "38px", borderRadius: "10px", background: `linear-gradient(135deg, ${l.color} 0%, ${l.color}dd 100%)`, display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontSize: "16px", fontWeight: 800, flexShrink: 0, alignSelf: "center" }}>
                    {l.num}
                  </div>
                  {/* content */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "5px" }}>
                      <span style={{ fontSize: "9.5px", fontWeight: 800, color: l.color, letterSpacing: "1.5px" }}>{l.label}</span>
                      <span style={{ fontSize: "9.5px", color: "#9CB3B0" }}>·</span>
                      <span style={{ fontSize: "9.5px", fontWeight: 800, color: l.color, letterSpacing: "1px", fontStyle: "italic" }}>{l.status}</span>
                    </div>
                    <h4 style={{ fontSize: "14px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 5px 0", lineHeight: 1.3 }}>{l.title}</h4>
                    <p style={{ fontSize: "12px", lineHeight: 1.6, color: "#5B7A78", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{l.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* bottom: small note about how to read the diagram */}
          <div style={{ marginTop: "22px", paddingTop: "18px", borderTop: "1px solid rgba(11, 110, 106, 0.08)", display: "flex", alignItems: "center", justifyContent: "center", gap: "10px" }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" stroke="#9CB3B0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
            <span style={{ fontSize: "11.5px", color: "#9CB3B0", fontStyle: "italic" }}>Baca dari dalam ke luar: mulai dari inti yang sudah ada, melebar ke yang sedang disusun, lalu ke arah yang akan dipertimbangkan.</span>
          </div>
        </div>
        <p style={CAP}>Gambar 4. Perluasan ruang lingkup INFOTRINK dalam tiga lapisan — sudah ada, sedang disusun, akan dipertimbangkan.</p>
      </div>

      {/* =====================================================
          8. RINGKASAN BATAS — quick reference
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#8B5CF6") }}>Ringkasan Batas Ruang Lingkup</h2>
        <p style={P}>
          Sebagai penutup pembahasan, berikut ringkasan padat tentang apa yang ada di dalam dan di luar ruang lingkup INFOTRINK. Ringkasan ini dapat dijadikan rujukan cepat tanpa harus membaca ulang seluruh bagian di atas.
        </p>

        {/* 2-column quick reference */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginTop: "20px" }}>
          {/* di dalam */}
          <div style={{ background: "white", borderRadius: "16px", overflow: "hidden", border: "1px solid rgba(16, 185, 129, 0.2)", boxShadow: "0 4px 14px rgba(16, 185, 129, 0.08)" }}>
            <div style={{ background: "linear-gradient(135deg, #10B981 0%, #059669 100%)", padding: "14px 22px", color: "white", display: "flex", alignItems: "center", gap: "10px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
              <div>
                <div style={{ fontSize: "10px", fontWeight: 800, letterSpacing: "2px", opacity: 0.85 }}>DI DALAM RUANG LINGKUP</div>
                <div style={{ fontSize: "16px", fontWeight: 800 }}>Yang Dihimpun</div>
              </div>
            </div>
            <ul style={{ margin: 0, padding: "16px 22px 18px", listStyle: "none" }}>
              {["Artikel, riset, kajian, laporan, data, gagasan", "Materi dari berbagai bidang yang saling melengkapi", "Konten dengan konteks dan keterkaitan yang jelas", "Pembaca dari pemula sampai ahli", "Dokumentasi proses yang berkelanjutan"].map((item, i) => (
                <li key={i} style={{ display: "flex", gap: "10px", padding: "7px 0", borderBottom: i < 4 ? "1px solid rgba(11, 110, 106, 0.06)" : "none", fontSize: "12.5px", lineHeight: 1.55, color: "#1F2937" }}>
                  <span style={{ color: "#10B981", fontWeight: 800, marginTop: "1px" }}>✓</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          {/* di luar */}
          <div style={{ background: "white", borderRadius: "16px", overflow: "hidden", border: "1px solid rgba(239, 68, 68, 0.2)", boxShadow: "0 4px 14px rgba(239, 68, 68, 0.08)" }}>
            <div style={{ background: "linear-gradient(135deg, #EF4444 0%, #DC2626 100%)", padding: "14px 22px", color: "white", display: "flex", alignItems: "center", gap: "10px" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
              <div>
                <div style={{ fontSize: "10px", fontWeight: 800, letterSpacing: "2px", opacity: 0.85 }}>DI LUAR RUANG LINGKUP</div>
                <div style={{ fontSize: "16px", fontWeight: 800 }}>Yang Tidak Dihimpun</div>
              </div>
            </div>
            <ul style={{ margin: 0, padding: "16px 22px 18px", listStyle: "none" }}>
              {["Berita harian yang mengejar kecepatan", "Transaksi jual-beli atau lelang", "Konten tanpa konteks atau keterangan asal", "Opini tanpa dasar data atau referensi", "Hal-hal di luar konteks pengetahuan"].map((item, i) => (
                <li key={i} style={{ display: "flex", gap: "10px", padding: "7px 0", borderBottom: i < 4 ? "1px solid rgba(11, 110, 106, 0.06)" : "none", fontSize: "12.5px", lineHeight: 1.55, color: "#1F2937" }}>
                  <span style={{ color: "#EF4444", fontWeight: 800, marginTop: "1px" }}>✕</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* =====================================================
          9. POSISI HALAMAN — flow diagram
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Posisi Halaman Ini</h2>
        <p style={P}>
          Halaman ini adalah bagian keempat dari rangkaian Mengenal INFOTRINK. Setelah memahami apa, mengapa, dan untuk apa, pembaca kini memahami sampai mana. Berikut alur lengkapnya.
        </p>

        {/* horizontal flow with this page highlighted */}
        <div style={{ background: "white", borderRadius: "16px", padding: "28px 24px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", margin: "18px 0" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "8px" }}>
            {[
              { name: "Pengenalan", q: "Apa", color: "#3B82F6", current: false },
              { name: "Latar Belakang", q: "Mengapa", color: "#8B5CF6", current: false },
              { name: "Tujuan & Fungsi", q: "Untuk Apa", color: "#0B6E6A", current: false },
              { name: "Ruang Lingkup", q: "Sampai Mana", color: "#F59E0B", current: true },
              { name: "Prinsip", q: "Bagaimana", color: "#EC4899", current: false },
            ].map((p, i, arr) => (
              <div key={p.name} style={{ flex: 1, display: "flex", alignItems: "center" }}>
                <div style={{ flex: 1, textAlign: "center", padding: p.current ? "16px 8px" : "12px 8px", background: p.current ? "linear-gradient(135deg, #0B3B3A 0%, #0B6E6A 100%)" : `${p.color}08`, borderRadius: "12px", border: p.current ? "2px solid #0B6E6A" : `1px solid ${p.color}25`, boxShadow: p.current ? "0 6px 18px rgba(11, 110, 106, 0.25)" : "none", transform: p.current ? "scale(1.05)" : "scale(1)" }}>
                  <div style={{ fontSize: "9px", fontWeight: 800, color: p.current ? "#81F6EF" : p.color, letterSpacing: "1.5px", marginBottom: "4px" }}>{p.q.toUpperCase()}</div>
                  <div style={{ fontSize: "12px", fontWeight: 800, color: p.current ? "white" : "#0B3B3A" }}>{p.name}</div>
                  {p.current && <div style={{ fontSize: "9px", color: "#81F6EF", marginTop: "3px", fontWeight: 700 }}>&#9658; HALAMAN INI</div>}
                </div>
                {i < arr.length - 1 && (
                  <div style={{ display: "flex", alignItems: "center", padding: "0 4px" }}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M5 12h14m0 0l-6-6m6 6l-6 6" stroke="#0B6E6A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* =====================================================
          10. PENUTUP + NAVIGATION
      ===================================================== */}
      <div style={{ marginBottom: "20px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Penutup</h2>
        <p style={P}>
          Ruang lingkup INFOTRINK sudah dijelaskan dari tiga dimensi: cakupan topik, kedalaman, dan pembaca. Setiap dimensi punya batas yang jelas — apa yang masuk, apa yang tidak, sampai mana, dan untuk siapa. Batas bukan penjara, melainkan penegas identitas. Tanpa batas yang jelas, platform bisa menampung hal-hal yang bukan bagiannya dan kehilangan arah.
        </p>
        <p style={P}>
          Setelah memahami sampai mana cakupan INFOTRINK, langkah terakhir adalah mengetahui bagaimana seluruh materi tersebut dikelola — yang akan dijelaskan pada halaman Prinsip Pengelolaan.
        </p>

        {/* navigation cards */}
        <div style={{ marginTop: "24px", paddingTop: "24px", borderTop: "1px solid rgba(11, 110, 106, 0.1)" }}>
          <h3 style={{ fontSize: "15px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 14px 0", display: "flex", alignItems: "center", gap: "8px" }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M13 7l5 5m0 0l-5 5m5-5H6" stroke="#0B6E6A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
            Lanjutkan ke Bagian Lainnya
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "14px" }}>
            {[
              { name: "Pengenalan INFOTRINK", menu: "Mengenal INFOTRINK", submenu: "Pengenalan INFOTRINK", color: "#3B82F6", svg: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" },
              { name: "Latar Belakang", menu: "Mengenal INFOTRINK", submenu: "Latar Belakang", color: "#10B981", svg: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" },
              { name: "Tujuan dan Fungsi", menu: "Mengenal INFOTRINK", submenu: "Tujuan dan Fungsi", color: "#F59E0B", svg: "M13 10V3L4 14h7v7l9-11h-7z" },
              { name: "Prinsip Pengelolaan", menu: "Mengenal INFOTRINK", submenu: "Prinsip Pengelolaan", color: "#8B5CF6", svg: "M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" },
            ].map((item) => (
              <div
                key={item.name}
                onClick={() => onOpenSubmenu(item.menu, item.submenu)}
                style={{ cursor: "pointer", background: "white", borderRadius: "14px", padding: "18px 16px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 12px rgba(11, 59, 58, 0.05)", transition: "all 0.2s ease", borderTop: `3px solid ${item.color}` }}
                onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = "0 8px 20px rgba(11, 59, 58, 0.1)"; }}
                onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "0 4px 12px rgba(11, 59, 58, 0.05)"; }}
              >
                <div style={{ width: "38px", height: "38px", borderRadius: "10px", background: `${item.color}15`, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "10px" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d={item.svg} stroke={item.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
                <div style={{ fontSize: "13.5px", fontWeight: 800, color: "#0B3B3A", marginBottom: "4px", lineHeight: 1.25 }}>{item.name}</div>
                <div style={{ display: "flex", alignItems: "center", gap: "4px", fontSize: "11px", color: item.color, fontWeight: 700 }}>
                  Baca selengkapnya
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M5 12h14m0 0l-6-6m6 6l-6 6" stroke={item.color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// PRINSIP PENGELOLAAN PAGE — menjawab "bagaimana" INFOTRINK dikelola
// ============================================================
function PrinsipPengelolaanPage({ onOpenSubmenu }: { onOpenSubmenu: (menu: string, submenu: string) => void }) {
  const H2 = {
    fontSize: "22px",
    fontWeight: 800,
    color: "#0B3B3A",
    margin: "0 0 14px 0",
    lineHeight: 1.3,
    letterSpacing: "-0.2px",
  } as const;
  const H2Bar = (color = "#0B6E6A") => ({
    borderLeft: `4px solid ${color}`,
    paddingLeft: "14px",
  });
  const P = {
    fontSize: "15px",
    lineHeight: 1.85,
    color: "#1F2937",
    margin: "0 0 14px 0",
    textAlign: "justify" as const,
    textJustify: "inter-word" as const,
  };
  const CAP = {
    fontSize: "12px",
    color: "#9CB3B0",
    textAlign: "center" as const,
    margin: "8px 0 28px 0",
    fontStyle: "italic" as const,
  };

  return (
    <div style={{ padding: "165px 70px 60px", color: "#1F2937" }}>
      {/* =====================================================
          0. HERO — dark hero dengan teks putih (NEW: inverted dark hero)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <div style={{ position: "relative", background: "linear-gradient(135deg, #0B3B3A 0%, #0B6E6A 60%, #0EA5E9 100%)", borderRadius: "20px", padding: "44px 48px", overflow: "hidden", boxShadow: "0 14px 40px rgba(11, 59, 58, 0.25)" }}>
          {/* decorative geometric pattern */}
          <div style={{ position: "absolute", top: "-80px", right: "-80px", width: "320px", height: "320px", borderRadius: "50%", background: "rgba(129, 246, 239, 0.1)" }} />
          <div style={{ position: "absolute", top: "40px", right: "40px", width: "160px", height: "160px", borderRadius: "50%", border: "2px solid rgba(129, 246, 239, 0.2)" }} />
          <div style={{ position: "absolute", top: "80px", right: "80px", width: "80px", height: "80px", borderRadius: "50%", border: "2px solid rgba(129, 246, 239, 0.3)" }} />

          <div style={{ position: "relative", color: "white", maxWidth: "780px" }}>
            <h1 style={{ fontSize: "44px", fontWeight: 800, margin: "0 0 16px 0", letterSpacing: "-0.8px", lineHeight: 1.05 }}>
              Prinsip Pengelolaan <BrandText text="INFOTRINK" />
            </h1>
            <p style={{ fontSize: "16px", lineHeight: 1.8, margin: 0, opacity: 0.95, textAlign: "justify", textJustify: "inter-word" }}>
              Halaman ini menutup rangkaian Mengenal INFOTRINK dengan menjelaskan bagaimana seluruh materi dikelola — bukan sekadar apa, mengapa, untuk apa, atau sampai mana, melainkan prinsip-prinsip yang dipakai sehari-hari agar pengetahuan tetap tertata, hidup, dan bermanfaat. Enam prinsip berikut bukan aturan kaku, melainkan kompas yang dipegang pengelola saat mengambil keputusan.
            </p>
          </div>
        </div>
      </div>

      {/* =====================================================
          1. ENAM PRINSIP — numbered timeline horizontal (NEW)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Enam Prinsip Pengelolaan</h2>
        <p style={P}>
          Berikut enam prinsip yang dipegang dalam mengelola INFOTRINK. Setiap prinsip punya satu peran spesifik — tidak saling mengulang — sehingga jika satu prinsip dilepas, akan ada celah yang tidak tertutup oleh prinsip lain.
        </p>

        {/* horizontal numbered timeline — alternating top/bottom labels */}
        <div style={{ background: "white", borderRadius: "20px", padding: "36px 28px 28px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", margin: "22px 0" }}>
          {/* timeline track */}
          <div style={{ position: "relative", height: "6px", background: "linear-gradient(90deg, #3B82F6 0%, #10B981 20%, #F59E0B 40%, #8B5CF6 60%, #EC4899 80%, #0EA5E9 100%)", borderRadius: "999px", margin: "0 30px" }} />

          {/* 6 nodes */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: "8px", marginTop: "-22px", padding: "0 18px" }}>
            {[
              { num: "1", title: "Keterbacaan", color: "#3B82F6" },
              { num: "2", title: "Keteraturan", color: "#10B981" },
              { num: "3", title: "Kontekstualitas", color: "#F59E0B" },
              { num: "4", title: "Keberlanjutan", color: "#8B5CF6" },
              { num: "5", title: "Keterbukaan", color: "#EC4899" },
              { num: "6", title: "Tanggung Jawab", color: "#0EA5E9" },
            ].map((p) => (
              <div key={p.num} style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center" }}>
                <div style={{ width: "40px", height: "40px", borderRadius: "50%", background: "white", border: `3px solid ${p.color}`, display: "flex", alignItems: "center", justifyContent: "center", color: p.color, fontSize: "16px", fontWeight: 800, boxShadow: `0 4px 12px ${p.color}30` }}>
                  {p.num}
                </div>
                <div style={{ fontSize: "12px", fontWeight: 800, color: "#0B3B3A", marginTop: "8px" }}>{p.title}</div>
              </div>
            ))}
          </div>

          {/* alternating descriptions below */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: "8px", marginTop: "20px", padding: "0 14px" }}>
            {[
              { desc: "Bahasa yang dipakai pembaca, bukan jargon.", color: "#3B82F6", align: "left" },
              { desc: "Setiap materi punya tempat yang jelas.", color: "#10B981", align: "center" },
              { desc: "Asal, waktu, dan latar belakang dilampirkan.", color: "#F59E0B", align: "center" },
              { desc: "Materi terus diperbarui seiring perkembangan.", color: "#8B5CF6", align: "center" },
              { desc: "Akses terbuka bagi berbagai kalangan.", color: "#EC4899", align: "center" },
              { desc: "Setiap materi dapat ditelusuri ke penulisnya.", color: "#0EA5E9", align: "right" },
            ].map((p, i) => (
              <div key={i} style={{ padding: "10px 6px 0", borderTop: `2px solid ${p.color}30` }}>
                <p style={{ fontSize: "11px", lineHeight: 1.55, color: "#5B7A78", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
        <p style={CAP}>Gambar 1. Enam prinsip pengelolaan INFOTRINK sebagai kompas sehari-hari.</p>
      </div>

      {/* =====================================================
          2. DETAIL PRINSIP — alternating expandable cards (NEW pattern)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#3B82F6") }}>Penjabaran Setiap Prinsip</h2>
        <p style={P}>
          Setiap prinsip dijabarkan menjadi satu pertanyaan kunci, satu kalimat prinsip, dan tiga penerapan konkret. Struktur ini memastikan setiap prinsip tidak berhenti di tingkat slogan, melainkan turut ke praktik.
        </p>

        {/* alternating expandable rows — different from zigzag */}
        <div style={{ display: "flex", flexDirection: "column", gap: "14px", marginTop: "20px" }}>
          {[
            {
              num: "1", title: "Keterbacaan", q: "Apakah pembaca bisa memahami?",
              prinsip: "Bahasa yang digunakan harus dapat dipahami pembaca, bukan sekadar terlihat pintar bagi penulis.",
              penerapan: ["Hindari jargon tanpa penjelasan", "Pakai kalimat pendek dan jelas", "Lengkapi istilah teknis dengan definisi"],
              color: "#3B82F6",
            },
            {
              num: "2", title: "Keteraturan", q: "Apakah setiap materi punya tempat?",
              prinsip: "Setiap materi ditempatkan pada kategori dan sub-kategori yang sesuai, tidak ditumpuk tanpa urutan.",
              penerapan: ["Kategorisasi berdasarkan bidang", "Sub-kategori per jenis materi", "Penamaan yang konsisten"],
              color: "#10B981",
            },
            {
              num: "3", title: "Kontekstualitas", q: "Apakah asal materi jelas?",
              prinsip: "Setiap materi dilengkapi keterangan asal, waktu, dan latar belakang agar maknanya tidak hilang.",
              penerapan: ["Catat tanggal dan sumber", "Sebutkan latar belakang", "Tautkan ke referensi pendukung"],
              color: "#F59E0B",
            },
            {
              num: "4", title: "Keberlanjutan", q: "Apakah materi tetap hidup?",
              prinsip: "Materi tidak ditinggal setelah diterbitkan — diperbarui, dilengkapi, atau dikoreksi seiring waktu.",
              penerapan: ["Tinjau materi secara berkala", "Tandai yang sudah usang", "Tambahkan perkembangan terbaru"],
              color: "#8B5CF6",
            },
            {
              num: "5", title: "Keterbukaan", q: "Apakah dapat diakses banyak orang?",
              prinsip: "Akses ke materi tidak dibatasi oleh golongan, lembaga, atau syarat teknis yang menyulitkan.",
              penerapan: ["Tanpa login wajib untuk baca", "Format yang dapat dibuka di berbagai perangkat", "Bahasa yang tidak eksklusif"],
              color: "#EC4899",
            },
            {
              num: "6", title: "Tanggung Jawab", q: "Apakah dapat ditelusuri ke sumbernya?",
              prinsip: "Setiap materi dapat ditelusuri kembali ke penulisnya, lengkap dengan tanggung jawab atas isi yang ditulis.",
              penerapan: ["Nama penulis tercantum", "Kontak atau cara menjangkau", "Klarifikasi jika ada keberatan"],
              color: "#0EA5E9",
            },
          ].map((p) => (
            <div key={p.num} style={{ background: "white", borderRadius: "16px", overflow: "hidden", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)" }}>
              <div style={{ display: "grid", gridTemplateColumns: "100px 1fr 1.2fr", minHeight: "100px" }}>
                {/* left: number + title block (colored) */}
                <div style={{ background: `linear-gradient(135deg, ${p.color} 0%, ${p.color}dd 100%)`, color: "white", padding: "20px 18px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center" }}>
                  <div style={{ fontSize: "32px", fontWeight: 800, lineHeight: 1, marginBottom: "6px" }}>{p.num}</div>
                  <div style={{ fontSize: "13px", fontWeight: 800, letterSpacing: "0.5px" }}>{p.title}</div>
                </div>
                {/* middle: question + principle */}
                <div style={{ padding: "18px 22px", borderRight: "1px solid rgba(11, 110, 106, 0.06)", display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <div style={{ fontSize: "10px", fontWeight: 800, color: p.color, letterSpacing: "1.5px", marginBottom: "6px" }}>PERTANYAAN KUNCI</div>
                  <div style={{ fontSize: "13px", fontWeight: 700, color: "#0B3B3A", marginBottom: "10px", lineHeight: 1.4, fontStyle: "italic" }}>&ldquo;{p.q}&rdquo;</div>
                  <div style={{ fontSize: "10px", fontWeight: 800, color: p.color, letterSpacing: "1.5px", marginBottom: "4px" }}>PRINSIP</div>
                  <p style={{ fontSize: "12.5px", lineHeight: 1.6, color: "#1F2937", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{p.prinsip}</p>
                </div>
                {/* right: penerapan list */}
                <div style={{ padding: "18px 22px", background: `${p.color}05`, display: "flex", flexDirection: "column", justifyContent: "center" }}>
                  <div style={{ fontSize: "10px", fontWeight: 800, color: p.color, letterSpacing: "1.5px", marginBottom: "8px" }}>PENERAPAN KONKRET</div>
                  <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>
                    {p.penerapan.map((it, idx) => (
                      <li key={idx} style={{ display: "flex", gap: "8px", alignItems: "flex-start", fontSize: "12.5px", color: "#1F2937", marginBottom: "5px", lineHeight: 1.5 }}>
                        <span style={{ color: p.color, fontWeight: 800, flexShrink: 0, marginTop: "1px" }}>›</span>
                        <span>{it}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* =====================================================
          3. SIKLUS PENGELOLAAN — circular cycle diagram (NEW)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#10B981") }}>Siklus Pengelolaan Harian</h2>
        <p style={P}>
          Enam prinsip di atas tidak dijalankan sekaligus — mereka mengalir dalam satu siklus yang berulang. Setiap materi yang masuk akan melewati empat tahap berikut, lalu kembali ke awal ketika ada perkembangan baru.
        </p>

        {/* 2-column: image + cycle diagram */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: "24px", marginTop: "20px", alignItems: "stretch" }}>
          {/* left: image */}
          <div style={{ position: "relative", borderRadius: "16px", overflow: "hidden", minHeight: "320px", boxShadow: "0 6px 18px rgba(11, 59, 58, 0.1)" }}>
            <Image src="/slide/prinsip-siklus.png" alt="Siklus pengelolaan yang berputar naik" width={640} height={320} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block", position: "absolute", inset: 0 }} unoptimized />
            <div style={{ position: "absolute", inset: 0, background: "linear-gradient(135deg, rgba(11,59,58,0.7) 0%, rgba(11,59,58,0.2) 60%, transparent 100%)" }} />
            <div style={{ position: "absolute", left: "20px", bottom: "20px", right: "20px", color: "white" }}>
              <div style={{ fontSize: "11px", fontWeight: 700, color: "#81F6EF", letterSpacing: "2px", marginBottom: "6px" }}>SIKLUS BERPUTAR</div>
              <div style={{ fontSize: "16px", fontWeight: 700, lineHeight: 1.3 }}>Bukan tahap sekali jalan, melainkan putaran yang terus berulang.</div>
            </div>
          </div>

          {/* right: cycle steps */}
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            {[
              { step: "A", title: "Tulis", desc: "Materi disusun dengan struktur yang jelas — mulai dari pengenalan, pembahasan, hingga penutup.", color: "#3B82F6" },
              { step: "B", title: "Tata", desc: "Materi ditempatkan pada kategori yang sesuai dan dilengkapi keterangan asal serta konteksnya.", color: "#10B981" },
              { step: "C", title: "Terbitkan", desc: "Materi diterbitkan dan dapat diakses pembaca, lengkap dengan penulis dan waktu terbit.", color: "#F59E0B" },
              { step: "D", title: "Tinjau", desc: "Materi ditinjau secara berkala — diperbarui, dilengkapi, atau dikoreksi sesuai perkembangan.", color: "#8B5CF6" },
            ].map((c, i, arr) => (
              <div key={c.step} style={{ display: "flex", alignItems: "center", gap: "14px", background: "white", borderRadius: "14px", padding: "14px 18px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 2px 8px rgba(11, 59, 58, 0.04)" }}>
                {/* step letter badge */}
                <div style={{ width: "40px", height: "40px", borderRadius: "50%", background: `linear-gradient(135deg, ${c.color} 0%, ${c.color}dd 100%)`, color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "16px", fontWeight: 800, flexShrink: 0, boxShadow: `0 4px 12px ${c.color}40` }}>
                  {c.step}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: "14px", fontWeight: 800, color: "#0B3B3A", marginBottom: "3px" }}>{c.title}</div>
                  <p style={{ fontSize: "12px", lineHeight: 1.55, color: "#5B7A78", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>{c.desc}</p>
                </div>
                {/* arrow to next (except last) */}
                {i < arr.length - 1 ? (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}><path d="M19 14l-7 7m0 0l-7-7m7 7V3" stroke={c.color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                ) : (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}><path d="M4 4v5h.582m15.356 2A8.001 8.001 0 0 0 4.582 9m0 0H9" stroke={c.color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                )}
              </div>
            ))}
            <div style={{ textAlign: "center", padding: "8px 0 0 0", fontSize: "11px", color: "#9CB3B0", fontStyle: "italic" }}>
              ↻ Setelah D, kembali ke A ketika ada perkembangan baru — siklus tidak berhenti.
            </div>
          </div>
        </div>
      </div>

      {/* =====================================================
          4. KEKUATAN PRINSIP — vertical strength bars (NEW)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#F59E0B") }}>Kekuatan Setiap Prinsip</h2>
        <p style={P}>
          Tidak semua prinsip ditekankan sama kuatnya. Berikut bobot perhatian yang diberikan pada setiap prinsip — bukan berarti yang lain tidak penting, melainkan untuk menunjukkan titik berat pengelolaan saat ini.
        </p>

        {/* 2-column: vertical bar chart left + interpretation right */}
        <div style={{ background: "white", borderRadius: "18px", padding: "32px 30px 28px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", margin: "20px 0" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "32px", alignItems: "center" }}>
            {/* left: vertical bar chart */}
            <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", height: "260px", padding: "0 10px", borderBottom: "2px solid #E5E7EB" }}>
              {[
                { label: "Baca", val: 95, color: "#3B82F6" },
                { label: "Tata", val: 90, color: "#10B981" },
                { label: "Konteks", val: 85, color: "#F59E0B" },
                { label: "Lanjut", val: 75, color: "#8B5CF6" },
                { label: "Buka", val: 88, color: "#EC4899" },
                { label: "Jawab", val: 80, color: "#0EA5E9" },
              ].map((b) => (
                <div key={b.label} style={{ display: "flex", flexDirection: "column", alignItems: "center", flex: 1 }}>
                  {/* bar */}
                  <div style={{ width: "100%", maxWidth: "40px", height: `${b.val * 2.4}px`, background: `linear-gradient(180deg, ${b.color} 0%, ${b.color}cc 100%)`, borderRadius: "8px 8px 0 0", marginBottom: "8px", display: "flex", alignItems: "flex-start", justifyContent: "center", paddingTop: "6px", boxShadow: `0 4px 12px ${b.color}30` }}>
                    <span style={{ fontSize: "11px", fontWeight: 800, color: "white" }}>{b.val}</span>
                  </div>
                  <div style={{ fontSize: "11px", fontWeight: 700, color: "#5B7A78", textAlign: "center" }}>{b.label}</div>
                </div>
              ))}
            </div>
            {/* right: interpretation */}
            <div>
              <div style={{ fontSize: "11px", fontWeight: 800, color: "#9CB3B0", letterSpacing: "1.5px", marginBottom: "10px" }}>INTERPRETASI</div>
              <p style={{ fontSize: "13px", lineHeight: 1.7, color: "#1F2937", margin: "0 0 14px 0", textAlign: "justify", textJustify: "inter-word" }}>
                <strong>Keterbacaan (95)</strong> dan <strong>Keterbukaan (88)</strong> menempati posisi tertinggi — pengelolaan INFOTRINK saat ini paling menekankan bahwa materi harus dapat dibaca dan diakses oleh siapa pun.
              </p>
              <p style={{ fontSize: "13px", lineHeight: 1.7, color: "#1F2937", margin: "0 0 14px 0", textAlign: "justify", textJustify: "inter-word" }}>
                <strong>Keberlanjutan (75)</strong> berada di posisi terendah bukan karena tidak penting, melainkan karena tahap pembaruan berkala masih dalam pengembangan.
              </p>
              <p style={{ fontSize: "13px", lineHeight: 1.7, color: "#1F2937", margin: 0, textAlign: "justify", textJustify: "inter-word" }}>
                Sisanya berada di rentang 80–90, yang berarti prinsip-prinsip tersebut sudah berjalan dengan baik tetapi masih punya ruang untuk diperkuat.
              </p>
            </div>
          </div>
        </div>
        <p style={CAP}>Gambar 2. Bobot perhatian pada setiap prinsip — bukan tolok ukur kesuksesan, melainkan penegas titik berat pengelolaan.</p>
      </div>

      {/* =====================================================
          5. SEBELUM vs SESUDAH PRINSIP — side-by-side transformation (NEW)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#8B5CF6") }}>Sebelum vs Sesudah Prinsip Diterapkan</h2>
        <p style={P}>
          Apa bedanya materi yang dikelola dengan prinsip dan yang tidak? Berikut perbandingan langsung dari sudut pandang pembaca — agar terlihat mengapa prinsip bukan sekadar dokumen di atas kertas.
        </p>

        {/* 2-column transformation cards */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr", gap: "16px", marginTop: "22px", alignItems: "stretch" }}>
          {/* before card */}
          <div style={{ background: "white", borderRadius: "16px", overflow: "hidden", border: "1px solid rgba(239, 68, 68, 0.2)", boxShadow: "0 4px 14px rgba(239, 68, 68, 0.08)" }}>
            <div style={{ background: "rgba(239, 68, 68, 0.08)", padding: "14px 22px", borderBottom: "1px solid rgba(239, 68, 68, 0.15)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <div style={{ width: "30px", height: "30px", borderRadius: "8px", background: "rgba(239, 68, 68, 0.15)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M6 18L18 6M6 6l12 12" stroke="#EF4444" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
                <div>
                  <div style={{ fontSize: "10px", fontWeight: 800, color: "#EF4444", letterSpacing: "1.5px" }}>TANPA PRINSIP</div>
                  <div style={{ fontSize: "16px", fontWeight: 800, color: "#0B3B3A" }}>Sebelum</div>
                </div>
              </div>
            </div>
            <ul style={{ margin: 0, padding: "16px 22px 18px", listStyle: "none" }}>
              {["Materi ditumpuk tanpa urutan yang jelas", "Banyak jargon tanpa penjelasan", "Asal dan waktu tidak tercatat", "Sekali terbit, lalu ditinggal", "Akses terbatas, perlu syarat teknis", "Tidak jelas siapa yang menulis"].map((it, i) => (
                <li key={i} style={{ display: "flex", gap: "10px", padding: "7px 0", borderBottom: i < 5 ? "1px solid rgba(11, 110, 106, 0.06)" : "none", fontSize: "12.5px", lineHeight: 1.55, color: "#5B7A78" }}>
                  <span style={{ color: "#EF4444", fontWeight: 800, marginTop: "1px" }}>✕</span>
                  <span>{it}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* arrow in middle */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: "0 4px" }}>
            <div style={{ width: "48px", height: "48px", borderRadius: "50%", background: "linear-gradient(135deg, #0B6E6A 0%, #10B981 100%)", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 4px 14px rgba(11, 110, 106, 0.3)" }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M5 12h14m0 0l-6-6m6 6l-6 6" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
            </div>
          </div>

          {/* after card */}
          <div style={{ background: "white", borderRadius: "16px", overflow: "hidden", border: "1px solid rgba(16, 185, 129, 0.2)", boxShadow: "0 4px 14px rgba(16, 185, 129, 0.08)" }}>
            <div style={{ background: "rgba(16, 185, 129, 0.08)", padding: "14px 22px", borderBottom: "1px solid rgba(16, 185, 129, 0.15)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <div style={{ width: "30px", height: "30px", borderRadius: "8px", background: "rgba(16, 185, 129, 0.15)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke="#10B981" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
                <div>
                  <div style={{ fontSize: "10px", fontWeight: 800, color: "#10B981", letterSpacing: "1.5px" }}>DENGAN PRINSIP</div>
                  <div style={{ fontSize: "16px", fontWeight: 800, color: "#0B3B3A" }}>Sesudah</div>
                </div>
              </div>
            </div>
            <ul style={{ margin: 0, padding: "16px 22px 18px", listStyle: "none" }}>
              {["Materi tertata per kategori yang jelas", "Bahasa dapat dipahami pembaca umum", "Asal, waktu, dan latar belakang tercatat", "Tinjau berkala, diperbarui seiring waktu", "Akses terbuka tanpa syarat menyulitkan", "Penulis tercantum, dapat dihubungi"].map((it, i) => (
                <li key={i} style={{ display: "flex", gap: "10px", padding: "7px 0", borderBottom: i < 5 ? "1px solid rgba(11, 110, 106, 0.06)" : "none", fontSize: "12.5px", lineHeight: 1.55, color: "#1F2937", fontWeight: 500 }}>
                  <span style={{ color: "#10B981", fontWeight: 800, marginTop: "1px" }}>✓</span>
                  <span>{it}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* =====================================================
          6. LAKUKAN vs HINDARI — paired do/dont (NEW)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#EC4899") }}>Lakukan vs Hindari</h2>
        <p style={P}>
          Berikut ringkasan praktis tentang apa yang dilakukan dan apa yang dihindari dalam pengelolaan INFOTRINK. Daftar ini bisa dijadikan rujukan cepat tanpa harus membaca ulang keenam prinsip.
        </p>

        {/* 5 paired rows */}
        <div style={{ background: "white", borderRadius: "16px", overflow: "hidden", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)", margin: "20px 0" }}>
          {/* header row */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", background: "linear-gradient(90deg, rgba(16, 185, 129, 0.1) 0%, rgba(16, 185, 129, 0.05) 50%, rgba(239, 68, 68, 0.05) 50%, rgba(239, 68, 68, 0.1) 100%)" }}>
            <div style={{ padding: "14px 22px", display: "flex", alignItems: "center", gap: "10px", borderRight: "1px solid rgba(11, 110, 106, 0.06)" }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke="#10B981" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
              <span style={{ fontSize: "12px", fontWeight: 800, color: "#10B981", letterSpacing: "1.5px" }}>LAKUKAN</span>
            </div>
            <div style={{ padding: "14px 22px", display: "flex", alignItems: "center", gap: "10px" }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" stroke="#EF4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
              <span style={{ fontSize: "12px", fontWeight: 800, color: "#EF4444", letterSpacing: "1.5px" }}>HINDARI</span>
            </div>
          </div>
          {/* 5 paired rows */}
          {[
            ["Tulis dengan bahasa pembaca umum", "Pakai jargon tanpa penjelasan"],
            ["Kategorikan setiap materi dengan jelas", "Tumpuk materi tanpa urutan"],
            ["Catat asal dan waktu setiap materi", "Terbitkan tanpa konteks atau sumber"],
            ["Tinjau materi secara berkala", "Tinggalkan materi setelah terbit"],
            ["Buka akses tanpa syarat menyulitkan", "Batasi akses dengan syarat teknis"],
          ].map((pair, i) => (
            <div key={i} style={{ display: "grid", gridTemplateColumns: "1fr 1fr", borderTop: "1px solid rgba(11, 110, 106, 0.06)" }}>
              <div style={{ padding: "13px 22px", fontSize: "13px", lineHeight: 1.55, color: "#1F2937", borderRight: "1px solid rgba(11, 110, 106, 0.06)", display: "flex", gap: "10px", alignItems: "flex-start" }}>
                <span style={{ color: "#10B981", fontWeight: 800, flexShrink: 0 }}>+</span>
                <span>{pair[0]}</span>
              </div>
              <div style={{ padding: "13px 22px", fontSize: "13px", lineHeight: 1.55, color: "#5B7A78", display: "flex", gap: "10px", alignItems: "flex-start" }}>
                <span style={{ color: "#EF4444", fontWeight: 800, flexShrink: 0 }}>−</span>
                <span>{pair[1]}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* =====================================================
          7. CHECKLIST PENGELOLA — interactive-looking checklist (NEW)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0EA5E9") }}>Checklist Sebelum Menerbitkan</h2>
        <p style={P}>
          Sebagai penutup pembahasan prinsip, berikut daftar periksa yang dipakai pengelola sebelum sebuah materi diterbitkan. Setiap poin mengacu pada satu prinsip di atas — jika ada satu poin yang belum terpenuhi, materi sebaiknya ditinjau ulang dulu.
        </p>

        {/* visual: prisma image + checklist */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.6fr", gap: "20px", marginTop: "20px", alignItems: "stretch" }}>
          {/* left: prisma image */}
          <div style={{ position: "relative", borderRadius: "16px", overflow: "hidden", minHeight: "320px", boxShadow: "0 6px 18px rgba(11, 59, 58, 0.1)" }}>
            <Image src="/slide/prinsip-prisma.png" alt="Prisma yang memecah satu cahaya menjadi banyak warna" width={640} height={320} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block", position: "absolute", inset: 0 }} unoptimized />
            <div style={{ position: "absolute", inset: 0, background: "linear-gradient(135deg, rgba(11,59,58,0.75) 0%, rgba(11,59,58,0.2) 60%, transparent 100%)" }} />
            <div style={{ position: "absolute", left: "20px", bottom: "20px", right: "20px", color: "white" }}>
              <div style={{ fontSize: "11px", fontWeight: 700, color: "#81F6EF", letterSpacing: "2px", marginBottom: "6px" }}>PRINSIP → PRAKTIK</div>
              <div style={{ fontSize: "15px", fontWeight: 700, lineHeight: 1.35 }}>Satu prinsip dipecah menjadi banyak penerapan — seperti prisma memecah cahaya.</div>
            </div>
          </div>

          {/* right: checklist */}
          <div style={{ background: "white", borderRadius: "16px", padding: "22px 26px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 14px rgba(11, 59, 58, 0.05)" }}>
            <div style={{ fontSize: "11px", fontWeight: 800, color: "#9CB3B0", letterSpacing: "1.5px", marginBottom: "14px" }}>DAFTAR PERIKSA · 8 POIN</div>
            <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
              {[
                { item: "Bahasa dapat dipahami pembaca umum", prinsip: "Keterbacaan", color: "#3B82F6" },
                { item: "Kategori dan sub-kategori sudah tepat", prinsip: "Keteraturan", color: "#10B981" },
                { item: "Asal, waktu, dan latar belakang tercatat", prinsip: "Kontekstualitas", color: "#F59E0B" },
                { item: "Materi akan ditinjau di waktu yang ditentukan", prinsip: "Keberlanjutan", color: "#8B5CF6" },
                { item: "Akses tidak dibatasi syarat menyulitkan", prinsip: "Keterbukaan", color: "#EC4899" },
                { item: "Nama penulis dan cara menghubungi tercantum", prinsip: "Tanggung Jawab", color: "#0EA5E9" },
                { item: "Tidak ada klaim tanpa dasar atau referensi", prinsip: "Kontekstualitas", color: "#F59E0B" },
                { item: "Format dapat dibuka di berbagai perangkat", prinsip: "Keterbukaan", color: "#EC4899" },
              ].map((c, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: "12px", padding: "10px 12px", background: `${c.color}06`, borderRadius: "10px", borderLeft: `3px solid ${c.color}` }}>
                  {/* checkbox */}
                  <div style={{ width: "22px", height: "22px", borderRadius: "6px", border: `2px solid ${c.color}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, background: "white" }}>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke={c.color} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: "12.5px", fontWeight: 600, color: "#1F2937", lineHeight: 1.4 }}>{c.item}</div>
                  </div>
                  <span style={{ fontSize: "9.5px", fontWeight: 700, color: c.color, padding: "3px 8px", background: `${c.color}12`, borderRadius: "999px", letterSpacing: "0.5px", flexShrink: 0 }}>{c.prinsip}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* =====================================================
          8. PENUTUP RANGKAIAN — final summary (NEW)
      ===================================================== */}
      <div style={{ marginBottom: "48px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Penutup Rangkaian Mengenal INFOTRINK</h2>
        <p style={P}>
          Halaman ini menutup rangkaian Mengenal INFOTRINK. Setelah memahami apa (Pengenalan), mengapa (Latar Belakang), untuk apa (Tujuan dan Fungsi), sampai mana (Ruang Lingkup), kini pembaca memahami bagaimana (Prinsip Pengelolaan). Lima pertanyaan itu — apa, mengapa, untuk apa, sampai mana, bagaimana — adalah kerangka yang menyatukan keseluruhan rangkaian.
        </p>

        {/* final recap flow */}
        <div style={{ background: "linear-gradient(135deg, #0B3B3A 0%, #0B6E6A 100%)", borderRadius: "18px", padding: "32px 32px 28px", color: "white", margin: "20px 0", position: "relative", overflow: "hidden" }}>
          <div style={{ position: "absolute", bottom: "-60px", right: "-60px", width: "200px", height: "200px", borderRadius: "50%", background: "rgba(129, 246, 239, 0.08)" }} />
          <div style={{ position: "relative" }}>
            <div style={{ fontSize: "11px", fontWeight: 800, color: "#81F6EF", letterSpacing: "2px", marginBottom: "16px" }}>REKAP LIMA PERTANYAAN</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: "14px" }}>
              {[
                { q: "Apa", a: "Pengenalan INFOTRINK", color: "#3B82F6" },
                { q: "Mengapa", a: "Latar Belakang", color: "#8B5CF6" },
                { q: "Untuk Apa", a: "Tujuan & Fungsi", color: "#10B981" },
                { q: "Sampai Mana", a: "Ruang Lingkup", color: "#F59E0B" },
                { q: "Bagaimana", a: "Prinsip Pengelolaan", color: "#81F6EF", current: true },
              ].map((p, i, arr) => (
                <div key={i} style={{ textAlign: "center", padding: "16px 8px", background: p.current ? "rgba(129, 246, 239, 0.15)" : "rgba(255,255,255,0.06)", borderRadius: "12px", border: p.current ? "2px solid #81F6EF" : "1px solid rgba(255,255,255,0.12)", transform: p.current ? "scale(1.05)" : "scale(1)" }}>
                  <div style={{ fontSize: "10px", fontWeight: 800, color: p.current ? "#81F6EF" : "rgba(255,255,255,0.7)", letterSpacing: "1.5px", marginBottom: "6px" }}>{p.q.toUpperCase()}</div>
                  <div style={{ fontSize: "12px", fontWeight: 700, color: "white", lineHeight: 1.3 }}>{p.a}</div>
                  {p.current && <div style={{ fontSize: "9px", color: "#81F6EF", marginTop: "5px", fontWeight: 800 }}>&#9658; HALAMAN INI</div>}
                </div>
              ))}
            </div>
            <p style={{ fontSize: "13px", lineHeight: 1.7, margin: "20px 0 0 0", opacity: 0.9, textAlign: "justify", textJustify: "inter-word" }}>
              Lima pertanyaan di atas berurutan — tidak boleh terbalik. Memahami "bagaimana" tanpa memahami "apa" akan membuat prinsip kehilangan konteks; memahami "sampai mana" tanpa "untuk apa" akan membuat batas kehilangan arah. Kerangka ini bisa dijadikan rujukan ketika ingin menjelaskan INFOTRINK kepada orang lain.
            </p>
          </div>
        </div>
      </div>

      {/* =====================================================
          9. PENUTUP + NAVIGATION
      ===================================================== */}
      <div style={{ marginBottom: "20px" }}>
        <h2 style={{ ...H2, ...H2Bar("#0B6E6A") }}>Penutup</h2>
        <p style={P}>
          Prinsip pengelolaan INFOTRINK adalah jembatan terakhir yang menyambungkan konsep dengan praktik. Tanpa prinsip yang dipegang, semua hal yang sudah dijelaskan di empat halaman sebelumnya akan berhenti di tingkat gagasan. Dengan prinsip yang dijalankan, INFOTRINK dapat tumbuh menjadi ruang pengetahuan yang tertata, hidup, dan bermanfaat — bukan karena kebetulan, melainkan karena ada kompas yang dipegang setiap hari.
        </p>
        <p style={P}>
          Dengan ini, rangkaian Mengenal INFOTRINK resmi selesai. Pembaca yang sudah membaca kelima halaman diharapkan punya pemahaman utuh tentang platform ini — dari apa, mengapa, untuk apa, sampai mana, hingga bagaimana. Langkah berikutnya adalah menjelajahi materi yang sudah ada, di menu Publikasi, Kategori, atau Galeri.
        </p>

        {/* navigation cards */}
        <div style={{ marginTop: "24px", paddingTop: "24px", borderTop: "1px solid rgba(11, 110, 106, 0.1)" }}>
          <h3 style={{ fontSize: "15px", fontWeight: 800, color: "#0B3B3A", margin: "0 0 14px 0", display: "flex", alignItems: "center", gap: "8px" }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M13 7l5 5m0 0l-5 5m5-5H6" stroke="#0B6E6A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
            Kembali ke Bagian Lainnya
          </h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "14px" }}>
            {[
              { name: "Pengenalan INFOTRINK", menu: "Mengenal INFOTRINK", submenu: "Pengenalan INFOTRINK", color: "#3B82F6", svg: "M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" },
              { name: "Latar Belakang", menu: "Mengenal INFOTRINK", submenu: "Latar Belakang", color: "#10B981", svg: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" },
              { name: "Tujuan dan Fungsi", menu: "Mengenal INFOTRINK", submenu: "Tujuan dan Fungsi", color: "#F59E0B", svg: "M13 10V3L4 14h7v7l9-11h-7z" },
              { name: "Ruang Lingkup", menu: "Mengenal INFOTRINK", submenu: "Ruang Lingkup", color: "#8B5CF6", svg: "M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" },
            ].map((item) => (
              <div
                key={item.name}
                onClick={() => onOpenSubmenu(item.menu, item.submenu)}
                style={{ cursor: "pointer", background: "white", borderRadius: "14px", padding: "18px 16px", border: "1px solid rgba(11, 110, 106, 0.08)", boxShadow: "0 4px 12px rgba(11, 59, 58, 0.05)", transition: "all 0.2s ease", borderTop: `3px solid ${item.color}` }}
                onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = "0 8px 20px rgba(11, 59, 58, 0.1)"; }}
                onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "0 4px 12px rgba(11, 59, 58, 0.05)"; }}
              >
                <div style={{ width: "38px", height: "38px", borderRadius: "10px", background: `${item.color}15`, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "10px" }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d={item.svg} stroke={item.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
                <div style={{ fontSize: "13.5px", fontWeight: 800, color: "#0B3B3A", marginBottom: "4px", lineHeight: 1.25 }}>{item.name}</div>
                <div style={{ display: "flex", alignItems: "center", gap: "4px", fontSize: "11px", color: item.color, fontWeight: 700 }}>
                  Baca selengkapnya
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none"><path d="M5 12h14m0 0l-6-6m6 6l-6 6" stroke={item.color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

